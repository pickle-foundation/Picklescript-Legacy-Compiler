Module 0:6
Ident 7:11 text="main"
Newline 11:12
Newline 12:13
Fn 13:15
Ident 16:20 text="main"
LParen 20:21
RParen 21:22
LBrace 23:24
Newline 24:25
Newline 104:105
Newline 180:181
Newline 256:257
Newline 329:330
Newline 408:409
Newline 482:483
Newline 558:559
Newline 635:636
Newline 714:715
Newline 785:786
Ident 790:797 text="println"
LParen 797:798
Str 798:817 T("collection count:")
Comma 817:818
Ident 819:836 text="gcCollectionCount"
LParen 836:837
RParen 837:838
RParen 838:839
Newline 839:840
Newline 840:841
Newline 914:915
Var 919:922
Ident 923:927 text="keep"
Assign 928:929
LBracket 930:931
Number 931:932 text="0" suf="" isf=0 int=0
RBracket 932:933
Newline 933:934
Var 938:941
Ident 942:943 text="i"
Assign 944:945
Number 946:947 text="0" suf="" isf=0 int=0
Newline 947:948
While 952:957
LParen 958:959
Ident 959:960 text="i"
Lt 961:962
Number 963:965 text="32" suf="" isf=0 int=32
RParen 965:966
LBrace 967:968
Newline 968:969
Ident 977:981 text="keep"
Dot 981:982
Ident 982:986 text="push"
LParen 986:987
Ident 987:988 text="i"
Star 989:990
Number 991:992 text="3" suf="" isf=0 int=3
RParen 992:993
Newline 993:994
Ident 1002:1003 text="i"
Assign 1004:1005
Ident 1006:1007 text="i"
Plus 1008:1009
Number 1010:1011 text="1" suf="" isf=0 int=1
Newline 1011:1012
RBrace 1016:1017
Newline 1017:1018
Ident 1022:1029 text="println"
LParen 1029:1030
Str 1030:1062 T("after 32 pushes, allocs >= 32:")
Comma 1062:1063
Ident 1064:1084 text="gcAllocationsSinceGc"
LParen 1084:1085
RParen 1085:1086
Ge 1087:1089
Number 1090:1092 text="32" suf="" isf=0 int=32
RParen 1092:1093
Newline 1093:1094
Ident 1098:1105 text="println"
LParen 1105:1106
Str 1106:1118 T("bytes > 0:")
Comma 1118:1119
Ident 1120:1134 text="gcBytesSinceGc"
LParen 1134:1135
RParen 1135:1136
Gt 1137:1138
Number 1139:1140 text="0" suf="" isf=0 int=0
RParen 1140:1141
Newline 1141:1142
Newline 1142:1143
Newline 1212:1213
Ident 1217:1231 text="gcSetThreshold"
LParen 1231:1232
Number 1232:1236 text="4096" suf="" isf=0 int=4096
RParen 1236:1237
Newline 1237:1238
Ident 1242:1251 text="gcCollect"
LParen 1251:1252
True 1252:1256
RParen 1256:1257
Newline 1257:1258
Newline 1336:1337
Newline 1410:1411
Newline 1475:1476
Let 1480:1483
Ident 1484:1495 text="allocsAfter"
Assign 1496:1497
Ident 1498:1518 text="gcAllocationsSinceGc"
LParen 1518:1519
RParen 1519:1520
Newline 1520:1521
Let 1525:1528
Ident 1529:1539 text="bytesAfter"
Assign 1540:1541
Ident 1542:1556 text="gcBytesSinceGc"
LParen 1556:1557
RParen 1557:1558
Newline 1558:1559
Let 1563:1566
Ident 1567:1573 text="cycles"
Assign 1574:1575
Ident 1576:1593 text="gcCollectionCount"
LParen 1593:1594
RParen 1594:1595
Newline 1595:1596
Ident 1600:1607 text="println"
LParen 1607:1608
Str 1608:1647 T("after collect, collection count >= 1:")
Comma 1647:1648
Ident 1649:1655 text="cycles"
Ge 1656:1658
Number 1659:1660 text="1" suf="" isf=0 int=1
RParen 1660:1661
Newline 1661:1662
Ident 1666:1673 text="println"
LParen 1673:1674
Str 1674:1723 T("after collect, bytes since gc < 4096 threshold:")
Comma 1723:1724
Ident 1725:1735 text="bytesAfter"
Lt 1736:1737
Number 1738:1742 text="4096" suf="" isf=0 int=4096
RParen 1742:1743
Newline 1743:1744
Ident 1748:1755 text="println"
LParen 1755:1756
Str 1756:1804 T("after collect, allocs reset below pre-collect:")
Comma 1804:1805
Ident 1806:1817 text="allocsAfter"
Lt 1818:1819
Number 1820:1822 text="33" suf="" isf=0 int=33
RParen 1822:1823
Newline 1823:1824
Newline 1904:1905
Newline 1982:1983
Ident 1987:1993 text="assert"
LParen 1993:1994
Ident 1994:2000 text="cycles"
Ge 2001:2003
Number 2004:2005 text="1" suf="" isf=0 int=1
Comma 2005:2006
Str 2007:2057 T("collection count did not advance after gcCollect")
RParen 2057:2058
Newline 2058:2059
Ident 2063:2069 text="assert"
LParen 2069:2070
Ident 2070:2080 text="bytesAfter"
Lt 2081:2082
Number 2083:2087 text="4096" suf="" isf=0 int=4096
Comma 2087:2088
Str 2089:2140 T("bytes-since-GC exceeded the threshold we just set")
RParen 2140:2141
Newline 2141:2142
Ident 2146:2152 text="assert"
LParen 2152:2153
Ident 2153:2156 text="len"
LParen 2156:2157
Ident 2157:2161 text="keep"
RParen 2161:2162
EqEq 2163:2165
Number 2166:2168 text="33" suf="" isf=0 int=33
Comma 2168:2169
Str 2170:2216 T("surviving list was damaged by the collection")
RParen 2216:2217
Newline 2217:2218
Newline 2218:2219
Newline 2290:2291
Ident 2295:2302 text="println"
LParen 2302:2303
Str 2303:2314 T("list len:")
Comma 2314:2315
Ident 2316:2319 text="len"
LParen 2319:2320
Ident 2320:2324 text="keep"
RParen 2324:2325
RParen 2325:2326
Newline 2326:2327
Ident 2331:2338 text="println"
LParen 2338:2339
Str 2339:2349 T("keep[0]:")
Comma 2349:2350
Ident 2351:2355 text="keep"
LBracket 2355:2356
Number 2356:2357 text="0" suf="" isf=0 int=0
RBracket 2357:2358
Comma 2358:2359
Str 2360:2372 T(" keep[31]:")
Comma 2372:2373
Ident 2374:2378 text="keep"
LBracket 2378:2379
Number 2379:2381 text="31" suf="" isf=0 int=31
RBracket 2381:2382
RParen 2382:2383
Newline 2383:2384
RBrace 2384:2385
Eof 2385:2385
