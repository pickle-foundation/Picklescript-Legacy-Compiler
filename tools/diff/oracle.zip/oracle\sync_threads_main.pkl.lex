Newline 75:76
Newline 155:156
Newline 236:237
Newline 239:240
Newline 314:315
Newline 389:390
Newline 469:470
Newline 535:536
Newline 538:539
Newline 611:612
Newline 690:691
Newline 766:767
Newline 841:842
Newline 919:920
Newline 998:999
Newline 1076:1077
Newline 1108:1109
Newline 1111:1112
Newline 1190:1191
Newline 1269:1270
Newline 1346:1347
Newline 1390:1391
Newline 1393:1394
Newline 1465:1466
Newline 1466:1467
Import 1467:1473
LBrace 1474:1475
Ident 1476:1490 text="abiThreadCount"
RBrace 1491:1492
From 1493:1497
Ident 1498:1505 text="runtime"
Dot 1505:1506
Ident 1506:1517 text="abi_threads"
Newline 1517:1518
Newline 1518:1519
Fn 1519:1521
Ident 1522:1526 text="main"
LParen 1526:1527
RParen 1527:1528
LBrace 1529:1530
Newline 1530:1531
Ident 1535:1542 text="println"
LParen 1542:1543
Ident 1543:1555 text="thread_count"
LParen 1555:1556
RParen 1556:1557
RParen 1557:1558
Newline 1558:1559
Ident 1563:1570 text="println"
LParen 1570:1571
Ident 1571:1586 text="thread_finished"
LParen 1586:1587
Number 1587:1588 text="0" suf="" isf=0 int=0
RParen 1588:1589
RParen 1589:1590
Newline 1590:1591
Ident 1595:1602 text="println"
LParen 1602:1603
Ident 1603:1618 text="thread_finished"
LParen 1618:1619
Number 1619:1622 text="999" suf="" isf=0 int=999
RParen 1622:1623
RParen 1623:1624
Newline 1624:1625
Let 1629:1632
Ident 1633:1634 text="m"
Assign 1635:1636
Ident 1637:1651 text="thread_message"
LParen 1651:1652
Number 1652:1653 text="0" suf="" isf=0 int=0
RParen 1653:1654
Newline 1654:1655
If 1659:1661
LParen 1662:1663
Let 1663:1666
Ident 1667:1671 text="some"
LParen 1671:1672
Ident 1672:1674 text="_m"
RParen 1674:1675
Assign 1676:1677
Ident 1678:1679 text="m"
RParen 1679:1680
LBrace 1681:1682
Newline 1682:1683
Ident 1691:1698 text="println"
LParen 1698:1699
Str 1699:1709 T("msg=some")
RParen 1709:1710
Newline 1710:1711
RBrace 1715:1716
Else 1717:1721
LBrace 1722:1723
Newline 1723:1724
Ident 1732:1739 text="println"
LParen 1739:1740
Str 1740:1750 T("msg=null")
RParen 1750:1751
Newline 1751:1752
RBrace 1756:1757
Newline 1757:1758
Ident 1762:1770 text="sleep_ms"
LParen 1770:1771
Number 1771:1772 text="7" suf="" isf=0 int=7
RParen 1772:1773
Newline 1773:1774
Ident 1778:1785 text="println"
LParen 1785:1786
Str 1786:1793 T("slept")
RParen 1793:1794
Newline 1794:1795
Ident 1799:1811 text="thread_yield"
LParen 1811:1812
RParen 1812:1813
Newline 1813:1814
Ident 1818:1825 text="println"
LParen 1825:1826
Str 1826:1835 T("yielded")
RParen 1835:1836
Newline 1836:1837
Ident 1841:1848 text="println"
LParen 1848:1849
Str 1849:1861 T("threads ok")
RParen 1861:1862
Newline 1862:1863
RBrace 1863:1864
Eof 1864:1864
