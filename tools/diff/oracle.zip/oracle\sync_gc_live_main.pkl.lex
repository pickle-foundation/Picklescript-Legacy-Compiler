Newline 74:75
Newline 151:152
Newline 230:231
Newline 303:304
Newline 376:377
Newline 379:380
Newline 454:455
Newline 530:531
Newline 604:605
Newline 654:655
Newline 655:656
Import 656:662
LBrace 663:664
Ident 665:677 text="abiGcCollect"
RBrace 678:679
From 680:684
Ident 685:692 text="runtime"
Dot 692:693
Ident 693:699 text="abi_gc"
Newline 699:700
Import 700:706
LBrace 707:708
Ident 709:727 text="abiRegisteredCount"
Comma 727:728
Ident 729:747 text="abiRegisteredBytes"
RBrace 748:749
From 750:754
Ident 755:762 text="runtime"
Dot 762:763
Ident 763:770 text="abi_raw"
Newline 770:771
Import 771:777
LBrace 778:779
Ident 780:787 text="listNew"
Comma 787:788
Ident 789:800 text="abiListPush"
RBrace 801:802
From 803:807
Ident 808:815 text="runtime"
Dot 815:816
Ident 816:824 text="abi_list"
Newline 824:825
Import 825:831
LBrace 832:833
Ident 834:843 text="abiBoxI64"
RBrace 844:845
From 846:850
Ident 851:858 text="runtime"
Dot 858:859
Ident 859:866 text="abi_box"
Newline 866:867
Newline 867:868
Fn 868:870
Ident 871:875 text="main"
LParen 875:876
RParen 876:877
LBrace 878:879
Newline 879:880
Var 884:887
Ident 888:890 text="c0"
Assign 891:892
Ident 893:911 text="abiRegisteredCount"
LParen 911:912
RParen 912:913
Newline 913:914
Var 918:921
Ident 922:924 text="b0"
Assign 925:926
Ident 927:945 text="abiRegisteredBytes"
LParen 945:946
RParen 946:947
Newline 947:948
Var 952:955
Ident 956:959 text="all"
Assign 960:961
Ident 962:969 text="listNew"
LParen 969:970
Number 970:971 text="0" suf="" isf=0 int=0
RParen 971:972
Newline 972:973
Ident 977:988 text="abiListPush"
LParen 988:989
Ident 989:992 text="all"
Comma 992:993
Ident 994:1003 text="abiBoxI64"
LParen 1003:1004
Number 1004:1006 text="11" suf="" isf=0 int=11
RParen 1006:1007
RParen 1007:1008
Newline 1008:1009
Ident 1013:1024 text="abiListPush"
LParen 1024:1025
Ident 1025:1028 text="all"
Comma 1028:1029
Ident 1030:1039 text="abiBoxI64"
LParen 1039:1040
Number 1040:1042 text="22" suf="" isf=0 int=22
RParen 1042:1043
RParen 1043:1044
Newline 1044:1045
Var 1049:1052
Ident 1053:1055 text="c1"
Assign 1056:1057
Ident 1058:1076 text="abiRegisteredCount"
LParen 1076:1077
RParen 1077:1078
Newline 1078:1079
Var 1083:1086
Ident 1087:1089 text="b1"
Assign 1090:1091
Ident 1092:1110 text="abiRegisteredBytes"
LParen 1110:1111
RParen 1111:1112
Newline 1112:1113
Var 1117:1120
Ident 1121:1124 text="dc1"
Assign 1125:1126
Ident 1127:1129 text="c1"
Minus 1130:1131
Ident 1132:1134 text="c0"
Newline 1134:1135
Var 1139:1142
Ident 1143:1146 text="db1"
Assign 1147:1148
Ident 1149:1151 text="b1"
Minus 1152:1153
Ident 1154:1156 text="b0"
Newline 1156:1157
Ident 1161:1168 text="println"
LParen 1168:1169
Str 1169:1200 T("made: count ") E[Ident 1183:1186 text="dc1"; Eof 1187:1187] T(" bytes ") E[Ident 1195:1198 text="db1"; Eof 1199:1199]
RParen 1200:1201
Newline 1201:1202
Ident 1206:1218 text="abiGcCollect"
LParen 1218:1219
True 1219:1223
RParen 1223:1224
Newline 1224:1225
Var 1229:1232
Ident 1233:1235 text="c2"
Assign 1236:1237
Ident 1238:1256 text="abiRegisteredCount"
LParen 1256:1257
RParen 1257:1258
Newline 1258:1259
Var 1263:1266
Ident 1267:1269 text="b2"
Assign 1270:1271
Ident 1272:1290 text="abiRegisteredBytes"
LParen 1290:1291
RParen 1291:1292
Newline 1292:1293
Var 1297:1300
Ident 1301:1304 text="dc2"
Assign 1305:1306
Ident 1307:1309 text="c2"
Minus 1310:1311
Ident 1312:1314 text="c0"
Newline 1314:1315
Var 1319:1322
Ident 1323:1326 text="db2"
Assign 1327:1328
Ident 1329:1331 text="b2"
Minus 1332:1333
Ident 1334:1336 text="b0"
Newline 1336:1337
Ident 1341:1348 text="println"
LParen 1348:1349
Str 1349:1394 T("live after collect: count ") E[Ident 1377:1380 text="dc2"; Eof 1381:1381] T(" bytes ") E[Ident 1389:1392 text="db2"; Eof 1393:1393]
RParen 1394:1395
Newline 1395:1396
Ident 1400:1412 text="abiGcCollect"
LParen 1412:1413
False 1413:1418
RParen 1418:1419
Newline 1419:1420
Var 1424:1427
Ident 1428:1430 text="c3"
Assign 1431:1432
Ident 1433:1451 text="abiRegisteredCount"
LParen 1451:1452
RParen 1452:1453
Newline 1453:1454
Var 1458:1461
Ident 1462:1464 text="b3"
Assign 1465:1466
Ident 1467:1485 text="abiRegisteredBytes"
LParen 1485:1486
RParen 1486:1487
Newline 1487:1488
Var 1492:1495
Ident 1496:1499 text="dc3"
Assign 1500:1501
Ident 1502:1504 text="c3"
Minus 1505:1506
Ident 1507:1509 text="c0"
Newline 1509:1510
Var 1514:1517
Ident 1518:1521 text="db3"
Assign 1522:1523
Ident 1524:1526 text="b3"
Minus 1527:1528
Ident 1529:1531 text="b0"
Newline 1531:1532
Ident 1536:1543 text="println"
LParen 1543:1544
Str 1544:1588 T("live after second: count ") E[Ident 1571:1574 text="dc3"; Eof 1575:1575] T(" bytes ") E[Ident 1583:1586 text="db3"; Eof 1587:1587]
RParen 1588:1589
Newline 1589:1590
Ident 1594:1601 text="println"
LParen 1601:1602
Str 1602:1620 T("registry seam ok")
RParen 1620:1621
Newline 1621:1622
RBrace 1622:1623
Eof 1623:1623
