Module 0:6
Ident 7:11 text="main"
Newline 11:12
Newline 12:13
Newline 93:94
Newline 173:174
Newline 251:252
Newline 307:308
Var 308:311
Ident 312:313 text="g"
Colon 313:314
Ident 315:318 text="int"
Assign 319:320
Number 321:322 text="1" suf="" isf=0 int=1
Newline 322:323
Var 323:326
Ident 327:336 text="untouched"
Colon 336:337
Ident 338:341 text="int"
Assign 342:343
Number 344:345 text="5" suf="" isf=0 int=5
Newline 345:346
Newline 346:347
Newline 425:426
Newline 485:486
Fn 486:488
Ident 489:501 text="writeThrough"
LParen 501:502
Ident 502:503 text="p"
Colon 503:504
Star 505:506
Ident 506:509 text="int"
Comma 509:510
Ident 511:512 text="v"
Colon 512:513
Ident 514:517 text="int"
RParen 517:518
LBrace 519:520
Newline 520:521
Unsafe 525:531
LBrace 532:533
Newline 533:534
Star 542:543
Ident 543:544 text="p"
Assign 545:546
Ident 547:548 text="v"
Newline 548:549
RBrace 553:554
Newline 554:555
RBrace 555:556
Newline 556:557
Newline 557:558
Fn 558:560
Ident 561:572 text="readThrough"
LParen 572:573
Ident 573:574 text="p"
Colon 574:575
Star 576:577
Ident 577:580 text="int"
RParen 580:581
Colon 581:582
Ident 583:586 text="int"
LBrace 587:588
Newline 588:589
Unsafe 593:599
LBrace 600:601
Newline 601:602
Return 610:616
Star 617:618
Ident 618:619 text="p"
Newline 619:620
RBrace 624:625
Newline 625:626
RBrace 626:627
Newline 627:628
Newline 628:629
Fn 629:631
Ident 632:636 text="bump"
LParen 636:637
Ident 637:638 text="p"
Colon 638:639
Star 640:641
Ident 641:644 text="int"
RParen 644:645
LBrace 646:647
Newline 647:648
Unsafe 652:658
LBrace 659:660
Newline 660:661
Star 669:670
Ident 670:671 text="p"
Assign 672:673
Star 674:675
Ident 675:676 text="p"
Plus 677:678
Number 679:681 text="10" suf="" isf=0 int=10
Newline 681:682
RBrace 686:687
Newline 687:688
RBrace 688:689
Newline 689:690
Newline 690:691
Fn 691:693
Ident 694:698 text="main"
LParen 698:699
RParen 699:700
LBrace 701:702
Newline 702:703
Unsafe 707:713
LBrace 714:715
Newline 715:716
Let 724:727
Ident 728:729 text="p"
Colon 729:730
Star 731:732
Ident 732:735 text="int"
Assign 736:737
Amp 738:739
Ident 739:740 text="g"
Newline 740:741
Ident 749:761 text="writeThrough"
LParen 761:762
Ident 762:763 text="p"
Comma 763:764
Number 765:767 text="99" suf="" isf=0 int=99
RParen 767:768
Newline 768:769
Ident 777:784 text="println"
LParen 784:785
Str 785:806 T("after writeThrough:")
Comma 806:807
Ident 808:809 text="g"
RParen 809:810
Newline 810:811
Ident 819:825 text="assert"
LParen 825:826
Ident 826:827 text="g"
EqEq 828:830
Number 831:833 text="99" suf="" isf=0 int=99
Comma 833:834
Str 835:885 T("a write through &global did not reach the global")
RParen 885:886
Newline 886:887
Newline 887:888
Ident 896:903 text="println"
LParen 903:904
Str 904:918 T("readThrough:")
Comma 918:919
Ident 920:931 text="readThrough"
LParen 931:932
Ident 932:933 text="p"
RParen 933:934
RParen 934:935
Newline 935:936
Ident 944:950 text="assert"
LParen 950:951
Ident 951:962 text="readThrough"
LParen 962:963
Ident 963:964 text="p"
RParen 964:965
EqEq 966:968
Number 969:971 text="99" suf="" isf=0 int=99
Comma 971:972
Str 973:1020 T("a read through &global did not see the global")
RParen 1020:1021
Newline 1021:1022
Newline 1022:1023
Newline 1100:1101
Newline 1153:1154
Ident 1162:1166 text="bump"
LParen 1166:1167
Ident 1167:1168 text="p"
RParen 1168:1169
Newline 1169:1170
Ident 1178:1185 text="println"
LParen 1185:1186
Str 1186:1199 T("after bump:")
Comma 1199:1200
Ident 1201:1202 text="g"
RParen 1202:1203
Newline 1203:1204
Ident 1212:1218 text="assert"
LParen 1218:1219
Ident 1219:1220 text="g"
EqEq 1221:1223
Number 1224:1227 text="109" suf="" isf=0 int=109
Comma 1227:1228
Str 1229:1283 T("read-modify-write through &global lost the old value")
RParen 1283:1284
Newline 1284:1285
RBrace 1289:1290
Newline 1290:1291
Newline 1291:1292
Newline 1368:1369
Newline 1437:1438
Ident 1442:1449 text="println"
LParen 1449:1450
Str 1450:1467 T("outside unsafe:")
Comma 1467:1468
Ident 1469:1470 text="g"
RParen 1470:1471
Newline 1471:1472
Ident 1476:1482 text="assert"
LParen 1482:1483
Ident 1483:1484 text="g"
EqEq 1485:1487
Number 1488:1491 text="109" suf="" isf=0 int=109
Comma 1491:1492
Str 1493:1554 T("the global did not retain the value written via its address")
RParen 1554:1555
Newline 1555:1556
Newline 1556:1557
Newline 1638:1639
Ident 1643:1650 text="println"
LParen 1650:1651
Str 1651:1663 T("untouched:")
Comma 1663:1664
Ident 1665:1674 text="untouched"
RParen 1674:1675
Newline 1675:1676
Ident 1680:1686 text="assert"
LParen 1686:1687
Ident 1687:1696 text="untouched"
EqEq 1697:1699
Number 1700:1701 text="5" suf="" isf=0 int=5
Comma 1701:1702
Str 1703:1744 T("taking &g disturbed an unrelated global")
RParen 1744:1745
Newline 1745:1746
Newline 1746:1747
Newline 1817:1818
Ident 1822:1823 text="g"
Assign 1824:1825
Number 1826:1827 text="7" suf="" isf=0 int=7
Newline 1827:1828
Ident 1832:1839 text="println"
LParen 1839:1840
Str 1840:1862 T("after direct assign:")
Comma 1862:1863
Ident 1864:1865 text="g"
RParen 1865:1866
Newline 1866:1867
Ident 1871:1877 text="assert"
LParen 1877:1878
Ident 1878:1879 text="g"
EqEq 1880:1882
Number 1883:1884 text="7" suf="" isf=0 int=7
Comma 1884:1885
Str 1886:1929 T("direct assignment to the global regressed")
RParen 1929:1930
Newline 1930:1931
Newline 1931:1932
Unsafe 1936:1942
LBrace 1943:1944
Newline 1944:1945
Let 1953:1956
Ident 1957:1959 text="p2"
Colon 1959:1960
Star 1961:1962
Ident 1962:1965 text="int"
Assign 1966:1967
Amp 1968:1969
Ident 1969:1970 text="g"
Newline 1970:1971
Ident 1979:1991 text="writeThrough"
LParen 1991:1992
Ident 1992:1994 text="p2"
Comma 1994:1995
Ident 1996:2007 text="readThrough"
LParen 2007:2008
Ident 2008:2010 text="p2"
RParen 2010:2011
Plus 2012:2013
Number 2014:2015 text="1" suf="" isf=0 int=1
RParen 2015:2016
Newline 2016:2017
RBrace 2021:2022
Newline 2022:2023
Ident 2027:2034 text="println"
LParen 2034:2035
Str 2035:2043 T("final:")
Comma 2043:2044
Ident 2045:2046 text="g"
RParen 2046:2047
Newline 2047:2048
Ident 2052:2058 text="assert"
LParen 2058:2059
Ident 2059:2060 text="g"
EqEq 2061:2063
Number 2064:2065 text="8" suf="" isf=0 int=8
Comma 2065:2066
Str 2067:2106 T("the final pointer update did not land")
RParen 2106:2107
Newline 2107:2108
RBrace 2108:2109
Eof 2109:2109
