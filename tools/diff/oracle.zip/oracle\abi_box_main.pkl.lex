Module 0:6
Ident 7:19 text="abi_box_main"
Newline 19:20
Newline 20:21
Newline 93:94
Newline 96:97
Newline 182:183
Newline 269:270
Newline 357:358
Newline 446:447
Newline 525:526
Newline 560:561
Newline 561:562
Import 562:568
LBrace 569:570
Ident 571:580 text="abiBoxI64"
Comma 580:581
Ident 582:593 text="abiUnboxI64"
Comma 593:594
Ident 595:605 text="abiBoxBool"
Comma 605:606
Ident 607:619 text="abiUnboxBool"
Comma 619:620
Ident 621:631 text="abiBoxChar"
Comma 631:632
Ident 633:645 text="abiUnboxChar"
Comma 645:646
Ident 647:658 text="abiUnboxF64"
Comma 658:659
Ident 660:666 text="newBox"
Comma 666:667
Ident 668:675 text="boxBits"
RBrace 676:677
From 678:682
Ident 683:690 text="runtime"
Dot 690:691
Ident 691:698 text="abi_box"
Newline 698:699
Import 699:705
LBrace 706:707
Ident 708:730 text="PICKLE_CLASS_BOX_FLOAT"
RBrace 731:732
From 733:737
Ident 738:745 text="runtime"
Dot 745:746
Ident 746:752 text="object"
Newline 752:753
Newline 753:754
Fn 754:756
Ident 757:761 text="main"
LParen 761:762
RParen 762:763
LBrace 764:765
Newline 765:766
Newline 831:832
Ident 836:843 text="println"
LParen 843:844
Str 844:895 T("i64 neg: ") E[Ident 855:866 text="abiUnboxI64"; LParen 866:867; Ident 867:876 text="abiBoxI64"; LParen 876:877; Minus 877:878; Number 878:891 text="1234567890123" suf="" isf=0 int=1234567890123; RParen 891:892; RParen 892:893; Eof 894:894]
RParen 895:896
Newline 896:897
Ident 901:908 text="println"
LParen 908:909
Str 909:948 T("i64 zero: ") E[Ident 921:932 text="abiUnboxI64"; LParen 932:933; Ident 933:942 text="abiBoxI64"; LParen 942:943; Number 943:944 text="0" suf="" isf=0 int=0; RParen 944:945; RParen 945:946; Eof 947:947]
RParen 948:949
Newline 949:950
Ident 954:961 text="println"
LParen 961:962
Str 962:1018 T("i64 max: ") E[Ident 973:984 text="abiUnboxI64"; LParen 984:985; Ident 985:994 text="abiBoxI64"; LParen 994:995; Number 995:1014 text="9223372036854775807" suf="" isf=0 int=9223372036854775807; RParen 1014:1015; RParen 1015:1016; Eof 1017:1017]
RParen 1018:1019
Newline 1019:1020
Ident 1024:1031 text="println"
LParen 1031:1032
Str 1032:1077 T("bool true: ") E[Ident 1045:1057 text="abiUnboxBool"; LParen 1057:1058; Ident 1058:1068 text="abiBoxBool"; LParen 1068:1069; True 1069:1073; RParen 1073:1074; RParen 1074:1075; Eof 1076:1076]
RParen 1077:1078
Newline 1078:1079
Ident 1083:1090 text="println"
LParen 1090:1091
Str 1091:1138 T("bool false: ") E[Ident 1105:1117 text="abiUnboxBool"; LParen 1117:1118; Ident 1118:1128 text="abiBoxBool"; LParen 1128:1129; False 1129:1134; RParen 1134:1135; RParen 1135:1136; Eof 1137:1137]
RParen 1138:1139
Newline 1139:1140
Ident 1144:1151 text="println"
LParen 1151:1152
Str 1152:1192 T("char A: ") E[Ident 1162:1174 text="abiUnboxChar"; LParen 1174:1175; Ident 1175:1185 text="abiBoxChar"; LParen 1185:1186; Number 1186:1188 text="65" suf="" isf=0 int=65; RParen 1188:1189; RParen 1189:1190; Eof 1191:1191]
RParen 1192:1193
Newline 1193:1194
Newline 1194:1195
Newline 1279:1280
Newline 1363:1364
Newline 1446:1447
Newline 1522:1523
Var 1527:1530
Ident 1531:1533 text="xs"
Assign 1534:1535
LBracket 1536:1537
Number 1537:1538 text="1" suf="" isf=0 int=1
Comma 1538:1539
Number 1540:1541 text="2" suf="" isf=0 int=2
Comma 1541:1542
Number 1543:1544 text="3" suf="" isf=0 int=3
RBracket 1544:1545
Newline 1545:1546
Ident 1550:1552 text="xs"
Dot 1552:1553
Ident 1553:1557 text="push"
LParen 1557:1558
Number 1558:1559 text="4" suf="" isf=0 int=4
RParen 1559:1560
Newline 1560:1561
Var 1565:1568
Ident 1569:1574 text="total"
Assign 1575:1576
Number 1577:1578 text="0" suf="" isf=0 int=0
Newline 1578:1579
Var 1583:1586
Ident 1587:1588 text="i"
Assign 1589:1590
Number 1591:1592 text="0" suf="" isf=0 int=0
Newline 1592:1593
While 1597:1602
LParen 1603:1604
Ident 1604:1605 text="i"
Lt 1606:1607
Ident 1608:1611 text="len"
LParen 1611:1612
Ident 1612:1614 text="xs"
RParen 1614:1615
RParen 1615:1616
LBrace 1617:1618
Newline 1618:1619
Ident 1627:1632 text="total"
Assign 1633:1634
Ident 1635:1640 text="total"
Plus 1641:1642
Ident 1643:1645 text="xs"
LBracket 1645:1646
Ident 1646:1647 text="i"
RBracket 1647:1648
Newline 1648:1649
Ident 1657:1658 text="i"
Assign 1659:1660
Ident 1661:1662 text="i"
Plus 1663:1664
Number 1665:1666 text="1" suf="" isf=0 int=1
Newline 1666:1667
RBrace 1671:1672
Newline 1672:1673
Ident 1677:1684 text="println"
LParen 1684:1685
Str 1685:1704 T("list sum: ") E[Ident 1697:1702 text="total"; Eof 1703:1703]
RParen 1704:1705
Newline 1705:1706
Newline 1706:1707
Newline 1765:1766
Var 1770:1773
Ident 1774:1779 text="flags"
Assign 1780:1781
LBracket 1782:1783
True 1783:1787
Comma 1787:1788
False 1789:1794
Comma 1794:1795
True 1796:1800
RBracket 1800:1801
Newline 1801:1802
Var 1806:1809
Ident 1810:1815 text="trues"
Assign 1816:1817
Number 1818:1819 text="0" suf="" isf=0 int=0
Newline 1819:1820
Var 1824:1827
Ident 1828:1829 text="j"
Assign 1830:1831
Number 1832:1833 text="0" suf="" isf=0 int=0
Newline 1833:1834
While 1838:1843
LParen 1844:1845
Ident 1845:1846 text="j"
Lt 1847:1848
Ident 1849:1852 text="len"
LParen 1852:1853
Ident 1853:1858 text="flags"
RParen 1858:1859
RParen 1859:1860
LBrace 1861:1862
Newline 1862:1863
If 1871:1873
LParen 1874:1875
Ident 1875:1880 text="flags"
LBracket 1880:1881
Ident 1881:1882 text="j"
RBracket 1882:1883
RParen 1883:1884
LBrace 1885:1886
Newline 1886:1887
Ident 1899:1904 text="trues"
Assign 1905:1906
Ident 1907:1912 text="trues"
Plus 1913:1914
Number 1915:1916 text="1" suf="" isf=0 int=1
Newline 1916:1917
RBrace 1925:1926
Newline 1926:1927
Ident 1935:1936 text="j"
Assign 1937:1938
Ident 1939:1940 text="j"
Plus 1941:1942
Number 1943:1944 text="1" suf="" isf=0 int=1
Newline 1944:1945
RBrace 1949:1950
Newline 1950:1951
Ident 1955:1962 text="println"
LParen 1962:1963
Str 1963:1984 T("true flags: ") E[Ident 1977:1982 text="trues"; Eof 1983:1983]
RParen 1984:1985
Newline 1985:1986
Newline 1986:1987
Newline 2072:2073
Newline 2156:2157
Newline 2243:2244
Newline 2327:2328
Newline 2384:2385
Let 2389:2392
Ident 2393:2397 text="fbox"
Assign 2398:2399
Ident 2400:2406 text="newBox"
LParen 2406:2407
Ident 2407:2429 text="PICKLE_CLASS_BOX_FLOAT"
Comma 2429:2430
Number 2431:2450 text="4609434218613702656" suf="" isf=0 int=4609434218613702656
RParen 2450:2451
Newline 2451:2452
Ident 2456:2463 text="println"
LParen 2463:2464
Str 2464:2500 T("float 1.5 payload: ") E[Ident 2485:2492 text="boxBits"; LParen 2492:2493; Ident 2493:2497 text="fbox"; RParen 2497:2498; Eof 2499:2499]
RParen 2500:2501
Newline 2501:2502
Ident 2506:2513 text="println"
LParen 2513:2514
Str 2514:2550 T("float unboxed: ") E[Ident 2531:2542 text="abiUnboxF64"; LParen 2542:2543; Ident 2543:2547 text="fbox"; RParen 2547:2548; Eof 2549:2549]
RParen 2550:2551
Newline 2551:2552
Ident 2556:2563 text="println"
LParen 2563:2564
Str 2564:2643 T("float 0.5: ") E[Ident 2577:2588 text="abiUnboxF64"; LParen 2588:2589; Ident 2589:2595 text="newBox"; LParen 2595:2596; Ident 2596:2618 text="PICKLE_CLASS_BOX_FLOAT"; Comma 2618:2619; Number 2620:2639 text="4602678819172646912" suf="" isf=0 int=4602678819172646912; RParen 2639:2640; RParen 2640:2641; Eof 2642:2642]
RParen 2643:2644
Newline 2644:2645
Ident 2649:2656 text="println"
LParen 2656:2657
Str 2657:2738 T("float -2.0: ") E[Ident 2671:2682 text="abiUnboxF64"; LParen 2682:2683; Ident 2683:2689 text="newBox"; LParen 2689:2690; Ident 2690:2712 text="PICKLE_CLASS_BOX_FLOAT"; Comma 2712:2713; Minus 2714:2715; Number 2715:2734 text="4611686018427387904" suf="" isf=0 int=4611686018427387904; RParen 2734:2735; RParen 2735:2736; Eof 2737:2737]
RParen 2738:2739
Newline 2739:2740
Ident 2744:2751 text="println"
LParen 2751:2752
Str 2752:2832 T("float +inf: ") E[Ident 2766:2777 text="abiUnboxF64"; LParen 2777:2778; Ident 2778:2784 text="newBox"; LParen 2784:2785; Ident 2785:2807 text="PICKLE_CLASS_BOX_FLOAT"; Comma 2807:2808; Number 2809:2828 text="9218868437227405312" suf="" isf=0 int=9218868437227405312; RParen 2828:2829; RParen 2829:2830; Eof 2831:2831]
RParen 2832:2833
Newline 2833:2834
Ident 2838:2845 text="println"
LParen 2845:2846
Str 2846:2924 T("float -inf: ") E[Ident 2860:2871 text="abiUnboxF64"; LParen 2871:2872; Ident 2872:2878 text="newBox"; LParen 2878:2879; Ident 2879:2901 text="PICKLE_CLASS_BOX_FLOAT"; Comma 2901:2902; Minus 2903:2904; Number 2904:2920 text="4503599627370496" suf="" isf=0 int=4503599627370496; RParen 2920:2921; RParen 2921:2922; Eof 2923:2923]
RParen 2924:2925
Newline 2925:2926
Ident 2930:2937 text="println"
LParen 2937:2938
Str 2938:3009 T("float min subnormal: ") E[Ident 2961:2972 text="abiUnboxF64"; LParen 2972:2973; Ident 2973:2979 text="newBox"; LParen 2979:2980; Ident 2980:3002 text="PICKLE_CLASS_BOX_FLOAT"; Comma 3002:3003; Number 3004:3005 text="1" suf="" isf=0 int=1; RParen 3005:3006; RParen 3006:3007; Eof 3008:3008]
RParen 3009:3010
Newline 3010:3011
Ident 3015:3022 text="println"
LParen 3022:3023
Str 3023:3102 T("float max: ") E[Ident 3036:3047 text="abiUnboxF64"; LParen 3047:3048; Ident 3048:3054 text="newBox"; LParen 3054:3055; Ident 3055:3077 text="PICKLE_CLASS_BOX_FLOAT"; Comma 3077:3078; Number 3079:3098 text="9218868437227405311" suf="" isf=0 int=9218868437227405311; RParen 3098:3099; RParen 3099:3100; Eof 3101:3101]
RParen 3102:3103
Newline 3103:3104
Let 3108:3111
Ident 3112:3118 text="nanbox"
Assign 3119:3120
Ident 3121:3127 text="newBox"
LParen 3127:3128
Ident 3128:3150 text="PICKLE_CLASS_BOX_FLOAT"
Comma 3150:3151
Number 3152:3171 text="9221120237041090560" suf="" isf=0 int=9221120237041090560
RParen 3171:3172
Newline 3172:3173
Let 3177:3180
Ident 3181:3184 text="nan"
Assign 3185:3186
Ident 3187:3198 text="abiUnboxF64"
LParen 3198:3199
Ident 3199:3205 text="nanbox"
RParen 3205:3206
Newline 3206:3207
Ident 3211:3218 text="println"
LParen 3218:3219
Str 3219:3257 T("float nan self-unequal: ") E[Ident 3245:3248 text="nan"; NotEq 3249:3251; Ident 3252:3255 text="nan"; Eof 3256:3256]
RParen 3257:3258
Newline 3258:3259
Ident 3263:3270 text="println"
LParen 3270:3271
Str 3271:3342 T("float nan payload preserved: ") E[Ident 3302:3309 text="boxBits"; LParen 3309:3310; Ident 3310:3316 text="nanbox"; RParen 3316:3317; EqEq 3318:3320; Number 3321:3340 text="9221120237041090560" suf="" isf=0 int=9221120237041090560; Eof 3341:3341]
RParen 3342:3343
Newline 3343:3344
RBrace 3344:3345
Eof 3345:3345
