Module 0:6
Ident 7:21 text="exception_test"
Newline 21:22
Newline 22:23
Newline 96:97
Newline 170:171
Newline 197:198
Class 198:203
Ident 204:207 text="Log"
LBrace 208:209
Newline 209:210
Var 214:217
Ident 218:219 text="s"
Colon 219:220
Ident 221:227 text="string"
Assign 228:229
Str 230:232
Newline 232:233
RBrace 233:234
Newline 234:235
Newline 235:236
Fn 236:238
Ident 239:243 text="note"
LParen 243:244
Ident 244:245 text="l"
Colon 245:246
Ident 247:250 text="Log"
Comma 250:251
Ident 252:253 text="x"
Colon 253:254
Ident 255:261 text="string"
RParen 261:262
LBrace 263:264
Newline 264:265
Ident 269:270 text="l"
Dot 270:271
Ident 271:272 text="s"
Assign 273:274
Ident 275:276 text="l"
Dot 276:277
Ident 277:278 text="s"
Plus 279:280
Ident 281:282 text="x"
Plus 283:284
Str 285:288 T(";")
Newline 288:289
RBrace 289:290
Newline 290:291
Newline 291:292
Newline 366:367
Newline 409:410
Fn 410:412
Ident 413:418 text="id_fn"
Lt 418:419
Ident 419:420 text="T"
Gt 420:421
LParen 421:422
Ident 422:423 text="x"
Colon 423:424
Ident 425:426 text="T"
RParen 426:427
Arrow 428:430
Ident 431:432 text="T"
LBrace 433:434
Newline 434:435
Return 439:445
Ident 446:447 text="x"
Newline 447:448
RBrace 448:449
Newline 449:450
Newline 450:451
Fn 451:453
Ident 454:458 text="boom"
LParen 458:459
RParen 459:460
LBrace 461:462
Newline 462:463
Throw 467:472
Str 473:479 T("boom")
Newline 479:480
RBrace 480:481
Newline 481:482
Newline 482:483
Fn 483:485
Ident 486:493 text="guarded"
LParen 493:494
RParen 494:495
Arrow 496:498
Ident 499:505 text="string"
LBrace 506:507
Newline 507:508
Try 512:515
LBrace 516:517
Newline 517:518
Ident 526:530 text="boom"
LParen 530:531
RParen 531:532
Newline 532:533
Str 541:554 T("unreachable")
Newline 554:555
RBrace 559:560
Catch 561:566
LParen 567:568
Ident 568:569 text="e"
RParen 569:570
LBrace 571:572
Newline 572:573
Str 581:590 T("caught ")
Plus 591:592
Ident 593:594 text="e"
Newline 594:595
RBrace 599:600
Newline 600:601
RBrace 601:602
Newline 602:603
Newline 603:604
Newline 682:683
Newline 700:701
Fn 701:703
Ident 704:715 text="throws_here"
LParen 715:716
RParen 716:717
LBrace 718:719
Newline 719:720
Throw 724:729
Str 730:736 T("deep")
Newline 736:737
RBrace 737:738
Newline 738:739
Newline 739:740
Fn 740:742
Ident 743:750 text="escapes"
LParen 750:751
RParen 751:752
Arrow 753:755
Ident 756:762 text="string"
LBrace 763:764
Newline 764:765
Try 769:772
LBrace 773:774
Newline 774:775
Ident 783:794 text="throws_here"
LParen 794:795
RParen 795:796
Newline 796:797
Str 805:818 T("unreachable")
Newline 818:819
RBrace 823:824
Catch 825:830
LParen 831:832
Ident 832:833 text="e"
RParen 833:834
LBrace 835:836
Newline 836:837
Str 845:853 T("outer ")
Plus 854:855
Ident 856:857 text="e"
Newline 857:858
RBrace 862:863
Newline 863:864
RBrace 864:865
Newline 865:866
Newline 866:867
Newline 945:946
Newline 1016:1017
Fn 1017:1019
Ident 1020:1032 text="finally_only"
LParen 1032:1033
Ident 1033:1034 text="l"
Colon 1034:1035
Ident 1036:1039 text="Log"
RParen 1039:1040
Arrow 1041:1043
Ident 1044:1050 text="string"
LBrace 1051:1052
Newline 1052:1053
Try 1057:1060
LBrace 1061:1062
Newline 1062:1063
Ident 1071:1075 text="boom"
LParen 1075:1076
RParen 1076:1077
Newline 1077:1078
Str 1086:1099 T("unreachable")
Newline 1099:1100
RBrace 1104:1105
Finally 1106:1113
LBrace 1114:1115
Newline 1115:1116
Ident 1124:1128 text="note"
LParen 1128:1129
Ident 1129:1130 text="l"
Comma 1130:1131
Str 1132:1137 T("fin")
RParen 1137:1138
Newline 1138:1139
RBrace 1143:1144
Newline 1144:1145
Str 1149:1156 T("after")
Newline 1156:1157
RBrace 1157:1158
Newline 1158:1159
Newline 1159:1160
Fn 1160:1162
Ident 1163:1182 text="finally_only_caught"
LParen 1182:1183
Ident 1183:1184 text="l"
Colon 1184:1185
Ident 1186:1189 text="Log"
RParen 1189:1190
Arrow 1191:1193
Ident 1194:1200 text="string"
LBrace 1201:1202
Newline 1202:1203
Try 1207:1210
LBrace 1211:1212
Newline 1212:1213
Ident 1221:1233 text="finally_only"
LParen 1233:1234
Ident 1234:1235 text="l"
RParen 1235:1236
Newline 1236:1237
Str 1245:1255 T("no throw")
Newline 1255:1256
RBrace 1260:1261
Catch 1262:1267
LParen 1268:1269
Ident 1269:1270 text="e"
RParen 1270:1271
LBrace 1272:1273
Newline 1273:1274
Str 1282:1288 T("got ")
Plus 1289:1290
Ident 1291:1292 text="e"
Newline 1292:1293
RBrace 1297:1298
Newline 1298:1299
RBrace 1299:1300
Newline 1300:1301
Newline 1301:1302
Fn 1302:1304
Ident 1305:1324 text="ret_through_finally"
LParen 1324:1325
Ident 1325:1326 text="l"
Colon 1326:1327
Ident 1328:1331 text="Log"
Comma 1331:1332
Ident 1333:1334 text="n"
Colon 1334:1335
Ident 1336:1339 text="int"
RParen 1339:1340
Arrow 1341:1343
Ident 1344:1350 text="string"
LBrace 1351:1352
Newline 1352:1353
Try 1357:1360
LBrace 1361:1362
Newline 1362:1363
If 1371:1373
LParen 1374:1375
Ident 1375:1376 text="n"
Gt 1377:1378
Number 1379:1380 text="0" suf="" isf=0 int=0
RParen 1380:1381
LBrace 1382:1383
Newline 1383:1384
Return 1396:1402
Str 1403:1408 T("pos")
Newline 1408:1409
RBrace 1417:1418
Newline 1418:1419
Str 1427:1435 T("nonpos")
Newline 1435:1436
RBrace 1440:1441
Finally 1442:1449
LBrace 1450:1451
Newline 1451:1452
Ident 1460:1464 text="note"
LParen 1464:1465
Ident 1465:1466 text="l"
Comma 1466:1467
Str 1468:1473 T("ret")
RParen 1473:1474
Newline 1474:1475
RBrace 1479:1480
Newline 1480:1481
RBrace 1481:1482
Newline 1482:1483
Newline 1483:1484
Fn 1484:1486
Ident 1487:1499 text="nested_throw"
LParen 1499:1500
Ident 1500:1501 text="l"
Colon 1501:1502
Ident 1503:1506 text="Log"
RParen 1506:1507
Arrow 1508:1510
Ident 1511:1517 text="string"
LBrace 1518:1519
Newline 1519:1520
Try 1524:1527
LBrace 1528:1529
Newline 1529:1530
Try 1538:1541
LBrace 1542:1543
Newline 1543:1544
Throw 1556:1561
Str 1562:1569 T("inner")
Newline 1569:1570
RBrace 1578:1579
Finally 1580:1587
LBrace 1588:1589
Newline 1589:1590
Ident 1602:1606 text="note"
LParen 1606:1607
Ident 1607:1608 text="l"
Comma 1608:1609
Str 1610:1620 T("innerfin")
RParen 1620:1621
Newline 1621:1622
RBrace 1630:1631
Newline 1631:1632
RBrace 1636:1637
Catch 1638:1643
LParen 1644:1645
Ident 1645:1646 text="e"
RParen 1646:1647
LBrace 1648:1649
Newline 1649:1650
Str 1658:1666 T("outer ")
Plus 1667:1668
Ident 1669:1670 text="e"
Newline 1670:1671
RBrace 1675:1676
Newline 1676:1677
RBrace 1677:1678
Newline 1678:1679
Newline 1679:1680
Newline 1727:1728
Fn 1728:1730
Ident 1731:1741 text="bare_catch"
LParen 1741:1742
RParen 1742:1743
Arrow 1744:1746
Ident 1747:1753 text="string"
LBrace 1754:1755
Newline 1755:1756
Try 1760:1763
LBrace 1764:1765
Newline 1765:1766
Throw 1774:1779
Str 1780:1789 T("ignored")
Newline 1789:1790
RBrace 1794:1795
Catch 1796:1801
LBrace 1802:1803
Newline 1803:1804
Str 1812:1818 T("bare")
Newline 1818:1819
RBrace 1823:1824
Newline 1824:1825
RBrace 1825:1826
Newline 1826:1827
Newline 1827:1828
Newline 1905:1906
Fn 1906:1908
Ident 1909:1923 text="handler_throws"
LParen 1923:1924
RParen 1924:1925
Arrow 1926:1928
Ident 1929:1935 text="string"
LBrace 1936:1937
Newline 1937:1938
Try 1942:1945
LBrace 1946:1947
Newline 1947:1948
Try 1956:1959
LBrace 1960:1961
Newline 1961:1962
Throw 1974:1979
Str 1980:1987 T("first")
Newline 1987:1988
RBrace 1996:1997
Catch 1998:2003
LBrace 2004:2005
Newline 2005:2006
Throw 2018:2023
Str 2024:2032 T("second")
Newline 2032:2033
RBrace 2041:2042
Newline 2042:2043
RBrace 2047:2048
Catch 2049:2054
LParen 2055:2056
Ident 2056:2057 text="e"
RParen 2057:2058
LBrace 2059:2060
Newline 2060:2061
Str 2069:2075 T("got ")
Plus 2076:2077
Ident 2078:2079 text="e"
Newline 2079:2080
RBrace 2084:2085
Newline 2085:2086
RBrace 2086:2087
Newline 2087:2088
Newline 2088:2089
Newline 2157:2158
Fn 2158:2160
Ident 2161:2172 text="two_finalys"
LParen 2172:2173
Ident 2173:2174 text="l"
Colon 2174:2175
Ident 2176:2179 text="Log"
RParen 2179:2180
Arrow 2181:2183
Ident 2184:2190 text="string"
LBrace 2191:2192
Newline 2192:2193
Try 2197:2200
LBrace 2201:2202
Newline 2202:2203
Try 2211:2214
LBrace 2215:2216
Newline 2216:2217
Return 2229:2235
Str 2236:2241 T("ret")
Newline 2241:2242
RBrace 2250:2251
Finally 2252:2259
LBrace 2260:2261
Newline 2261:2262
Ident 2274:2278 text="note"
LParen 2278:2279
Ident 2279:2280 text="l"
Comma 2280:2281
Str 2282:2286 T("f2")
RParen 2286:2287
Newline 2287:2288
RBrace 2296:2297
Newline 2297:2298
RBrace 2302:2303
Finally 2304:2311
LBrace 2312:2313
Newline 2313:2314
Ident 2322:2326 text="note"
LParen 2326:2327
Ident 2327:2328 text="l"
Comma 2328:2329
Str 2330:2334 T("f1")
RParen 2334:2335
Newline 2335:2336
RBrace 2340:2341
Newline 2341:2342
RBrace 2342:2343
Newline 2343:2344
Newline 2344:2345
Fn 2345:2347
Ident 2348:2369 text="break_through_finally"
LParen 2369:2370
Ident 2370:2371 text="l"
Colon 2371:2372
Ident 2373:2376 text="Log"
RParen 2376:2377
Arrow 2378:2380
Ident 2381:2387 text="string"
LBrace 2388:2389
Newline 2389:2390
While 2394:2399
LParen 2400:2401
True 2401:2405
RParen 2405:2406
LBrace 2407:2408
Newline 2408:2409
Try 2417:2420
LBrace 2421:2422
Newline 2422:2423
Break 2435:2440
Newline 2440:2441
RBrace 2449:2450
Finally 2451:2458
LBrace 2459:2460
Newline 2460:2461
Ident 2473:2477 text="note"
LParen 2477:2478
Ident 2478:2479 text="l"
Comma 2479:2480
Str 2481:2486 T("brk")
RParen 2486:2487
Newline 2487:2488
RBrace 2496:2497
Newline 2497:2498
RBrace 2502:2503
Newline 2503:2504
Str 2508:2514 T("done")
Newline 2514:2515
RBrace 2515:2516
Newline 2516:2517
Newline 2517:2518
Fn 2518:2520
Ident 2521:2545 text="continue_through_finally"
LParen 2545:2546
Ident 2546:2547 text="l"
Colon 2547:2548
Ident 2549:2552 text="Log"
RParen 2552:2553
Arrow 2554:2556
Ident 2557:2560 text="int"
LBrace 2561:2562
Newline 2562:2563
Var 2567:2570
Ident 2571:2572 text="n"
Colon 2572:2573
Ident 2574:2577 text="int"
Assign 2578:2579
Number 2580:2581 text="0" suf="" isf=0 int=0
Newline 2581:2582
For 2586:2589
LParen 2590:2591
Ident 2591:2592 text="i"
In 2593:2595
Number 2596:2597 text="0" suf="" isf=0 int=0
Range 2597:2599
Number 2599:2600 text="3" suf="" isf=0 int=3
RParen 2600:2601
LBrace 2602:2603
Newline 2603:2604
Try 2612:2615
LBrace 2616:2617
Newline 2617:2618
If 2630:2632
LParen 2633:2634
Ident 2634:2635 text="i"
EqEq 2636:2638
Number 2639:2640 text="1" suf="" isf=0 int=1
RParen 2640:2641
LBrace 2642:2643
Newline 2643:2644
Continue 2660:2668
Newline 2668:2669
RBrace 2681:2682
Newline 2682:2683
Ident 2695:2696 text="n"
Assign 2697:2698
Ident 2699:2700 text="n"
Plus 2701:2702
Number 2703:2705 text="10" suf="" isf=0 int=10
Newline 2705:2706
RBrace 2714:2715
Finally 2716:2723
LBrace 2724:2725
Newline 2725:2726
Ident 2738:2742 text="note"
LParen 2742:2743
Ident 2743:2744 text="l"
Comma 2744:2745
Str 2746:2749 T("c")
RParen 2749:2750
Newline 2750:2751
RBrace 2759:2760
Newline 2760:2761
RBrace 2765:2766
Newline 2766:2767
Ident 2771:2772 text="n"
Newline 2772:2773
RBrace 2773:2774
Newline 2774:2775
Newline 2775:2776
Class 2776:2781
Ident 2782:2789 text="Thrower"
LBrace 2790:2791
Newline 2791:2792
Var 2796:2799
Ident 2800:2803 text="tag"
Colon 2803:2804
Ident 2805:2811 text="string"
Newline 2811:2812
Constructor 2816:2827
LParen 2827:2828
Ident 2828:2831 text="tag"
Colon 2831:2832
Ident 2833:2839 text="string"
RParen 2839:2840
LBrace 2841:2842
Newline 2842:2843
This 2851:2855
Dot 2855:2856
Ident 2856:2859 text="tag"
Assign 2860:2861
Ident 2862:2865 text="tag"
Newline 2865:2866
RBrace 2870:2871
Newline 2871:2872
Fn 2876:2878
Get 2879:2882
LParen 2882:2883
RParen 2883:2884
Arrow 2885:2887
Ident 2888:2894 text="string"
LBrace 2895:2896
Newline 2896:2897
Throw 2905:2910
This 2911:2915
Dot 2915:2916
Ident 2916:2919 text="tag"
Newline 2919:2920
RBrace 2924:2925
Newline 2925:2926
RBrace 2926:2927
Newline 2927:2928
Newline 2928:2929
Fn 2929:2931
Ident 2932:2945 text="method_throws"
LParen 2945:2946
Ident 2946:2947 text="t"
Colon 2947:2948
Ident 2949:2956 text="Thrower"
RParen 2956:2957
Arrow 2958:2960
Ident 2961:2967 text="string"
LBrace 2968:2969
Newline 2969:2970
Try 2974:2977
LBrace 2978:2979
Newline 2979:2980
Ident 2988:2989 text="t"
Dot 2989:2990
Get 2990:2993
LParen 2993:2994
RParen 2994:2995
Newline 2995:2996
Str 3004:3017 T("unreachable")
Newline 3017:3018
RBrace 3022:3023
Catch 3024:3029
LParen 3030:3031
Ident 3031:3032 text="e"
RParen 3032:3033
LBrace 3034:3035
Newline 3035:3036
Str 3044:3053 T("method ")
Plus 3054:3055
Ident 3056:3057 text="e"
Newline 3057:3058
RBrace 3062:3063
Newline 3063:3064
RBrace 3064:3065
Newline 3065:3066
Newline 3066:3067
Fn 3067:3069
Ident 3070:3083 text="generic_throw"
Lt 3083:3084
Ident 3084:3085 text="T"
Gt 3085:3086
LParen 3086:3087
Ident 3087:3088 text="v"
Colon 3088:3089
Ident 3090:3091 text="T"
RParen 3091:3092
Arrow 3093:3095
Ident 3096:3097 text="T"
LBrace 3098:3099
Newline 3099:3100
Throw 3104:3109
Str 3110:3115 T("gen")
Newline 3115:3116
RBrace 3116:3117
Newline 3117:3118
Newline 3118:3119
Fn 3119:3121
Ident 3122:3135 text="calls_generic"
LParen 3135:3136
RParen 3136:3137
Arrow 3138:3140
Ident 3141:3147 text="string"
LBrace 3148:3149
Newline 3149:3150
Try 3154:3157
LBrace 3158:3159
Newline 3159:3160
Ident 3168:3181 text="generic_throw"
Lt 3181:3182
Ident 3182:3185 text="int"
Gt 3185:3186
LParen 3186:3187
Number 3187:3188 text="1" suf="" isf=0 int=1
RParen 3188:3189
Newline 3189:3190
Str 3198:3211 T("unreachable")
Newline 3211:3212
RBrace 3216:3217
Catch 3218:3223
LParen 3224:3225
Ident 3225:3226 text="e"
RParen 3226:3227
LBrace 3228:3229
Newline 3229:3230
Str 3238:3248 T("generic ")
Plus 3249:3250
Ident 3251:3252 text="e"
Newline 3252:3253
RBrace 3257:3258
Newline 3258:3259
RBrace 3259:3260
Newline 3260:3261
Newline 3261:3262
Newline 3338:3339
Newline 3370:3371
Fn 3371:3373
Ident 3374:3382 text="repeated"
LParen 3382:3383
RParen 3383:3384
Arrow 3385:3387
Ident 3388:3394 text="string"
LBrace 3395:3396
Newline 3396:3397
Var 3401:3404
Ident 3405:3408 text="out"
Colon 3408:3409
Ident 3410:3416 text="string"
Assign 3417:3418
Str 3419:3421
Newline 3421:3422
Var 3426:3429
Ident 3430:3431 text="i"
Colon 3431:3432
Ident 3433:3436 text="int"
Assign 3437:3438
Number 3439:3440 text="0" suf="" isf=0 int=0
Newline 3440:3441
While 3445:3450
LParen 3451:3452
Ident 3452:3453 text="i"
Lt 3454:3455
Number 3456:3457 text="3" suf="" isf=0 int=3
RParen 3457:3458
LBrace 3459:3460
Newline 3460:3461
Try 3469:3472
LBrace 3473:3474
Newline 3474:3475
Throw 3487:3492
Str 3493:3496 T("p")
Newline 3496:3497
RBrace 3505:3506
Catch 3507:3512
LParen 3513:3514
Ident 3514:3515 text="e"
RParen 3515:3516
LBrace 3517:3518
Newline 3518:3519
Ident 3531:3534 text="out"
Assign 3535:3536
Ident 3537:3540 text="out"
Plus 3541:3542
Ident 3543:3544 text="e"
Newline 3544:3545
RBrace 3553:3554
Newline 3554:3555
Ident 3563:3564 text="i"
Assign 3565:3566
Ident 3567:3568 text="i"
Plus 3569:3570
Number 3571:3572 text="1" suf="" isf=0 int=1
Newline 3572:3573
RBrace 3577:3578
Newline 3578:3579
Ident 3583:3586 text="out"
Newline 3586:3587
RBrace 3587:3588
Newline 3588:3589
Newline 3589:3590
Newline 3653:3654
Fn 3654:3656
Ident 3657:3671 text="throws_at_tail"
LParen 3671:3672
RParen 3672:3673
Arrow 3674:3676
Ident 3677:3683 text="string"
LBrace 3684:3685
Newline 3685:3686
Throw 3690:3695
Str 3696:3702 T("tail")
Newline 3702:3703
RBrace 3703:3704
Newline 3704:3705
Newline 3705:3706
Fn 3706:3708
Ident 3709:3725 text="tail_is_uncaught"
LParen 3725:3726
RParen 3726:3727
Arrow 3728:3730
Ident 3731:3737 text="string"
LBrace 3738:3739
Newline 3739:3740
Try 3744:3747
LBrace 3748:3749
Newline 3749:3750
Ident 3758:3772 text="throws_at_tail"
LParen 3772:3773
RParen 3773:3774
Newline 3774:3775
Str 3783:3796 T("unreachable")
Newline 3796:3797
RBrace 3801:3802
Catch 3803:3808
LParen 3809:3810
Ident 3810:3811 text="e"
RParen 3811:3812
LBrace 3813:3814
Newline 3814:3815
Str 3823:3830 T("tail ")
Plus 3831:3832
Ident 3833:3834 text="e"
Newline 3834:3835
RBrace 3839:3840
Newline 3840:3841
RBrace 3841:3842
Newline 3842:3843
Newline 3843:3844
Ident 3844:3848 text="test"
Fn 3849:3851
Ident 3852:3893 text="a_local_throw_is_caught_in_the_same_frame"
LParen 3893:3894
RParen 3894:3895
LBrace 3896:3897
Newline 3897:3898
Ident 3902:3908 text="expect"
LParen 3908:3909
Ident 3909:3914 text="id_fn"
Lt 3914:3915
Ident 3915:3921 text="string"
Gt 3921:3922
LParen 3922:3923
Ident 3923:3930 text="guarded"
LParen 3930:3931
RParen 3931:3932
RParen 3932:3933
RParen 3933:3934
Dot 3934:3935
Ident 3935:3939 text="toBe"
LParen 3939:3940
Str 3940:3953 T("caught boom")
RParen 3953:3954
Newline 3954:3955
RBrace 3955:3956
Newline 3956:3957
Newline 3957:3958
Ident 3958:3962 text="test"
Fn 3963:3965
Ident 3966:4001 text="a_throw_crosses_a_function_boundary"
LParen 4001:4002
RParen 4002:4003
LBrace 4004:4005
Newline 4005:4006
Ident 4010:4016 text="expect"
LParen 4016:4017
Ident 4017:4022 text="id_fn"
Lt 4022:4023
Ident 4023:4029 text="string"
Gt 4029:4030
LParen 4030:4031
Ident 4031:4038 text="escapes"
LParen 4038:4039
RParen 4039:4040
RParen 4040:4041
RParen 4041:4042
Dot 4042:4043
Ident 4043:4047 text="toBe"
LParen 4047:4048
Str 4048:4060 T("outer deep")
RParen 4060:4061
Newline 4061:4062
RBrace 4062:4063
Newline 4063:4064
Newline 4064:4065
Newline 4139:4140
Fn 4140:4142
Ident 4143:4152 text="swallowed"
LParen 4152:4153
RParen 4153:4154
Arrow 4155:4157
Ident 4158:4164 text="string"
LBrace 4165:4166
Newline 4166:4167
Try 4171:4174
LBrace 4175:4176
Newline 4176:4177
Ident 4185:4196 text="throws_here"
LParen 4196:4197
RParen 4197:4198
Newline 4198:4199
Str 4207:4220 T("unreachable")
Newline 4220:4221
RBrace 4225:4226
Catch 4227:4232
LParen 4233:4234
Ident 4234:4235 text="e"
RParen 4235:4236
LBrace 4237:4238
Newline 4238:4239
Str 4247:4257 T("handled ")
Plus 4258:4259
Ident 4260:4261 text="e"
Newline 4261:4262
RBrace 4266:4267
Newline 4267:4268
RBrace 4268:4269
Newline 4269:4270
Newline 4270:4271
Newline 4346:4347
Newline 4421:4422
Newline 4474:4475
Fn 4475:4477
Ident 4478:4496 text="catch_then_finally"
LParen 4496:4497
Ident 4497:4498 text="l"
Colon 4498:4499
Ident 4500:4503 text="Log"
RParen 4503:4504
Arrow 4505:4507
Ident 4508:4514 text="string"
LBrace 4515:4516
Newline 4516:4517
Try 4521:4524
LBrace 4525:4526
Newline 4526:4527
Ident 4535:4539 text="note"
LParen 4539:4540
Ident 4540:4541 text="l"
Comma 4541:4542
Str 4543:4549 T("body")
RParen 4549:4550
Newline 4550:4551
Throw 4559:4564
Str 4565:4569 T("tf")
Newline 4569:4570
RBrace 4574:4575
Catch 4576:4581
LParen 4582:4583
Ident 4583:4584 text="e"
RParen 4584:4585
LBrace 4586:4587
Newline 4587:4588
Ident 4596:4600 text="note"
LParen 4600:4601
Ident 4601:4602 text="l"
Comma 4602:4603
Str 4604:4611 T("catch")
RParen 4611:4612
Newline 4612:4613
Str 4621:4631 T("handled ")
Plus 4632:4633
Ident 4634:4635 text="e"
Newline 4635:4636
RBrace 4640:4641
Finally 4642:4649
LBrace 4650:4651
Newline 4651:4652
Ident 4660:4664 text="note"
LParen 4664:4665
Ident 4665:4666 text="l"
Comma 4666:4667
Str 4668:4673 T("fin")
RParen 4673:4674
Newline 4674:4675
RBrace 4679:4680
Newline 4680:4681
RBrace 4681:4682
Newline 4682:4683
Newline 4683:4684
Newline 4764:4765
Newline 4838:4839
Fn 4839:4841
Ident 4842:4868 text="catch_then_finally_by_call"
LParen 4868:4869
Ident 4869:4870 text="l"
Colon 4870:4871
Ident 4872:4875 text="Log"
RParen 4875:4876
Arrow 4877:4879
Ident 4880:4886 text="string"
LBrace 4887:4888
Newline 4888:4889
Try 4893:4896
LBrace 4897:4898
Newline 4898:4899
Ident 4907:4911 text="note"
LParen 4911:4912
Ident 4912:4913 text="l"
Comma 4913:4914
Str 4915:4921 T("body")
RParen 4921:4922
Newline 4922:4923
Ident 4931:4942 text="throws_here"
LParen 4942:4943
RParen 4943:4944
Newline 4944:4945
RBrace 4949:4950
Catch 4951:4956
LParen 4957:4958
Ident 4958:4959 text="e"
RParen 4959:4960
LBrace 4961:4962
Newline 4962:4963
Ident 4971:4975 text="note"
LParen 4975:4976
Ident 4976:4977 text="l"
Comma 4977:4978
Str 4979:4986 T("catch")
RParen 4986:4987
Newline 4987:4988
Str 4996:5006 T("handled ")
Plus 5007:5008
Ident 5009:5010 text="e"
Newline 5010:5011
RBrace 5015:5016
Finally 5017:5024
LBrace 5025:5026
Newline 5026:5027
Ident 5035:5039 text="note"
LParen 5039:5040
Ident 5040:5041 text="l"
Comma 5041:5042
Str 5043:5048 T("fin")
RParen 5048:5049
Newline 5049:5050
RBrace 5054:5055
Newline 5055:5056
RBrace 5056:5057
Newline 5057:5058
Newline 5058:5059
Newline 5141:5142
Newline 5190:5191
Fn 5191:5193
Ident 5194:5226 text="inner_finally_before_outer_catch"
LParen 5226:5227
Ident 5227:5228 text="l"
Colon 5228:5229
Ident 5230:5233 text="Log"
RParen 5233:5234
Arrow 5235:5237
Ident 5238:5244 text="string"
LBrace 5245:5246
Newline 5246:5247
Try 5251:5254
LBrace 5255:5256
Newline 5256:5257
Try 5265:5268
LBrace 5269:5270
Newline 5270:5271
Ident 5283:5287 text="note"
LParen 5287:5288
Ident 5288:5289 text="l"
Comma 5289:5290
Str 5291:5297 T("body")
RParen 5297:5298
Newline 5298:5299
Throw 5311:5316
Str 5317:5321 T("io")
Newline 5321:5322
RBrace 5330:5331
Finally 5332:5339
LBrace 5340:5341
Newline 5341:5342
Ident 5354:5358 text="note"
LParen 5358:5359
Ident 5359:5360 text="l"
Comma 5360:5361
Str 5362:5369 T("inner")
RParen 5369:5370
Newline 5370:5371
RBrace 5379:5380
Newline 5380:5381
RBrace 5385:5386
Catch 5387:5392
LParen 5393:5394
Ident 5394:5395 text="e"
RParen 5395:5396
LBrace 5397:5398
Newline 5398:5399
Ident 5407:5411 text="note"
LParen 5411:5412
Ident 5412:5413 text="l"
Comma 5413:5414
Str 5415:5422 T("catch")
RParen 5422:5423
Newline 5423:5424
Str 5432:5442 T("handled ")
Plus 5443:5444
Ident 5445:5446 text="e"
Newline 5446:5447
RBrace 5451:5452
Newline 5452:5453
RBrace 5453:5454
Newline 5454:5455
Newline 5455:5456
Newline 5536:5537
Newline 5615:5616
Newline 5679:5680
Fn 5680:5682
Ident 5683:5718 text="catchless_inner_keeps_outer_handler"
LParen 5718:5719
Ident 5719:5720 text="l"
Colon 5720:5721
Ident 5722:5725 text="Log"
RParen 5725:5726
Arrow 5727:5729
Ident 5730:5736 text="string"
LBrace 5737:5738
Newline 5738:5739
Try 5743:5746
LBrace 5747:5748
Newline 5748:5749
Try 5757:5760
LBrace 5761:5762
Newline 5762:5763
Ident 5775:5779 text="note"
LParen 5779:5780
Ident 5780:5781 text="l"
Comma 5781:5782
Str 5783:5790 T("inner")
RParen 5790:5791
Newline 5791:5792
RBrace 5800:5801
Finally 5802:5809
LBrace 5810:5811
Newline 5811:5812
Ident 5824:5828 text="note"
LParen 5828:5829
Ident 5829:5830 text="l"
Comma 5830:5831
Str 5832:5836 T("f1")
RParen 5836:5837
Newline 5837:5838
RBrace 5846:5847
Newline 5847:5848
Ident 5856:5860 text="note"
LParen 5860:5861
Ident 5861:5862 text="l"
Comma 5862:5863
Str 5864:5877 T("after-inner")
RParen 5877:5878
Newline 5878:5879
Throw 5887:5892
Str 5893:5899 T("keep")
Newline 5899:5900
RBrace 5904:5905
Catch 5906:5911
LParen 5912:5913
Ident 5913:5914 text="e"
RParen 5914:5915
LBrace 5916:5917
Newline 5917:5918
Str 5926:5936 T("handled ")
Plus 5937:5938
Ident 5939:5940 text="e"
Newline 5940:5941
RBrace 5945:5946
Newline 5946:5947
RBrace 5947:5948
Newline 5948:5949
Newline 5949:5950
Newline 6027:6028
Newline 6048:6049
Fn 6049:6051
Ident 6052:6071 text="three_inner_finalys"
LParen 6071:6072
Ident 6072:6073 text="l"
Colon 6073:6074
Ident 6075:6078 text="Log"
RParen 6078:6079
Arrow 6080:6082
Ident 6083:6089 text="string"
LBrace 6090:6091
Newline 6091:6092
Try 6096:6099
LBrace 6100:6101
Newline 6101:6102
Try 6110:6113
LBrace 6114:6115
Newline 6115:6116
Try 6128:6131
LBrace 6132:6133
Newline 6133:6134
Throw 6150:6155
Str 6156:6162 T("deep")
Newline 6162:6163
RBrace 6175:6176
Finally 6177:6184
LBrace 6185:6186
Newline 6186:6187
Ident 6203:6207 text="note"
LParen 6207:6208
Ident 6208:6209 text="l"
Comma 6209:6210
Str 6211:6215 T("f3")
RParen 6215:6216
Newline 6216:6217
RBrace 6229:6230
Newline 6230:6231
RBrace 6239:6240
Finally 6241:6248
LBrace 6249:6250
Newline 6250:6251
Ident 6263:6267 text="note"
LParen 6267:6268
Ident 6268:6269 text="l"
Comma 6269:6270
Str 6271:6275 T("f2")
RParen 6275:6276
Newline 6276:6277
RBrace 6285:6286
Newline 6286:6287
RBrace 6291:6292
Catch 6293:6298
LParen 6299:6300
Ident 6300:6301 text="e"
RParen 6301:6302
LBrace 6303:6304
Newline 6304:6305
Ident 6313:6317 text="note"
LParen 6317:6318
Ident 6318:6319 text="l"
Comma 6319:6320
Str 6321:6328 T("catch")
RParen 6328:6329
Newline 6329:6330
Str 6338:6348 T("handled ")
Plus 6349:6350
Ident 6351:6352 text="e"
Newline 6352:6353
RBrace 6357:6358
Finally 6359:6366
LBrace 6367:6368
Newline 6368:6369
Ident 6377:6381 text="note"
LParen 6381:6382
Ident 6382:6383 text="l"
Comma 6383:6384
Str 6385:6389 T("f1")
RParen 6389:6390
Newline 6390:6391
RBrace 6395:6396
Newline 6396:6397
RBrace 6397:6398
Newline 6398:6399
Newline 6399:6400
Ident 6400:6404 text="test"
Fn 6405:6407
Ident 6408:6469 text="a_direct_throw_with_catch_and_finally_runs_catch_then_finally"
LParen 6469:6470
RParen 6470:6471
LBrace 6472:6473
Newline 6473:6474
Let 6478:6481
Ident 6482:6483 text="l"
Assign 6484:6485
Ident 6486:6489 text="Log"
LParen 6489:6490
RParen 6490:6491
Newline 6491:6492
Ident 6496:6502 text="expect"
LParen 6502:6503
Ident 6503:6508 text="id_fn"
Lt 6508:6509
Ident 6509:6515 text="string"
Gt 6515:6516
LParen 6516:6517
Ident 6517:6535 text="catch_then_finally"
LParen 6535:6536
Ident 6536:6537 text="l"
RParen 6537:6538
RParen 6538:6539
RParen 6539:6540
Dot 6540:6541
Ident 6541:6545 text="toBe"
LParen 6545:6546
Str 6546:6558 T("handled tf")
RParen 6558:6559
Newline 6559:6560
Ident 6564:6570 text="expect"
LParen 6570:6571
Ident 6571:6572 text="l"
Dot 6572:6573
Ident 6573:6574 text="s"
RParen 6574:6575
Dot 6575:6576
Ident 6576:6580 text="toBe"
LParen 6580:6581
Str 6581:6598 T("body;catch;fin;")
RParen 6598:6599
Newline 6599:6600
RBrace 6600:6601
Newline 6601:6602
Newline 6602:6603
Ident 6603:6607 text="test"
Fn 6608:6610
Ident 6611:6670 text="a_call_throw_with_catch_and_finally_runs_catch_then_finally"
LParen 6670:6671
RParen 6671:6672
LBrace 6673:6674
Newline 6674:6675
Let 6679:6682
Ident 6683:6684 text="l"
Assign 6685:6686
Ident 6687:6690 text="Log"
LParen 6690:6691
RParen 6691:6692
Newline 6692:6693
Ident 6697:6703 text="expect"
LParen 6703:6704
Ident 6704:6709 text="id_fn"
Lt 6709:6710
Ident 6710:6716 text="string"
Gt 6716:6717
LParen 6717:6718
Ident 6718:6744 text="catch_then_finally_by_call"
LParen 6744:6745
Ident 6745:6746 text="l"
RParen 6746:6747
RParen 6747:6748
RParen 6748:6749
Dot 6749:6750
Ident 6750:6754 text="toBe"
LParen 6754:6755
Str 6755:6769 T("handled deep")
RParen 6769:6770
Newline 6770:6771
Ident 6775:6781 text="expect"
LParen 6781:6782
Ident 6782:6783 text="l"
Dot 6783:6784
Ident 6784:6785 text="s"
RParen 6785:6786
Dot 6786:6787
Ident 6787:6791 text="toBe"
LParen 6791:6792
Str 6792:6809 T("body;catch;fin;")
RParen 6809:6810
Newline 6810:6811
RBrace 6811:6812
Newline 6812:6813
Newline 6813:6814
Ident 6814:6818 text="test"
Fn 6819:6821
Ident 6822:6866 text="an_inner_finally_runs_before_the_outer_catch"
LParen 6866:6867
RParen 6867:6868
LBrace 6869:6870
Newline 6870:6871
Let 6875:6878
Ident 6879:6880 text="l"
Assign 6881:6882
Ident 6883:6886 text="Log"
LParen 6886:6887
RParen 6887:6888
Newline 6888:6889
Ident 6893:6899 text="expect"
LParen 6899:6900
Ident 6900:6905 text="id_fn"
Lt 6905:6906
Ident 6906:6912 text="string"
Gt 6912:6913
LParen 6913:6914
Ident 6914:6946 text="inner_finally_before_outer_catch"
LParen 6946:6947
Ident 6947:6948 text="l"
RParen 6948:6949
RParen 6949:6950
RParen 6950:6951
Dot 6951:6952
Ident 6952:6956 text="toBe"
LParen 6956:6957
Str 6957:6969 T("handled io")
RParen 6969:6970
Newline 6970:6971
Ident 6975:6981 text="expect"
LParen 6981:6982
Ident 6982:6983 text="l"
Dot 6983:6984
Ident 6984:6985 text="s"
RParen 6985:6986
Dot 6986:6987
Ident 6987:6991 text="toBe"
LParen 6991:6992
Str 6992:7011 T("body;inner;catch;")
RParen 7011:7012
Newline 7012:7013
RBrace 7013:7014
Newline 7014:7015
Newline 7015:7016
Ident 7016:7020 text="test"
Fn 7021:7023
Ident 7024:7080 text="a_catchless_inner_try_does_not_consume_the_outer_handler"
LParen 7080:7081
RParen 7081:7082
LBrace 7083:7084
Newline 7084:7085
Let 7089:7092
Ident 7093:7094 text="l"
Assign 7095:7096
Ident 7097:7100 text="Log"
LParen 7100:7101
RParen 7101:7102
Newline 7102:7103
Ident 7107:7113 text="expect"
LParen 7113:7114
Ident 7114:7119 text="id_fn"
Lt 7119:7120
Ident 7120:7126 text="string"
Gt 7126:7127
LParen 7127:7128
Ident 7128:7163 text="catchless_inner_keeps_outer_handler"
LParen 7163:7164
Ident 7164:7165 text="l"
RParen 7165:7166
RParen 7166:7167
RParen 7167:7168
Dot 7168:7169
Ident 7169:7173 text="toBe"
LParen 7173:7174
Str 7174:7188 T("handled keep")
RParen 7188:7189
Newline 7189:7190
Ident 7194:7200 text="expect"
LParen 7200:7201
Ident 7201:7202 text="l"
Dot 7202:7203
Ident 7203:7204 text="s"
RParen 7204:7205
Dot 7205:7206
Ident 7206:7210 text="toBe"
LParen 7210:7211
Str 7211:7234 T("inner;f1;after-inner;")
RParen 7234:7235
Newline 7235:7236
RBrace 7236:7237
Newline 7237:7238
Newline 7238:7239
Ident 7239:7243 text="test"
Fn 7244:7246
Ident 7247:7292 text="every_inner_finally_runs_once_innermost_first"
LParen 7292:7293
RParen 7293:7294
LBrace 7295:7296
Newline 7296:7297
Let 7301:7304
Ident 7305:7306 text="l"
Assign 7307:7308
Ident 7309:7312 text="Log"
LParen 7312:7313
RParen 7313:7314
Newline 7314:7315
Ident 7319:7325 text="expect"
LParen 7325:7326
Ident 7326:7331 text="id_fn"
Lt 7331:7332
Ident 7332:7338 text="string"
Gt 7338:7339
LParen 7339:7340
Ident 7340:7359 text="three_inner_finalys"
LParen 7359:7360
Ident 7360:7361 text="l"
RParen 7361:7362
RParen 7362:7363
RParen 7363:7364
Dot 7364:7365
Ident 7365:7369 text="toBe"
LParen 7369:7370
Str 7370:7384 T("handled deep")
RParen 7384:7385
Newline 7385:7386
Ident 7390:7396 text="expect"
LParen 7396:7397
Ident 7397:7398 text="l"
Dot 7398:7399
Ident 7399:7400 text="s"
RParen 7400:7401
Dot 7401:7402
Ident 7402:7406 text="toBe"
LParen 7406:7407
Str 7407:7424 T("f3;f2;catch;f1;")
RParen 7424:7425
Newline 7425:7426
RBrace 7426:7427
Newline 7427:7428
Newline 7428:7429
Ident 7429:7433 text="test"
Fn 7434:7436
Ident 7437:7479 text="a_caught_throw_does_not_disturb_the_caller"
LParen 7479:7480
RParen 7480:7481
LBrace 7482:7483
Newline 7483:7484
Ident 7488:7494 text="expect"
LParen 7494:7495
Ident 7495:7500 text="id_fn"
Lt 7500:7501
Ident 7501:7507 text="string"
Gt 7507:7508
LParen 7508:7509
Ident 7509:7518 text="swallowed"
LParen 7518:7519
RParen 7519:7520
RParen 7520:7521
RParen 7521:7522
Dot 7522:7523
Ident 7523:7527 text="toBe"
LParen 7527:7528
Str 7528:7542 T("handled deep")
RParen 7542:7543
Newline 7543:7544
RBrace 7544:7545
Newline 7545:7546
Newline 7546:7547
Ident 7547:7551 text="test"
Fn 7552:7554
Ident 7555:7592 text="finally_runs_while_a_throw_propagates"
LParen 7592:7593
RParen 7593:7594
LBrace 7595:7596
Newline 7596:7597
Let 7601:7604
Ident 7605:7606 text="l"
Assign 7607:7608
Ident 7609:7612 text="Log"
LParen 7612:7613
RParen 7613:7614
Newline 7614:7615
Newline 7689:7690
Ident 7694:7700 text="expect"
LParen 7700:7701
Ident 7701:7706 text="id_fn"
Lt 7706:7707
Ident 7707:7713 text="string"
Gt 7713:7714
LParen 7714:7715
Ident 7715:7734 text="finally_only_caught"
LParen 7734:7735
Ident 7735:7736 text="l"
RParen 7736:7737
RParen 7737:7738
RParen 7738:7739
Dot 7739:7740
Ident 7740:7744 text="toBe"
LParen 7744:7745
Str 7745:7755 T("got boom")
RParen 7755:7756
Newline 7756:7757
Ident 7761:7767 text="expect"
LParen 7767:7768
Ident 7768:7769 text="l"
Dot 7769:7770
Ident 7770:7771 text="s"
RParen 7771:7772
Dot 7772:7773
Ident 7773:7777 text="toBe"
LParen 7777:7778
Str 7778:7784 T("fin;")
RParen 7784:7785
Newline 7785:7786
RBrace 7786:7787
Newline 7787:7788
Newline 7788:7789
Ident 7789:7793 text="test"
Fn 7794:7796
Ident 7797:7828 text="finally_runs_on_an_early_return"
LParen 7828:7829
RParen 7829:7830
LBrace 7831:7832
Newline 7832:7833
Let 7837:7840
Ident 7841:7842 text="l"
Assign 7843:7844
Ident 7845:7848 text="Log"
LParen 7848:7849
RParen 7849:7850
Newline 7850:7851
Ident 7855:7861 text="expect"
LParen 7861:7862
Ident 7862:7867 text="id_fn"
Lt 7867:7868
Ident 7868:7874 text="string"
Gt 7874:7875
LParen 7875:7876
Ident 7876:7895 text="ret_through_finally"
LParen 7895:7896
Ident 7896:7897 text="l"
Comma 7897:7898
Number 7899:7900 text="1" suf="" isf=0 int=1
RParen 7900:7901
RParen 7901:7902
RParen 7902:7903
Dot 7903:7904
Ident 7904:7908 text="toBe"
LParen 7908:7909
Str 7909:7914 T("pos")
RParen 7914:7915
Newline 7915:7916
Ident 7920:7926 text="expect"
LParen 7926:7927
Ident 7927:7928 text="l"
Dot 7928:7929
Ident 7929:7930 text="s"
RParen 7930:7931
Dot 7931:7932
Ident 7932:7936 text="toBe"
LParen 7936:7937
Str 7937:7943 T("ret;")
RParen 7943:7944
Newline 7944:7945
RBrace 7945:7946
Newline 7946:7947
Newline 7947:7948
Ident 7948:7952 text="test"
Fn 7953:7955
Ident 7956:7995 text="finally_runs_when_a_return_is_not_taken"
LParen 7995:7996
RParen 7996:7997
LBrace 7998:7999
Newline 7999:8000
Let 8004:8007
Ident 8008:8009 text="l"
Assign 8010:8011
Ident 8012:8015 text="Log"
LParen 8015:8016
RParen 8016:8017
Newline 8017:8018
Ident 8022:8028 text="expect"
LParen 8028:8029
Ident 8029:8034 text="id_fn"
Lt 8034:8035
Ident 8035:8041 text="string"
Gt 8041:8042
LParen 8042:8043
Ident 8043:8062 text="ret_through_finally"
LParen 8062:8063
Ident 8063:8064 text="l"
Comma 8064:8065
Number 8066:8067 text="0" suf="" isf=0 int=0
RParen 8067:8068
RParen 8068:8069
RParen 8069:8070
Dot 8070:8071
Ident 8071:8075 text="toBe"
LParen 8075:8076
Str 8076:8084 T("nonpos")
RParen 8084:8085
Newline 8085:8086
Ident 8090:8096 text="expect"
LParen 8096:8097
Ident 8097:8098 text="l"
Dot 8098:8099
Ident 8099:8100 text="s"
RParen 8100:8101
Dot 8101:8102
Ident 8102:8106 text="toBe"
LParen 8106:8107
Str 8107:8113 T("ret;")
RParen 8113:8114
Newline 8114:8115
RBrace 8115:8116
Newline 8116:8117
Newline 8117:8118
Ident 8118:8122 text="test"
Fn 8123:8125
Ident 8126:8169 text="an_inner_finally_runs_before_an_outer_catch"
LParen 8169:8170
RParen 8170:8171
LBrace 8172:8173
Newline 8173:8174
Let 8178:8181
Ident 8182:8183 text="l"
Assign 8184:8185
Ident 8186:8189 text="Log"
LParen 8189:8190
RParen 8190:8191
Newline 8191:8192
Ident 8196:8202 text="expect"
LParen 8202:8203
Ident 8203:8208 text="id_fn"
Lt 8208:8209
Ident 8209:8215 text="string"
Gt 8215:8216
LParen 8216:8217
Ident 8217:8229 text="nested_throw"
LParen 8229:8230
Ident 8230:8231 text="l"
RParen 8231:8232
RParen 8232:8233
RParen 8233:8234
Dot 8234:8235
Ident 8235:8239 text="toBe"
LParen 8239:8240
Str 8240:8253 T("outer inner")
RParen 8253:8254
Newline 8254:8255
Ident 8259:8265 text="expect"
LParen 8265:8266
Ident 8266:8267 text="l"
Dot 8267:8268
Ident 8268:8269 text="s"
RParen 8269:8270
Dot 8270:8271
Ident 8271:8275 text="toBe"
LParen 8275:8276
Str 8276:8287 T("innerfin;")
RParen 8287:8288
Newline 8288:8289
RBrace 8289:8290
Newline 8290:8291
Newline 8291:8292
Ident 8292:8296 text="test"
Fn 8297:8299
Ident 8300:8330 text="nested_finalys_run_inner_first"
LParen 8330:8331
RParen 8331:8332
LBrace 8333:8334
Newline 8334:8335
Let 8339:8342
Ident 8343:8344 text="l"
Assign 8345:8346
Ident 8347:8350 text="Log"
LParen 8350:8351
RParen 8351:8352
Newline 8352:8353
Ident 8357:8363 text="expect"
LParen 8363:8364
Ident 8364:8369 text="id_fn"
Lt 8369:8370
Ident 8370:8376 text="string"
Gt 8376:8377
LParen 8377:8378
Ident 8378:8389 text="two_finalys"
LParen 8389:8390
Ident 8390:8391 text="l"
RParen 8391:8392
RParen 8392:8393
RParen 8393:8394
Dot 8394:8395
Ident 8395:8399 text="toBe"
LParen 8399:8400
Str 8400:8405 T("ret")
RParen 8405:8406
Newline 8406:8407
Ident 8411:8417 text="expect"
LParen 8417:8418
Ident 8418:8419 text="l"
Dot 8419:8420
Ident 8420:8421 text="s"
RParen 8421:8422
Dot 8422:8423
Ident 8423:8427 text="toBe"
LParen 8427:8428
Str 8428:8436 T("f2;f1;")
RParen 8436:8437
Newline 8437:8438
RBrace 8438:8439
Newline 8439:8440
Newline 8440:8441
Ident 8441:8445 text="test"
Fn 8446:8448
Ident 8449:8485 text="a_bare_catch_catches_without_binding"
LParen 8485:8486
RParen 8486:8487
LBrace 8488:8489
Newline 8489:8490
Ident 8494:8500 text="expect"
LParen 8500:8501
Ident 8501:8506 text="id_fn"
Lt 8506:8507
Ident 8507:8513 text="string"
Gt 8513:8514
LParen 8514:8515
Ident 8515:8525 text="bare_catch"
LParen 8525:8526
RParen 8526:8527
RParen 8527:8528
RParen 8528:8529
Dot 8529:8530
Ident 8530:8534 text="toBe"
LParen 8534:8535
Str 8535:8541 T("bare")
RParen 8541:8542
Newline 8542:8543
RBrace 8543:8544
Newline 8544:8545
Newline 8545:8546
Ident 8546:8550 text="test"
Fn 8551:8553
Ident 8554:8597 text="a_throw_from_a_handler_replaces_the_payload"
LParen 8597:8598
RParen 8598:8599
LBrace 8600:8601
Newline 8601:8602
Ident 8606:8612 text="expect"
LParen 8612:8613
Ident 8613:8618 text="id_fn"
Lt 8618:8619
Ident 8619:8625 text="string"
Gt 8625:8626
LParen 8626:8627
Ident 8627:8641 text="handler_throws"
LParen 8641:8642
RParen 8642:8643
RParen 8643:8644
RParen 8644:8645
Dot 8645:8646
Ident 8646:8650 text="toBe"
LParen 8650:8651
Str 8651:8663 T("got second")
RParen 8663:8664
Newline 8664:8665
RBrace 8665:8666
Newline 8666:8667
Newline 8667:8668
Ident 8668:8672 text="test"
Fn 8673:8675
Ident 8676:8698 text="break_runs_the_finally"
LParen 8698:8699
RParen 8699:8700
LBrace 8701:8702
Newline 8702:8703
Let 8707:8710
Ident 8711:8712 text="l"
Assign 8713:8714
Ident 8715:8718 text="Log"
LParen 8718:8719
RParen 8719:8720
Newline 8720:8721
Ident 8725:8731 text="expect"
LParen 8731:8732
Ident 8732:8737 text="id_fn"
Lt 8737:8738
Ident 8738:8744 text="string"
Gt 8744:8745
LParen 8745:8746
Ident 8746:8767 text="break_through_finally"
LParen 8767:8768
Ident 8768:8769 text="l"
RParen 8769:8770
RParen 8770:8771
RParen 8771:8772
Dot 8772:8773
Ident 8773:8777 text="toBe"
LParen 8777:8778
Str 8778:8784 T("done")
RParen 8784:8785
Newline 8785:8786
Ident 8790:8796 text="expect"
LParen 8796:8797
Ident 8797:8798 text="l"
Dot 8798:8799
Ident 8799:8800 text="s"
RParen 8800:8801
Dot 8801:8802
Ident 8802:8806 text="toBe"
LParen 8806:8807
Str 8807:8813 T("brk;")
RParen 8813:8814
Newline 8814:8815
RBrace 8815:8816
Newline 8816:8817
Newline 8817:8818
Ident 8818:8822 text="test"
Fn 8823:8825
Ident 8826:8851 text="continue_runs_the_finally"
LParen 8851:8852
RParen 8852:8853
LBrace 8854:8855
Newline 8855:8856
Let 8860:8863
Ident 8864:8865 text="l"
Assign 8866:8867
Ident 8868:8871 text="Log"
LParen 8871:8872
RParen 8872:8873
Newline 8873:8874
Ident 8878:8884 text="expect"
LParen 8884:8885
Ident 8885:8890 text="id_fn"
Lt 8890:8891
Ident 8891:8894 text="int"
Gt 8894:8895
LParen 8895:8896
Ident 8896:8920 text="continue_through_finally"
LParen 8920:8921
Ident 8921:8922 text="l"
RParen 8922:8923
RParen 8923:8924
RParen 8924:8925
Dot 8925:8926
Ident 8926:8930 text="toBe"
LParen 8930:8931
Number 8931:8933 text="20" suf="" isf=0 int=20
RParen 8933:8934
Newline 8934:8935
Ident 8939:8945 text="expect"
LParen 8945:8946
Ident 8946:8947 text="l"
Dot 8947:8948
Ident 8948:8949 text="s"
RParen 8949:8950
Dot 8950:8951
Ident 8951:8955 text="toBe"
LParen 8955:8956
Str 8956:8964 T("c;c;c;")
RParen 8964:8965
Newline 8965:8966
RBrace 8966:8967
Newline 8967:8968
Newline 8968:8969
Ident 8969:8973 text="test"
Fn 8974:8976
Ident 8977:9009 text="a_method_can_throw_and_be_caught"
LParen 9009:9010
RParen 9010:9011
LBrace 9012:9013
Newline 9013:9014
Ident 9018:9024 text="expect"
LParen 9024:9025
Ident 9025:9030 text="id_fn"
Lt 9030:9031
Ident 9031:9037 text="string"
Gt 9037:9038
LParen 9038:9039
Ident 9039:9052 text="method_throws"
LParen 9052:9053
Ident 9053:9060 text="Thrower"
LParen 9060:9061
Str 9061:9065 T("mt")
RParen 9065:9066
RParen 9066:9067
RParen 9067:9068
RParen 9068:9069
Dot 9069:9070
Ident 9070:9074 text="toBe"
LParen 9074:9075
Str 9075:9086 T("method mt")
RParen 9086:9087
Newline 9087:9088
RBrace 9088:9089
Newline 9089:9090
Newline 9090:9091
Ident 9091:9095 text="test"
Fn 9096:9098
Ident 9099:9127 text="a_generic_function_can_throw"
LParen 9127:9128
RParen 9128:9129
LBrace 9130:9131
Newline 9131:9132
Ident 9136:9142 text="expect"
LParen 9142:9143
Ident 9143:9148 text="id_fn"
Lt 9148:9149
Ident 9149:9155 text="string"
Gt 9155:9156
LParen 9156:9157
Ident 9157:9170 text="calls_generic"
LParen 9170:9171
RParen 9171:9172
RParen 9172:9173
RParen 9173:9174
Dot 9174:9175
Ident 9175:9179 text="toBe"
LParen 9179:9180
Str 9180:9193 T("generic gen")
RParen 9193:9194
Newline 9194:9195
RBrace 9195:9196
Newline 9196:9197
Newline 9197:9198
Ident 9198:9202 text="test"
Fn 9203:9205
Ident 9206:9247 text="repeated_throws_do_not_leak_payload_state"
LParen 9247:9248
RParen 9248:9249
LBrace 9250:9251
Newline 9251:9252
Ident 9256:9262 text="expect"
LParen 9262:9263
Ident 9263:9268 text="id_fn"
Lt 9268:9269
Ident 9269:9275 text="string"
Gt 9275:9276
LParen 9276:9277
Ident 9277:9285 text="repeated"
LParen 9285:9286
RParen 9286:9287
RParen 9287:9288
RParen 9288:9289
Dot 9289:9290
Ident 9290:9294 text="toBe"
LParen 9294:9295
Str 9295:9300 T("ppp")
RParen 9300:9301
Newline 9301:9302
RBrace 9302:9303
Newline 9303:9304
Newline 9304:9305
Ident 9305:9309 text="test"
Fn 9310:9312
Ident 9313:9356 text="a_throw_at_a_function_tail_still_propagates"
LParen 9356:9357
RParen 9357:9358
LBrace 9359:9360
Newline 9360:9361
Ident 9365:9371 text="expect"
LParen 9371:9372
Ident 9372:9377 text="id_fn"
Lt 9377:9378
Ident 9378:9384 text="string"
Gt 9384:9385
LParen 9385:9386
Ident 9386:9402 text="tail_is_uncaught"
LParen 9402:9403
RParen 9403:9404
RParen 9404:9405
RParen 9405:9406
Dot 9406:9407
Ident 9407:9411 text="toBe"
LParen 9411:9412
Str 9412:9423 T("tail tail")
RParen 9423:9424
Newline 9424:9425
RBrace 9425:9426
Newline 9426:9427
Newline 9427:9428
Ident 9428:9432 text="test"
Fn 9433:9435
Ident 9436:9473 text="a_try_without_a_throw_is_just_a_value"
LParen 9473:9474
RParen 9474:9475
LBrace 9476:9477
Newline 9477:9478
Newline 9541:9542
Ident 9546:9552 text="expect"
LParen 9552:9553
Ident 9553:9558 text="id_fn"
Lt 9558:9559
Ident 9559:9565 text="string"
Gt 9565:9566
LParen 9566:9567
Ident 9567:9578 text="quiet_value"
LParen 9578:9579
RParen 9579:9580
RParen 9580:9581
RParen 9581:9582
Dot 9582:9583
Ident 9583:9587 text="toBe"
LParen 9587:9588
Str 9588:9595 T("plain")
RParen 9595:9596
Newline 9596:9597
RBrace 9597:9598
Newline 9598:9599
Newline 9599:9600
Newline 9680:9681
Newline 9722:9723
Fn 9723:9725
Ident 9726:9737 text="quiet_value"
LParen 9737:9738
RParen 9738:9739
Arrow 9740:9742
Ident 9743:9749 text="string"
LBrace 9750:9751
Newline 9751:9752
Try 9756:9759
LBrace 9760:9761
Newline 9761:9762
Str 9770:9777 T("plain")
Newline 9777:9778
RBrace 9782:9783
Catch 9784:9789
LParen 9790:9791
Ident 9791:9792 text="e"
RParen 9792:9793
LBrace 9794:9795
Newline 9795:9796
Str 9804:9812 T("caught")
Newline 9812:9813
RBrace 9817:9818
Newline 9818:9819
RBrace 9819:9820
Newline 9820:9821
Newline 9821:9822
Newline 9903:9904
Newline 9942:9943
Fn 9943:9945
Ident 9946:9954 text="diverges"
LParen 9954:9955
RParen 9955:9956
Arrow 9957:9959
Ident 9960:9963 text="int"
LBrace 9964:9965
Newline 9965:9966
Throw 9970:9975
Str 9976:9986 T("diverges")
Newline 9986:9987
RBrace 9987:9988
Newline 9988:9989
Newline 9989:9990
Newline 10067:10068
Newline 10123:10124
Fn 10124:10126
Ident 10127:10147 text="return_through_catch"
LParen 10147:10148
RParen 10148:10149
Arrow 10150:10152
Ident 10153:10156 text="int"
LBrace 10157:10158
Newline 10158:10159
Try 10163:10166
LBrace 10167:10168
Newline 10168:10169
Return 10177:10183
Ident 10184:10192 text="diverges"
LParen 10192:10193
RParen 10193:10194
Newline 10194:10195
RBrace 10199:10200
Catch 10201:10206
LParen 10207:10208
Ident 10208:10209 text="e"
RParen 10209:10210
LBrace 10211:10212
Newline 10212:10213
Return 10221:10227
Number 10228:10229 text="7" suf="" isf=0 int=7
Newline 10229:10230
RBrace 10234:10235
Newline 10235:10236
RBrace 10236:10237
Newline 10237:10238
Newline 10238:10239
Newline 10320:10321
Newline 10385:10386
Fn 10386:10388
Ident 10389:10406 text="diverges_mid_body"
LParen 10406:10407
RParen 10407:10408
Arrow 10409:10411
Ident 10412:10415 text="int"
LBrace 10416:10417
Newline 10417:10418
Ident 10422:10430 text="diverges"
LParen 10430:10431
RParen 10431:10432
Newline 10432:10433
Return 10437:10443
Number 10444:10446 text="99" suf="" isf=0 int=99
Newline 10446:10447
RBrace 10447:10448
Newline 10448:10449
Newline 10449:10450
Newline 10530:10531
Fn 10531:10533
Ident 10534:10550 text="diverges_at_tail"
LParen 10550:10551
RParen 10551:10552
Arrow 10553:10555
Ident 10556:10559 text="int"
LBrace 10560:10561
Newline 10561:10562
Ident 10566:10574 text="diverges"
LParen 10574:10575
RParen 10575:10576
Newline 10576:10577
RBrace 10577:10578
Newline 10578:10579
Newline 10579:10580
Ident 10580:10584 text="test"
Fn 10585:10587
Ident 10588:10632 text="a_return_through_a_catch_supplies_the_result"
LParen 10632:10633
RParen 10633:10634
LBrace 10635:10636
Newline 10636:10637
Ident 10641:10647 text="expect"
LParen 10647:10648
Ident 10648:10653 text="id_fn"
Lt 10653:10654
Ident 10654:10657 text="int"
Gt 10657:10658
LParen 10658:10659
Ident 10659:10679 text="return_through_catch"
LParen 10679:10680
RParen 10680:10681
RParen 10681:10682
RParen 10682:10683
Dot 10683:10684
Ident 10684:10688 text="toBe"
LParen 10688:10689
Number 10689:10690 text="7" suf="" isf=0 int=7
RParen 10690:10691
Newline 10691:10692
RBrace 10692:10693
Newline 10693:10694
Newline 10694:10695
Ident 10695:10699 text="test"
Fn 10700:10702
Ident 10703:10761 text="a_diverging_call_as_a_statement_skips_the_rest_of_the_body"
LParen 10761:10762
RParen 10762:10763
LBrace 10764:10765
Newline 10765:10766
Ident 10770:10776 text="expect"
LParen 10776:10777
Ident 10777:10782 text="id_fn"
Lt 10782:10783
Ident 10783:10786 text="int"
Gt 10786:10787
LParen 10787:10788
Ident 10788:10804 text="catches_mid_body"
LParen 10804:10805
RParen 10805:10806
RParen 10806:10807
RParen 10807:10808
Dot 10808:10809
Ident 10809:10813 text="toBe"
LParen 10813:10814
Minus 10814:10815
Number 10815:10816 text="1" suf="" isf=0 int=1
RParen 10816:10817
Newline 10817:10818
RBrace 10818:10819
Newline 10819:10820
Newline 10820:10821
Ident 10821:10825 text="test"
Fn 10826:10828
Ident 10829:10873 text="a_diverging_call_at_the_tail_yields_no_value"
LParen 10873:10874
RParen 10874:10875
LBrace 10876:10877
Newline 10877:10878
Ident 10882:10888 text="expect"
LParen 10888:10889
Ident 10889:10894 text="id_fn"
Lt 10894:10895
Ident 10895:10898 text="int"
Gt 10898:10899
LParen 10899:10900
Ident 10900:10912 text="catches_tail"
LParen 10912:10913
RParen 10913:10914
RParen 10914:10915
RParen 10915:10916
Dot 10916:10917
Ident 10917:10921 text="toBe"
LParen 10921:10922
Minus 10922:10923
Number 10923:10924 text="2" suf="" isf=0 int=2
RParen 10924:10925
Newline 10925:10926
RBrace 10926:10927
Newline 10927:10928
Newline 10928:10929
Newline 11007:11008
Newline 11048:11049
Fn 11049:11051
Ident 11052:11068 text="catches_mid_body"
LParen 11068:11069
RParen 11069:11070
Arrow 11071:11073
Ident 11074:11077 text="int"
LBrace 11078:11079
Newline 11079:11080
Try 11084:11087
LBrace 11088:11089
Newline 11089:11090
Return 11098:11104
Ident 11105:11122 text="diverges_mid_body"
LParen 11122:11123
RParen 11123:11124
Newline 11124:11125
RBrace 11129:11130
Catch 11131:11136
LParen 11137:11138
Ident 11138:11139 text="e"
RParen 11139:11140
LBrace 11141:11142
Newline 11142:11143
Return 11151:11157
Minus 11158:11159
Number 11159:11160 text="1" suf="" isf=0 int=1
Newline 11160:11161
RBrace 11165:11166
Newline 11166:11167
RBrace 11167:11168
Newline 11168:11169
Newline 11169:11170
Fn 11170:11172
Ident 11173:11185 text="catches_tail"
LParen 11185:11186
RParen 11186:11187
Arrow 11188:11190
Ident 11191:11194 text="int"
LBrace 11195:11196
Newline 11196:11197
Try 11201:11204
LBrace 11205:11206
Newline 11206:11207
Return 11215:11221
Ident 11222:11238 text="diverges_at_tail"
LParen 11238:11239
RParen 11239:11240
Newline 11240:11241
RBrace 11245:11246
Catch 11247:11252
LParen 11253:11254
Ident 11254:11255 text="e"
RParen 11255:11256
LBrace 11257:11258
Newline 11258:11259
Return 11267:11273
Minus 11274:11275
Number 11275:11276 text="2" suf="" isf=0 int=2
Newline 11276:11277
RBrace 11281:11282
Newline 11282:11283
RBrace 11283:11284
Newline 11284:11285
Eof 11285:11285
