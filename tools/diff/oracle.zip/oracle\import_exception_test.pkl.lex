Newline 76:77
Newline 79:80
Newline 157:158
Newline 236:237
Newline 317:318
Newline 395:396
Newline 474:475
Newline 519:520
Newline 522:523
Newline 601:602
Newline 677:678
Newline 757:758
Newline 832:833
Newline 912:913
Newline 951:952
Newline 954:955
Newline 1035:1036
Newline 1112:1113
Newline 1192:1193
Newline 1252:1253
Newline 1255:1256
Newline 1334:1335
Newline 1415:1416
Newline 1489:1490
Newline 1492:1493
Newline 1572:1573
Newline 1644:1645
Newline 1645:1646
Module 1646:1652
Ident 1653:1674 text="import_exception_test"
Newline 1674:1675
Newline 1675:1676
Import 1676:1682
Ident 1683:1686 text="std"
Dot 1686:1687
Ident 1687:1689 text="io"
As 1690:1692
Ident 1693:1695 text="io"
Newline 1695:1696
Import 1696:1702
Ident 1703:1706 text="std"
Dot 1706:1707
Ident 1707:1709 text="fs"
As 1710:1712
Ident 1713:1715 text="fs"
Newline 1715:1716
Import 1716:1722
LBrace 1723:1724
Ident 1725:1735 text="currentDir"
RBrace 1736:1737
From 1738:1742
Ident 1743:1746 text="std"
Dot 1746:1747
Ident 1747:1754 text="process"
Newline 1754:1755
Newline 1755:1756
Newline 1801:1802
Fn 1802:1804
Ident 1805:1822 text="qualifying_in_try"
LParen 1822:1823
RParen 1823:1824
Arrow 1825:1827
Ident 1828:1831 text="int"
LBrace 1832:1833
Newline 1833:1834
Try 1838:1841
LBrace 1842:1843
Newline 1843:1844
Return 1852:1858
Ident 1859:1861 text="io"
Dot 1861:1862
Ident 1862:1869 text="writeln"
LParen 1869:1870
Ident 1870:1872 text="fs"
Dot 1872:1873
Ident 1873:1881 text="pathName"
LParen 1881:1882
Str 1882:1894 T("in/try.pkl")
RParen 1894:1895
RParen 1895:1896
Newline 1896:1897
RBrace 1901:1902
Catch 1903:1908
LParen 1909:1910
Ident 1910:1911 text="e"
RParen 1911:1912
LBrace 1913:1914
Newline 1914:1915
Return 1923:1929
Ident 1930:1932 text="io"
Dot 1932:1933
Ident 1933:1940 text="writeln"
LParen 1940:1941
Ident 1941:1942 text="e"
RParen 1942:1943
Newline 1943:1944
RBrace 1948:1949
Newline 1949:1950
RBrace 1950:1951
Newline 1951:1952
Newline 1952:1953
Newline 1990:1991
Fn 1991:1993
Ident 1994:2013 text="qualifying_in_catch"
LParen 2013:2014
RParen 2014:2015
Arrow 2016:2018
Ident 2019:2022 text="int"
LBrace 2023:2024
Newline 2024:2025
Try 2029:2032
LBrace 2033:2034
Newline 2034:2035
Throw 2043:2048
Str 2049:2072 T("handed to the handler")
Newline 2072:2073
RBrace 2077:2078
Catch 2079:2084
LParen 2085:2086
Ident 2086:2087 text="e"
RParen 2087:2088
LBrace 2089:2090
Newline 2090:2091
Return 2099:2105
Ident 2106:2108 text="io"
Dot 2108:2109
Ident 2109:2116 text="writeln"
LParen 2116:2117
Ident 2117:2118 text="e"
RParen 2118:2119
Newline 2119:2120
RBrace 2124:2125
Newline 2125:2126
RBrace 2126:2127
Newline 2127:2128
Newline 2128:2129
Newline 2200:2201
Fn 2201:2203
Ident 2204:2225 text="qualifying_in_finally"
LParen 2225:2226
RParen 2226:2227
Arrow 2228:2230
Ident 2231:2234 text="int"
LBrace 2235:2236
Newline 2236:2237
Try 2241:2244
LBrace 2245:2246
Newline 2246:2247
Return 2255:2261
Ident 2262:2264 text="io"
Dot 2264:2265
Ident 2265:2272 text="writeln"
LParen 2272:2273
Str 2273:2281 T("in try")
RParen 2281:2282
Newline 2282:2283
RBrace 2287:2288
Finally 2289:2296
LBrace 2297:2298
Newline 2298:2299
Ident 2307:2309 text="io"
Dot 2309:2310
Ident 2310:2317 text="writeln"
LParen 2317:2318
Ident 2318:2320 text="fs"
Dot 2320:2321
Ident 2321:2329 text="pathName"
LParen 2329:2330
Str 2330:2346 T("in/finally.pkl")
RParen 2346:2347
RParen 2347:2348
Newline 2348:2349
RBrace 2353:2354
Newline 2354:2355
RBrace 2355:2356
Newline 2356:2357
Newline 2357:2358
Newline 2428:2429
Fn 2429:2431
Ident 2432:2457 text="throwing_a_qualified_call"
LParen 2457:2458
RParen 2458:2459
Arrow 2460:2462
Ident 2463:2466 text="int"
LBrace 2467:2468
Newline 2468:2469
Try 2473:2476
LBrace 2477:2478
Newline 2478:2479
Throw 2487:2492
Ident 2493:2495 text="fs"
Dot 2495:2496
Ident 2496:2504 text="pathName"
LParen 2504:2505
Str 2505:2529 T("thrown/from/a/call.pkl")
RParen 2529:2530
Newline 2530:2531
RBrace 2535:2536
Catch 2537:2542
LParen 2543:2544
Ident 2544:2545 text="e"
RParen 2545:2546
LBrace 2547:2548
Newline 2548:2549
Return 2557:2563
Ident 2564:2566 text="io"
Dot 2566:2567
Ident 2567:2574 text="writeln"
LParen 2574:2575
Ident 2575:2576 text="e"
RParen 2576:2577
Newline 2577:2578
RBrace 2582:2583
Newline 2583:2584
RBrace 2584:2585
Newline 2585:2586
Newline 2586:2587
Newline 2661:2662
Newline 2732:2733
Fn 2733:2735
Ident 2736:2768 text="throwing_a_nested_qualified_call"
LParen 2768:2769
RParen 2769:2770
Arrow 2771:2773
Ident 2774:2777 text="int"
LBrace 2778:2779
Newline 2779:2780
Try 2784:2787
LBrace 2788:2789
Newline 2789:2790
Throw 2798:2803
Ident 2804:2806 text="fs"
Dot 2806:2807
Ident 2807:2815 text="pathName"
LParen 2815:2816
Ident 2816:2818 text="fs"
Dot 2818:2819
Ident 2819:2827 text="pathName"
LParen 2827:2828
Str 2828:2852 T("thrown/from/nested.pkl")
RParen 2852:2853
RParen 2853:2854
Newline 2854:2855
RBrace 2859:2860
Catch 2861:2866
LParen 2867:2868
Ident 2868:2869 text="e"
RParen 2869:2870
LBrace 2871:2872
Newline 2872:2873
Return 2881:2887
Ident 2888:2890 text="io"
Dot 2890:2891
Ident 2891:2898 text="writeln"
LParen 2898:2899
Ident 2899:2900 text="e"
RParen 2900:2901
Newline 2901:2902
RBrace 2906:2907
Newline 2907:2908
RBrace 2908:2909
Newline 2909:2910
Newline 2910:2911
Newline 2985:2986
Newline 3061:3062
Newline 3071:3072
Fn 3072:3074
Ident 3075:3107 text="qualifying_in_a_nested_condition"
LParen 3107:3108
RParen 3108:3109
Arrow 3110:3112
Ident 3113:3116 text="int"
LBrace 3117:3118
Newline 3118:3119
Try 3123:3126
LBrace 3127:3128
Newline 3128:3129
If 3137:3139
LParen 3140:3141
Ident 3141:3143 text="fs"
Dot 3143:3144
Ident 3144:3152 text="pathName"
LParen 3152:3153
Str 3153:3169 T("cond/guard.pkl")
RParen 3169:3170
NotEq 3171:3173
Str 3174:3176
RParen 3176:3177
LBrace 3178:3179
Newline 3179:3180
Throw 3192:3197
Ident 3198:3200 text="fs"
Dot 3200:3201
Ident 3201:3209 text="pathName"
LParen 3209:3210
Str 3210:3226 T("cond/throw.pkl")
RParen 3226:3227
Newline 3227:3228
RBrace 3236:3237
Newline 3237:3238
RBrace 3242:3243
Catch 3244:3249
LParen 3250:3251
Ident 3251:3252 text="e"
RParen 3252:3253
LBrace 3254:3255
Newline 3255:3256
Return 3264:3270
Ident 3271:3273 text="io"
Dot 3273:3274
Ident 3274:3281 text="writeln"
LParen 3281:3282
Ident 3282:3283 text="e"
RParen 3283:3284
Newline 3284:3285
RBrace 3289:3290
Newline 3290:3291
Return 3295:3301
Number 3302:3303 text="0" suf="" isf=0 int=0
Newline 3303:3304
RBrace 3304:3305
Newline 3305:3306
Newline 3306:3307
Newline 3382:3383
Newline 3461:3462
Newline 3513:3514
Fn 3514:3516
Ident 3517:3533 text="bare_name_in_try"
LParen 3533:3534
RParen 3534:3535
Arrow 3536:3538
Ident 3539:3542 text="int"
LBrace 3543:3544
Newline 3544:3545
Try 3549:3552
LBrace 3553:3554
Newline 3554:3555
If 3563:3565
LParen 3566:3567
Let 3567:3570
Ident 3571:3575 text="some"
LParen 3575:3576
Ident 3576:3579 text="dir"
RParen 3579:3580
Assign 3581:3582
Ident 3583:3593 text="currentDir"
LParen 3593:3594
RParen 3594:3595
RParen 3595:3596
LBrace 3597:3598
Newline 3598:3599
Return 3611:3617
Ident 3618:3620 text="io"
Dot 3620:3621
Ident 3621:3628 text="writeln"
LParen 3628:3629
Ident 3629:3631 text="fs"
Dot 3631:3632
Ident 3632:3640 text="pathName"
LParen 3640:3641
Ident 3641:3644 text="dir"
Plus 3645:3646
Str 3647:3659 T("/probe.pkl")
RParen 3659:3660
RParen 3660:3661
Newline 3661:3662
RBrace 3670:3671
Newline 3671:3672
Return 3680:3686
Number 3687:3688 text="0" suf="" isf=0 int=0
Newline 3688:3689
RBrace 3693:3694
Catch 3695:3700
LParen 3701:3702
Ident 3702:3703 text="e"
RParen 3703:3704
LBrace 3705:3706
Newline 3706:3707
Return 3715:3721
Ident 3722:3724 text="io"
Dot 3724:3725
Ident 3725:3732 text="writeln"
LParen 3732:3733
Ident 3733:3734 text="e"
RParen 3734:3735
Newline 3735:3736
RBrace 3740:3741
Newline 3741:3742
RBrace 3742:3743
Newline 3743:3744
Newline 3744:3745
Newline 3819:3820
Newline 3894:3895
Fn 3895:3897
Ident 3898:3923 text="qualifying_a_bound_import"
LParen 3923:3924
RParen 3924:3925
Arrow 3926:3928
Ident 3929:3932 text="int"
LBrace 3933:3934
Newline 3934:3935
Let 3939:3942
Ident 3943:3947 text="emit"
Assign 3948:3949
Ident 3950:3952 text="io"
Dot 3952:3953
Ident 3953:3960 text="writeln"
Newline 3960:3961
Return 3965:3971
Ident 3972:3976 text="emit"
LParen 3976:3977
Ident 3977:3979 text="fs"
Dot 3979:3980
Ident 3980:3988 text="pathName"
LParen 3988:3989
Str 3989:4000 T("bound.pkl")
RParen 4000:4001
RParen 4001:4002
Newline 4002:4003
RBrace 4003:4004
Newline 4004:4005
Newline 4005:4006
Fn 4006:4008
Ident 4009:4013 text="main"
LParen 4013:4014
RParen 4014:4015
LBrace 4016:4017
Newline 4017:4018
Ident 4022:4039 text="qualifying_in_try"
LParen 4039:4040
RParen 4040:4041
Newline 4041:4042
Ident 4046:4065 text="qualifying_in_catch"
LParen 4065:4066
RParen 4066:4067
Newline 4067:4068
Ident 4072:4093 text="qualifying_in_finally"
LParen 4093:4094
RParen 4094:4095
Newline 4095:4096
Ident 4100:4125 text="throwing_a_qualified_call"
LParen 4125:4126
RParen 4126:4127
Newline 4127:4128
Ident 4132:4164 text="throwing_a_nested_qualified_call"
LParen 4164:4165
RParen 4165:4166
Newline 4166:4167
Ident 4171:4203 text="qualifying_in_a_nested_condition"
LParen 4203:4204
RParen 4204:4205
Newline 4205:4206
Ident 4210:4226 text="bare_name_in_try"
LParen 4226:4227
RParen 4227:4228
Newline 4228:4229
Ident 4233:4258 text="qualifying_a_bound_import"
LParen 4258:4259
RParen 4259:4260
Newline 4260:4261
Ident 4265:4267 text="io"
Dot 4267:4268
Ident 4268:4275 text="writeln"
LParen 4275:4276
Str 4276:4282 T("done")
RParen 4282:4283
Newline 4283:4284
RBrace 4284:4285
Newline 4285:4286
Eof 4286:4286
