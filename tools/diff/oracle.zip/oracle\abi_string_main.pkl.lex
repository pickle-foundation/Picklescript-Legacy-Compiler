Module 0:6
Ident 7:22 text="abi_string_main"
Newline 22:23
Newline 23:24
Newline 106:107
Newline 184:185
Newline 262:263
Newline 289:290
Newline 292:293
Newline 372:373
Newline 451:452
Newline 532:533
Newline 607:608
Newline 647:648
Newline 650:651
Newline 722:723
Newline 725:726
Newline 802:803
Newline 880:881
Newline 955:956
Newline 1027:1028
Newline 1104:1105
Newline 1160:1161
Newline 1227:1228
Newline 1230:1231
Newline 1296:1297
Newline 1377:1378
Newline 1445:1446
Import 1446:1452
LBrace 1453:1454
Ident 1455:1464 text="abiStrLen"
Comma 1464:1465
Ident 1466:1475 text="abiStrGet"
Comma 1475:1476
Ident 1477:1486 text="abiStrSet"
Comma 1486:1487
Ident 1488:1500 text="abiStrConcat"
Comma 1500:1501
Ident 1502:1511 text="abiStrCmp"
Comma 1511:1512
Ident 1513:1527 text="abiStrFromBool"
Comma 1527:1528
Ident 1529:1543 text="abiStrFromByte"
Comma 1543:1544
Ident 1545:1559 text="abiStrFromChar"
Comma 1559:1560
Ident 1561:1574 text="abiStrToBytes"
Comma 1574:1575
Ident 1576:1590 text="abiStrFromList"
RBrace 1591:1592
From 1593:1597
Ident 1598:1605 text="runtime"
Dot 1605:1606
Ident 1606:1616 text="abi_string"
Newline 1616:1617
Import 1617:1623
LBrace 1624:1625
Ident 1626:1636 text="abiListNew"
Comma 1636:1637
Ident 1638:1648 text="abiListLen"
Comma 1648:1649
Ident 1650:1660 text="abiListGet"
RBrace 1661:1662
From 1663:1667
Ident 1668:1675 text="runtime"
Dot 1675:1676
Ident 1676:1684 text="abi_list"
Newline 1684:1685
Import 1685:1691
LBrace 1692:1693
Ident 1694:1705 text="abiUnboxI64"
RBrace 1706:1707
From 1708:1712
Ident 1713:1720 text="runtime"
Dot 1720:1721
Ident 1721:1728 text="abi_box"
Newline 1728:1729
Newline 1729:1730
Newline 1807:1808
Newline 1885:1886
Newline 1954:1955
Fn 1955:1957 doc="Build a string object from raw byte values. `pickle_str_from_byte` is the\nconstructor that takes a plain `int` byte, so it is the way a test gets a\nstring object without depending on the emitter's own conversion."
Ident 1958:1960 text="b2"
LParen 1960:1961
Ident 1961:1962 text="a"
Colon 1962:1963
Ident 1964:1967 text="int"
Comma 1967:1968
Ident 1969:1970 text="c"
Colon 1970:1971
Ident 1972:1975 text="int"
RParen 1975:1976
Arrow 1977:1979
Star 1980:1981
Ident 1981:1984 text="int"
LBrace 1985:1986
Newline 1986:1987
Return 1991:1997
Ident 1998:2010 text="abiStrConcat"
LParen 2010:2011
Ident 2011:2025 text="abiStrFromByte"
LParen 2025:2026
Ident 2026:2027 text="a"
RParen 2027:2028
Comma 2028:2029
Ident 2030:2044 text="abiStrFromByte"
LParen 2044:2045
Ident 2045:2046 text="c"
RParen 2046:2047
RParen 2047:2048
Newline 2048:2049
RBrace 2049:2050
Newline 2050:2051
Newline 2051:2052
Fn 2052:2054
Ident 2055:2057 text="b3"
LParen 2057:2058
Ident 2058:2059 text="a"
Colon 2059:2060
Ident 2061:2064 text="int"
Comma 2064:2065
Ident 2066:2067 text="c"
Colon 2067:2068
Ident 2069:2072 text="int"
Comma 2072:2073
Ident 2074:2075 text="d"
Colon 2075:2076
Ident 2077:2080 text="int"
RParen 2080:2081
Arrow 2082:2084
Star 2085:2086
Ident 2086:2089 text="int"
LBrace 2090:2091
Newline 2091:2092
Return 2096:2102
Ident 2103:2115 text="abiStrConcat"
LParen 2115:2116
Ident 2116:2118 text="b2"
LParen 2118:2119
Ident 2119:2120 text="a"
Comma 2120:2121
Ident 2122:2123 text="c"
RParen 2123:2124
Comma 2124:2125
Ident 2126:2140 text="abiStrFromByte"
LParen 2140:2141
Ident 2141:2142 text="d"
RParen 2142:2143
RParen 2143:2144
Newline 2144:2145
RBrace 2145:2146
Newline 2146:2147
Newline 2147:2148
Fn 2148:2150
Ident 2151:2153 text="b4"
LParen 2153:2154
Ident 2154:2155 text="a"
Colon 2155:2156
Ident 2157:2160 text="int"
Comma 2160:2161
Ident 2162:2163 text="c"
Colon 2163:2164
Ident 2165:2168 text="int"
Comma 2168:2169
Ident 2170:2171 text="d"
Colon 2171:2172
Ident 2173:2176 text="int"
Comma 2176:2177
Ident 2178:2179 text="e"
Colon 2179:2180
Ident 2181:2184 text="int"
RParen 2184:2185
Arrow 2186:2188
Star 2189:2190
Ident 2190:2193 text="int"
LBrace 2194:2195
Newline 2195:2196
Return 2200:2206
Ident 2207:2219 text="abiStrConcat"
LParen 2219:2220
Ident 2220:2222 text="b3"
LParen 2222:2223
Ident 2223:2224 text="a"
Comma 2224:2225
Ident 2226:2227 text="c"
Comma 2227:2228
Ident 2229:2230 text="d"
RParen 2230:2231
Comma 2231:2232
Ident 2233:2247 text="abiStrFromByte"
LParen 2247:2248
Ident 2248:2249 text="e"
RParen 2249:2250
RParen 2250:2251
Newline 2251:2252
RBrace 2252:2253
Newline 2253:2254
Newline 2254:2255
Fn 2255:2257
Ident 2258:2262 text="main"
LParen 2262:2263
RParen 2263:2264
LBrace 2265:2266
Newline 2266:2267
Ident 2271:2278 text="println"
LParen 2278:2279
Str 2279:2310 T("== str_get reads raw bytes ==")
RParen 2310:2311
Newline 2311:2312
Let 2316:2319
Ident 2320:2323 text="abc"
Assign 2324:2325
Ident 2326:2328 text="b3"
LParen 2328:2329
Number 2329:2331 text="97" suf="" isf=0 int=97
Comma 2331:2332
Number 2333:2335 text="98" suf="" isf=0 int=98
Comma 2335:2336
Number 2337:2339 text="99" suf="" isf=0 int=99
RParen 2339:2340
Newline 2340:2341
Ident 2345:2352 text="println"
LParen 2352:2353
Str 2353:2381 T("  abc len=") E[Ident 2365:2374 text="abiStrLen"; LParen 2374:2375; Ident 2375:2378 text="abc"; RParen 2378:2379; Eof 2380:2380]
RParen 2381:2382
Newline 2382:2383
Var 2387:2390
Ident 2391:2392 text="i"
Assign 2393:2394
Number 2395:2396 text="0" suf="" isf=0 int=0
Newline 2396:2397
While 2401:2406
LParen 2407:2408
Ident 2408:2409 text="i"
Lt 2410:2411
Ident 2412:2421 text="abiStrLen"
LParen 2421:2422
Ident 2422:2425 text="abc"
RParen 2425:2426
RParen 2426:2427
LBrace 2428:2429
Newline 2429:2430
Ident 2438:2445 text="println"
LParen 2445:2446
Str 2446:2480 T("    abc[") E[Ident 2456:2457 text="i"; Eof 2458:2458] T("]=") E[Ident 2461:2470 text="abiStrGet"; LParen 2470:2471; Ident 2471:2474 text="abc"; Comma 2474:2475; Ident 2476:2477 text="i"; RParen 2477:2478; Eof 2479:2479]
RParen 2480:2481
Newline 2481:2482
Ident 2490:2491 text="i"
Assign 2492:2493
Ident 2494:2495 text="i"
Plus 2496:2497
Number 2498:2499 text="1" suf="" isf=0 int=1
Newline 2499:2500
RBrace 2504:2505
Newline 2505:2506
Newline 2506:2507
Ident 2511:2518 text="println"
LParen 2518:2519
Str 2519:2554 T("== str_get over multibyte text ==")
RParen 2554:2555
Newline 2555:2556
Newline 2621:2622
Let 2626:2629
Ident 2630:2636 text="eacute"
Assign 2637:2638
Ident 2639:2641 text="b2"
LParen 2641:2642
Number 2642:2645 text="195" suf="" isf=0 int=195
Comma 2645:2646
Number 2647:2650 text="169" suf="" isf=0 int=169
RParen 2650:2651
Newline 2651:2652
Ident 2656:2663 text="println"
LParen 2663:2664
Str 2664:2743 T("  len=") E[Ident 2672:2681 text="abiStrLen"; LParen 2681:2682; Ident 2682:2688 text="eacute"; RParen 2688:2689; Eof 2690:2690] T(" b0=") E[Ident 2695:2704 text="abiStrGet"; LParen 2704:2705; Ident 2705:2711 text="eacute"; Comma 2711:2712; Number 2713:2714 text="0" suf="" isf=0 int=0; RParen 2714:2715; Eof 2716:2716] T(" b1=") E[Ident 2721:2730 text="abiStrGet"; LParen 2730:2731; Ident 2731:2737 text="eacute"; Comma 2737:2738; Number 2739:2740 text="1" suf="" isf=0 int=1; RParen 2740:2741; Eof 2742:2742]
RParen 2743:2744
Newline 2744:2745
Newline 2745:2746
Ident 2750:2757 text="println"
LParen 2757:2758
Str 2758:2790 T("== str_set is copy-on-write ==")
RParen 2790:2791
Newline 2791:2792
Let 2796:2799
Ident 2800:2803 text="src"
Assign 2804:2805
Ident 2806:2808 text="b3"
LParen 2808:2809
Number 2809:2811 text="97" suf="" isf=0 int=97
Comma 2811:2812
Number 2813:2815 text="98" suf="" isf=0 int=98
Comma 2815:2816
Number 2817:2819 text="99" suf="" isf=0 int=99
RParen 2819:2820
Newline 2820:2821
Let 2825:2828
Ident 2829:2832 text="dst"
Assign 2833:2834
Ident 2835:2844 text="abiStrSet"
LParen 2844:2845
Ident 2845:2848 text="src"
Comma 2848:2849
Number 2850:2851 text="1" suf="" isf=0 int=1
Comma 2851:2852
Number 2853:2856 text="122" suf="" isf=0 int=122
RParen 2856:2857
Newline 2857:2858
Ident 2862:2869 text="println"
LParen 2869:2870
Str 2870:2927 T("  src[1]=") E[Ident 2881:2890 text="abiStrGet"; LParen 2890:2891; Ident 2891:2894 text="src"; Comma 2894:2895; Number 2896:2897 text="1" suf="" isf=0 int=1; RParen 2897:2898; Eof 2899:2899] T(" dst[1]=") E[Ident 2908:2917 text="abiStrGet"; LParen 2917:2918; Ident 2918:2921 text="dst"; Comma 2921:2922; Number 2923:2924 text="1" suf="" isf=0 int=1; RParen 2924:2925; Eof 2926:2926]
RParen 2927:2928
Newline 2928:2929
Ident 2933:2940 text="println"
LParen 2940:2941
Str 2941:2987 T("  same object=") E[LParen 2957:2958; Ident 2958:2961 text="src"; As 2962:2964; Ident 2965:2968 text="int"; RParen 2968:2969; EqEq 2970:2972; LParen 2973:2974; Ident 2974:2977 text="dst"; As 2978:2980; Ident 2981:2984 text="int"; RParen 2984:2985; Eof 2986:2986]
RParen 2987:2988
Newline 2988:2989
Newline 2989:2990
Ident 2994:3001 text="println"
LParen 3001:3002
Str 3002:3037 T("== str_set truncates to a byte ==")
RParen 3037:3038
Newline 3038:3039
Newline 3089:3090
Let 3094:3097
Ident 3098:3103 text="trunc"
Assign 3104:3105
Ident 3106:3115 text="abiStrSet"
LParen 3115:3116
Ident 3116:3118 text="b4"
LParen 3118:3119
Number 3119:3121 text="63" suf="" isf=0 int=63
Comma 3121:3122
Number 3123:3124 text="0" suf="" isf=0 int=0
Comma 3124:3125
Number 3126:3127 text="0" suf="" isf=0 int=0
Comma 3127:3128
Number 3129:3130 text="0" suf="" isf=0 int=0
RParen 3130:3131
Comma 3131:3132
Number 3133:3134 text="0" suf="" isf=0 int=0
Comma 3134:3135
Number 3136:3139 text="321" suf="" isf=0 int=321
RParen 3139:3140
Newline 3140:3141
Ident 3145:3152 text="println"
LParen 3152:3153
Str 3153:3184 T("  byte0=") E[Ident 3163:3172 text="abiStrGet"; LParen 3172:3173; Ident 3173:3178 text="trunc"; Comma 3178:3179; Number 3180:3181 text="0" suf="" isf=0 int=0; RParen 3181:3182; Eof 3183:3183]
RParen 3184:3185
Newline 3185:3186
Newline 3186:3187
Ident 3191:3198 text="println"
LParen 3198:3199
Str 3199:3220 T("== str_from_bool ==")
RParen 3220:3221
Newline 3221:3222
Newline 3298:3299
Newline 3375:3376
Newline 3457:3458
Newline 3526:3527
Let 3531:3534
Ident 3535:3537 text="bt"
Assign 3538:3539
Ident 3540:3554 text="abiStrFromBool"
LParen 3554:3555
True 3555:3559
RParen 3559:3560
Newline 3560:3561
Let 3565:3568
Ident 3569:3571 text="bf"
Assign 3572:3573
Ident 3574:3588 text="abiStrFromBool"
LParen 3588:3589
False 3589:3594
RParen 3594:3595
Newline 3595:3596
Ident 3600:3607 text="println"
LParen 3607:3608
Str 3608:3719 T("  true  len=") E[Ident 3622:3631 text="abiStrLen"; LParen 3631:3632; Ident 3632:3634 text="bt"; RParen 3634:3635; Eof 3636:3636] T(" bytes=") E[Ident 3644:3653 text="abiStrGet"; LParen 3653:3654; Ident 3654:3656 text="bt"; Comma 3656:3657; Number 3658:3659 text="0" suf="" isf=0 int=0; RParen 3659:3660; Eof 3661:3661] T(",") E[Ident 3663:3672 text="abiStrGet"; LParen 3672:3673; Ident 3673:3675 text="bt"; Comma 3675:3676; Number 3677:3678 text="1" suf="" isf=0 int=1; RParen 3678:3679; Eof 3680:3680] T(",") E[Ident 3682:3691 text="abiStrGet"; LParen 3691:3692; Ident 3692:3694 text="bt"; Comma 3694:3695; Number 3696:3697 text="2" suf="" isf=0 int=2; RParen 3697:3698; Eof 3699:3699] T(",") E[Ident 3701:3710 text="abiStrGet"; LParen 3710:3711; Ident 3711:3713 text="bt"; Comma 3713:3714; Number 3715:3716 text="3" suf="" isf=0 int=3; RParen 3716:3717; Eof 3718:3718]
RParen 3719:3720
Newline 3720:3721
Ident 3725:3732 text="println"
LParen 3732:3733
Str 3733:3863 T("  false len=") E[Ident 3747:3756 text="abiStrLen"; LParen 3756:3757; Ident 3757:3759 text="bf"; RParen 3759:3760; Eof 3761:3761] T(" bytes=") E[Ident 3769:3778 text="abiStrGet"; LParen 3778:3779; Ident 3779:3781 text="bf"; Comma 3781:3782; Number 3783:3784 text="0" suf="" isf=0 int=0; RParen 3784:3785; Eof 3786:3786] T(",") E[Ident 3788:3797 text="abiStrGet"; LParen 3797:3798; Ident 3798:3800 text="bf"; Comma 3800:3801; Number 3802:3803 text="1" suf="" isf=0 int=1; RParen 3803:3804; Eof 3805:3805] T(",") E[Ident 3807:3816 text="abiStrGet"; LParen 3816:3817; Ident 3817:3819 text="bf"; Comma 3819:3820; Number 3821:3822 text="2" suf="" isf=0 int=2; RParen 3822:3823; Eof 3824:3824] T(",") E[Ident 3826:3835 text="abiStrGet"; LParen 3835:3836; Ident 3836:3838 text="bf"; Comma 3838:3839; Number 3840:3841 text="3" suf="" isf=0 int=3; RParen 3841:3842; Eof 3843:3843] T(",") E[Ident 3845:3854 text="abiStrGet"; LParen 3854:3855; Ident 3855:3857 text="bf"; Comma 3857:3858; Number 3859:3860 text="4" suf="" isf=0 int=4; RParen 3860:3861; Eof 3862:3862]
RParen 3863:3864
Newline 3864:3865
Newline 3865:3866
Ident 3870:3877 text="println"
LParen 3877:3878
Str 3878:3922 T("== str_from_byte is raw, not re-encoded ==")
RParen 3922:3923
Newline 3923:3924
Let 3928:3931
Ident 3932:3935 text="raw"
Assign 3936:3937
Ident 3938:3952 text="abiStrFromByte"
LParen 3952:3953
Number 3953:3956 text="195" suf="" isf=0 int=195
RParen 3956:3957
Newline 3957:3958
Ident 3962:3969 text="println"
LParen 3969:3970
Str 3970:4020 T("  len=") E[Ident 3978:3987 text="abiStrLen"; LParen 3987:3988; Ident 3988:3991 text="raw"; RParen 3991:3992; Eof 3993:3993] T(" byte0=") E[Ident 4001:4010 text="abiStrGet"; LParen 4010:4011; Ident 4011:4014 text="raw"; Comma 4014:4015; Number 4016:4017 text="0" suf="" isf=0 int=0; RParen 4017:4018; Eof 4019:4019]
RParen 4020:4021
Newline 4021:4022
Ident 4026:4033 text="println"
LParen 4033:4034
Str 4034:4096 T("  321 truncates to byte0=") E[Ident 4061:4070 text="abiStrGet"; LParen 4070:4071; Ident 4071:4085 text="abiStrFromByte"; LParen 4085:4086; Number 4086:4089 text="321" suf="" isf=0 int=321; RParen 4089:4090; Comma 4090:4091; Number 4092:4093 text="0" suf="" isf=0 int=0; RParen 4093:4094; Eof 4095:4095]
RParen 4096:4097
Newline 4097:4098
Newline 4098:4099
Ident 4103:4110 text="println"
LParen 4110:4111
Str 4111:4146 T("== str_from_char encodes UTF-8 ==")
RParen 4146:4147
Newline 4147:4148
Ident 4152:4159 text="println"
LParen 4159:4160
Str 4160:4207 T("  A       len=") E[Ident 4176:4185 text="abiStrLen"; LParen 4185:4186; Ident 4186:4200 text="abiStrFromChar"; LParen 4200:4201; Number 4201:4203 text="65" suf="" isf=0 int=65; RParen 4203:4204; RParen 4204:4205; Eof 4206:4206]
RParen 4207:4208
Newline 4208:4209
Ident 4213:4220 text="println"
LParen 4220:4221
Str 4221:4269 T("  U+00E9  len=") E[Ident 4237:4246 text="abiStrLen"; LParen 4246:4247; Ident 4247:4261 text="abiStrFromChar"; LParen 4261:4262; Number 4262:4265 text="233" suf="" isf=0 int=233; RParen 4265:4266; RParen 4266:4267; Eof 4268:4268]
RParen 4269:4270
Newline 4270:4271
Ident 4275:4282 text="println"
LParen 4282:4283
Str 4283:4333 T("  U+FFFD  len=") E[Ident 4299:4308 text="abiStrLen"; LParen 4308:4309; Ident 4309:4323 text="abiStrFromChar"; LParen 4323:4324; Number 4324:4329 text="65533" suf="" isf=0 int=65533; RParen 4329:4330; RParen 4330:4331; Eof 4332:4332]
RParen 4333:4334
Newline 4334:4335
Ident 4339:4346 text="println"
LParen 4346:4347
Str 4347:4398 T("  U+1F600 len=") E[Ident 4363:4372 text="abiStrLen"; LParen 4372:4373; Ident 4373:4387 text="abiStrFromChar"; LParen 4387:4388; Number 4388:4394 text="128512" suf="" isf=0 int=128512; RParen 4394:4395; RParen 4395:4396; Eof 4397:4397]
RParen 4398:4399
Newline 4399:4400
Let 4404:4407
Ident 4408:4413 text="emoji"
Assign 4414:4415
Ident 4416:4430 text="abiStrFromChar"
LParen 4430:4431
Number 4431:4437 text="128512" suf="" isf=0 int=128512
RParen 4437:4438
Newline 4438:4439
Var 4443:4446
Ident 4447:4448 text="j"
Assign 4449:4450
Number 4451:4452 text="0" suf="" isf=0 int=0
Newline 4452:4453
While 4457:4462
LParen 4463:4464
Ident 4464:4465 text="j"
Lt 4466:4467
Ident 4468:4477 text="abiStrLen"
LParen 4477:4478
Ident 4478:4483 text="emoji"
RParen 4483:4484
RParen 4484:4485
LBrace 4486:4487
Newline 4487:4488
Ident 4496:4503 text="println"
LParen 4503:4504
Str 4504:4542 T("    emoji[") E[Ident 4516:4517 text="j"; Eof 4518:4518] T("]=") E[Ident 4521:4530 text="abiStrGet"; LParen 4530:4531; Ident 4531:4536 text="emoji"; Comma 4536:4537; Ident 4538:4539 text="j"; RParen 4539:4540; Eof 4541:4541]
RParen 4542:4543
Newline 4543:4544
Ident 4552:4553 text="j"
Assign 4554:4555
Ident 4556:4557 text="j"
Plus 4558:4559
Number 4560:4561 text="1" suf="" isf=0 int=1
Newline 4561:4562
RBrace 4566:4567
Newline 4567:4568
Newline 4568:4569
Ident 4573:4580 text="println"
LParen 4580:4581
Str 4581:4631 T("== str_from_char replaces invalid code points ==")
RParen 4631:4632
Newline 4632:4633
Let 4637:4640
Ident 4641:4645 text="want"
Assign 4646:4647
Ident 4648:4662 text="abiStrFromChar"
LParen 4662:4663
Number 4663:4668 text="65533" suf="" isf=0 int=65533
RParen 4668:4669
Newline 4669:4670
Ident 4674:4681 text="println"
LParen 4681:4682
Str 4682:4753 T("  D800  matches U+FFFD: ") E[Ident 4708:4717 text="abiStrCmp"; LParen 4717:4718; Ident 4718:4732 text="abiStrFromChar"; LParen 4732:4733; Number 4733:4738 text="55296" suf="" isf=0 int=55296; RParen 4738:4739; Comma 4739:4740; Ident 4741:4745 text="want"; RParen 4745:4746; EqEq 4747:4749; Number 4750:4751 text="0" suf="" isf=0 int=0; Eof 4752:4752]
RParen 4753:4754
Newline 4754:4755
Ident 4759:4766 text="println"
LParen 4766:4767
Str 4767:4838 T("  DFFF  matches U+FFFD: ") E[Ident 4793:4802 text="abiStrCmp"; LParen 4802:4803; Ident 4803:4817 text="abiStrFromChar"; LParen 4817:4818; Number 4818:4823 text="57343" suf="" isf=0 int=57343; RParen 4823:4824; Comma 4824:4825; Ident 4826:4830 text="want"; RParen 4830:4831; EqEq 4832:4834; Number 4835:4836 text="0" suf="" isf=0 int=0; Eof 4837:4837]
RParen 4838:4839
Newline 4839:4840
Ident 4844:4851 text="println"
LParen 4851:4852
Str 4852:4927 T("  >10FFFF matches U+FFFD: ") E[Ident 4880:4889 text="abiStrCmp"; LParen 4889:4890; Ident 4890:4904 text="abiStrFromChar"; LParen 4904:4905; Number 4905:4912 text="1114112" suf="" isf=0 int=1114112; RParen 4912:4913; Comma 4913:4914; Ident 4915:4919 text="want"; RParen 4919:4920; EqEq 4921:4923; Number 4924:4925 text="0" suf="" isf=0 int=0; Eof 4926:4926]
RParen 4927:4928
Newline 4928:4929
Ident 4933:4940 text="println"
LParen 4940:4941
Str 4941:5012 T("  -1    matches U+FFFD: ") E[Ident 4967:4976 text="abiStrCmp"; LParen 4976:4977; Ident 4977:4991 text="abiStrFromChar"; LParen 4991:4992; Number 4992:4993 text="0" suf="" isf=0 int=0; Minus 4994:4995; Number 4996:4997 text="1" suf="" isf=0 int=1; RParen 4997:4998; Comma 4998:4999; Ident 5000:5004 text="want"; RParen 5004:5005; EqEq 5006:5008; Number 5009:5010 text="0" suf="" isf=0 int=0; Eof 5011:5011]
RParen 5012:5013
Newline 5013:5014
Newline 5014:5015
Ident 5019:5026 text="println"
LParen 5026:5027
Str 5027:5064 T("== str_to_bytes boxes every byte ==")
RParen 5064:5065
Newline 5065:5066
Let 5070:5073
Ident 5074:5076 text="bs"
Assign 5077:5078
Ident 5079:5092 text="abiStrToBytes"
LParen 5092:5093
Ident 5093:5096 text="abc"
RParen 5096:5097
Newline 5097:5098
Ident 5102:5109 text="println"
LParen 5109:5110
Str 5110:5139 T("  list len=") E[Ident 5123:5133 text="abiListLen"; LParen 5133:5134; Ident 5134:5136 text="bs"; RParen 5136:5137; Eof 5138:5138]
RParen 5139:5140
Newline 5140:5141
Var 5145:5148
Ident 5149:5150 text="k"
Assign 5151:5152
Number 5153:5154 text="0" suf="" isf=0 int=0
Newline 5154:5155
While 5159:5164
LParen 5165:5166
Ident 5166:5167 text="k"
Lt 5168:5169
Ident 5170:5180 text="abiListLen"
LParen 5180:5181
Ident 5181:5183 text="bs"
RParen 5183:5184
RParen 5184:5185
LBrace 5186:5187
Newline 5187:5188
Ident 5196:5203 text="println"
LParen 5203:5204
Str 5204:5251 T("    box[") E[Ident 5214:5215 text="k"; Eof 5216:5216] T("]=") E[Ident 5219:5230 text="abiUnboxI64"; LParen 5230:5231; Ident 5231:5241 text="abiListGet"; LParen 5241:5242; Ident 5242:5244 text="bs"; Comma 5244:5245; Ident 5246:5247 text="k"; RParen 5247:5248; RParen 5248:5249; Eof 5250:5250]
RParen 5251:5252
Newline 5252:5253
Ident 5261:5262 text="k"
Assign 5263:5264
Ident 5265:5266 text="k"
Plus 5267:5268
Number 5269:5270 text="1" suf="" isf=0 int=1
Newline 5270:5271
RBrace 5275:5276
Newline 5276:5277
Newline 5277:5278
Ident 5282:5289 text="println"
LParen 5289:5290
Str 5290:5330 T("== bytes()/str() round-trip exactly ==")
RParen 5330:5331
Newline 5331:5332
Newline 5383:5384
Let 5388:5391
Ident 5392:5397 text="mixed"
Assign 5398:5399
Ident 5400:5402 text="b3"
LParen 5402:5403
Number 5403:5406 text="104" suf="" isf=0 int=104
Comma 5406:5407
Number 5408:5411 text="233" suf="" isf=0 int=233
Comma 5411:5412
Number 5413:5416 text="108" suf="" isf=0 int=108
RParen 5416:5417
Newline 5417:5418
Let 5422:5425
Ident 5426:5430 text="back"
Assign 5431:5432
Ident 5433:5447 text="abiStrFromList"
LParen 5447:5448
Ident 5448:5461 text="abiStrToBytes"
LParen 5461:5462
Ident 5462:5467 text="mixed"
RParen 5467:5468
RParen 5468:5469
Newline 5469:5470
Ident 5474:5481 text="println"
LParen 5481:5482
Str 5482:5562 T("  len in=") E[Ident 5493:5502 text="abiStrLen"; LParen 5502:5503; Ident 5503:5508 text="mixed"; RParen 5508:5509; Eof 5510:5510] T(" out=") E[Ident 5516:5525 text="abiStrLen"; LParen 5525:5526; Ident 5526:5530 text="back"; RParen 5530:5531; Eof 5532:5532] T(" cmp=") E[Ident 5538:5547 text="abiStrCmp"; LParen 5547:5548; Ident 5548:5552 text="back"; Comma 5552:5553; Ident 5554:5559 text="mixed"; RParen 5559:5560; Eof 5561:5561]
RParen 5562:5563
Newline 5563:5564
Var 5568:5571
Ident 5572:5573 text="m"
Assign 5574:5575
Number 5576:5577 text="0" suf="" isf=0 int=0
Newline 5577:5578
While 5582:5587
LParen 5588:5589
Ident 5589:5590 text="m"
Lt 5591:5592
Ident 5593:5602 text="abiStrLen"
LParen 5602:5603
Ident 5603:5607 text="back"
RParen 5607:5608
RParen 5608:5609
LBrace 5610:5611
Newline 5611:5612
Ident 5620:5627 text="println"
LParen 5627:5628
Str 5628:5664 T("    back[") E[Ident 5639:5640 text="m"; Eof 5641:5641] T("]=") E[Ident 5644:5653 text="abiStrGet"; LParen 5653:5654; Ident 5654:5658 text="back"; Comma 5658:5659; Ident 5660:5661 text="m"; RParen 5661:5662; Eof 5663:5663]
RParen 5664:5665
Newline 5665:5666
Ident 5674:5675 text="m"
Assign 5676:5677
Ident 5678:5679 text="m"
Plus 5680:5681
Number 5682:5683 text="1" suf="" isf=0 int=1
Newline 5683:5684
RBrace 5688:5689
Newline 5689:5690
Newline 5690:5691
Ident 5695:5702 text="println"
LParen 5702:5703
Str 5703:5723 T("== empty string ==")
RParen 5723:5724
Newline 5724:5725
Newline 5806:5807
Newline 5859:5860
Let 5864:5867
Ident 5868:5873 text="empty"
Assign 5874:5875
Ident 5876:5890 text="abiStrFromList"
LParen 5890:5891
Ident 5891:5901 text="abiListNew"
LParen 5901:5902
Number 5902:5903 text="0" suf="" isf=0 int=0
RParen 5903:5904
RParen 5904:5905
Newline 5905:5906
Ident 5910:5917 text="println"
LParen 5917:5918
Str 5918:5988 T("  len=") E[Ident 5926:5935 text="abiStrLen"; LParen 5935:5936; Ident 5936:5941 text="empty"; RParen 5941:5942; Eof 5943:5943] T(" list len=") E[Ident 5954:5964 text="abiListLen"; LParen 5964:5965; Ident 5965:5978 text="abiStrToBytes"; LParen 5978:5979; Ident 5979:5984 text="empty"; RParen 5984:5985; RParen 5985:5986; Eof 5987:5987]
RParen 5988:5989
Newline 5989:5990
RBrace 5990:5991
Eof 5991:5991
