Newline 70:71
Newline 145:146
Newline 192:193
Newline 195:196
Newline 274:275
Newline 346:347
Newline 422:423
Newline 503:504
Newline 583:584
Newline 656:657
Newline 710:711
Newline 713:714
Newline 788:789
Newline 867:868
Newline 946:947
Newline 1023:1024
Newline 1068:1069
Newline 1071:1072
Newline 1148:1149
Newline 1227:1228
Newline 1257:1258
Newline 1258:1259
Import 1259:1265
LBrace 1266:1267
Ident 1268:1278 text="abiOnceNew"
RBrace 1279:1280
From 1281:1285
Ident 1286:1293 text="runtime"
Dot 1293:1294
Ident 1294:1302 text="abi_once"
Newline 1302:1303
Newline 1303:1304
Fn 1304:1306
Ident 1307:1311 text="main"
LParen 1311:1312
RParen 1312:1313
LBrace 1314:1315
Newline 1315:1316
Var 1320:1323
Ident 1324:1325 text="o"
Assign 1326:1327
Ident 1328:1336 text="once_new"
LParen 1336:1337
RParen 1337:1338
Newline 1338:1339
Ident 1343:1350 text="println"
LParen 1350:1351
Ident 1351:1359 text="once_run"
LParen 1359:1360
Ident 1360:1361 text="o"
Comma 1361:1362
Fn 1363:1365
LParen 1366:1367
RParen 1367:1368
LBrace 1369:1370
Ident 1371:1378 text="println"
LParen 1378:1379
Str 1379:1389 T("body one")
RParen 1389:1390
RBrace 1391:1392
RParen 1392:1393
RParen 1393:1394
Newline 1394:1395
Ident 1399:1406 text="println"
LParen 1406:1407
Ident 1407:1415 text="once_run"
LParen 1415:1416
Ident 1416:1417 text="o"
Comma 1417:1418
Fn 1419:1421
LParen 1422:1423
RParen 1423:1424
LBrace 1425:1426
Ident 1427:1434 text="println"
LParen 1434:1435
Str 1435:1451 T("body one again")
RParen 1451:1452
RBrace 1453:1454
RParen 1454:1455
RParen 1455:1456
Newline 1456:1457
Ident 1461:1468 text="println"
LParen 1468:1469
Ident 1469:1478 text="once_done"
LParen 1478:1479
Ident 1479:1480 text="o"
RParen 1480:1481
RParen 1481:1482
Newline 1482:1483
Var 1487:1490
Ident 1491:1492 text="p"
Assign 1493:1494
Ident 1495:1503 text="once_new"
LParen 1503:1504
RParen 1504:1505
Newline 1505:1506
Ident 1510:1517 text="println"
LParen 1517:1518
Ident 1518:1527 text="once_done"
LParen 1527:1528
Ident 1528:1529 text="p"
RParen 1529:1530
RParen 1530:1531
Newline 1531:1532
Ident 1536:1543 text="println"
LParen 1543:1544
Ident 1544:1552 text="once_run"
LParen 1552:1553
Ident 1553:1554 text="p"
Comma 1554:1555
Fn 1556:1558
LParen 1559:1560
RParen 1560:1561
LBrace 1562:1563
Ident 1564:1571 text="println"
LParen 1571:1572
Str 1572:1582 T("body two")
RParen 1582:1583
RBrace 1584:1585
RParen 1585:1586
RParen 1586:1587
Newline 1587:1588
Ident 1592:1599 text="println"
LParen 1599:1600
Ident 1600:1609 text="once_done"
LParen 1609:1610
Ident 1610:1611 text="p"
RParen 1611:1612
RParen 1612:1613
Newline 1613:1614
Ident 1618:1625 text="println"
LParen 1625:1626
Ident 1626:1635 text="once_done"
LParen 1635:1636
Ident 1636:1637 text="o"
RParen 1637:1638
RParen 1638:1639
Newline 1639:1640
Ident 1644:1651 text="println"
LParen 1651:1652
Str 1652:1661 T("once ok")
RParen 1661:1662
Newline 1662:1663
RBrace 1663:1664
Eof 1664:1664
