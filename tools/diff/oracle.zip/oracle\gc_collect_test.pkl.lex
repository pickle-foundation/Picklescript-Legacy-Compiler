Newline 77:78
Newline 160:161
Newline 240:241
Newline 319:320
Newline 401:402
Newline 402:403
Ident 403:407 text="test"
Fn 408:410
Ident 411:426 text="force_true_runs"
LParen 426:427
RParen 427:428
LBrace 429:430
Newline 430:431
Ident 435:444 text="gcCollect"
LParen 444:445
True 445:449
RParen 449:450
Newline 450:451
RBrace 451:452
Newline 452:453
Newline 453:454
Ident 454:458 text="test"
Fn 459:461
Ident 462:478 text="force_false_runs"
LParen 478:479
RParen 479:480
LBrace 481:482
Newline 482:483
Ident 487:496 text="gcCollect"
LParen 496:497
False 497:502
RParen 502:503
Newline 503:504
RBrace 504:505
Newline 505:506
Newline 506:507
Ident 507:511 text="test"
Fn 512:514
Ident 515:541 text="force_may_be_an_expression"
LParen 541:542
RParen 542:543
LBrace 544:545
Newline 545:546
Let 550:553
Ident 554:557 text="yes"
Assign 558:559
Number 560:561 text="1" suf="" isf=0 int=1
Plus 562:563
Number 564:565 text="1" suf="" isf=0 int=1
EqEq 566:568
Number 569:570 text="2" suf="" isf=0 int=2
Newline 570:571
Ident 575:584 text="gcCollect"
LParen 584:585
Ident 585:588 text="yes"
RParen 588:589
Newline 589:590
RBrace 590:591
Newline 591:592
Newline 592:593
Ident 593:597 text="test"
Fn 598:600
Ident 601:635 text="collection_does_not_disturb_values"
LParen 635:636
RParen 636:637
LBrace 638:639
Newline 639:640
Newline 717:718
Newline 761:762
Var 766:769
Ident 770:772 text="xs"
Assign 773:774
LBracket 775:776
Number 776:777 text="0" suf="" isf=0 int=0
Comma 777:778
Number 779:780 text="1" suf="" isf=0 int=1
Comma 780:781
Number 782:783 text="2" suf="" isf=0 int=2
Comma 783:784
Number 785:786 text="3" suf="" isf=0 int=3
Comma 786:787
Number 788:789 text="4" suf="" isf=0 int=4
RBracket 789:790
Newline 790:791
Var 795:798
Ident 799:800 text="s"
Assign 801:802
Str 803:811 T("pickle")
Newline 811:812
Ident 816:825 text="gcCollect"
LParen 825:826
True 826:830
RParen 830:831
Newline 831:832
Ident 836:842 text="expect"
LParen 842:843
Ident 843:846 text="len"
LParen 846:847
Ident 847:849 text="xs"
RParen 849:850
RParen 850:851
Dot 851:852
Ident 852:856 text="toBe"
LParen 856:857
Number 857:858 text="5" suf="" isf=0 int=5
RParen 858:859
Newline 859:860
Ident 864:870 text="expect"
LParen 870:871
Ident 871:873 text="xs"
LBracket 873:874
Number 874:875 text="4" suf="" isf=0 int=4
RBracket 875:876
RParen 876:877
Dot 877:878
Ident 878:882 text="toBe"
LParen 882:883
Number 883:884 text="4" suf="" isf=0 int=4
RParen 884:885
Newline 885:886
Ident 890:896 text="expect"
LParen 896:897
Ident 897:898 text="s"
RParen 898:899
Dot 899:900
Ident 900:904 text="toBe"
LParen 904:905
Str 905:913 T("pickle")
RParen 913:914
Newline 914:915
RBrace 915:916
Newline 916:917
Newline 917:918
Ident 918:922 text="test"
Fn 923:925
Ident 926:951 text="collect_around_allocation"
LParen 951:952
RParen 952:953
LBrace 954:955
Newline 955:956
Newline 1032:1033
Newline 1081:1082
Var 1086:1089
Ident 1090:1092 text="xs"
Assign 1093:1094
LBracket 1095:1096
Number 1096:1097 text="0" suf="" isf=0 int=0
RBracket 1097:1098
Newline 1098:1099
For 1103:1106
LParen 1107:1108
Ident 1108:1109 text="i"
In 1110:1112
Ident 1113:1118 text="range"
LParen 1118:1119
Number 1119:1121 text="10" suf="" isf=0 int=10
RParen 1121:1122
RParen 1122:1123
LBrace 1124:1125
Newline 1125:1126
Ident 1134:1136 text="xs"
Dot 1136:1137
Ident 1137:1141 text="push"
LParen 1141:1142
Ident 1142:1143 text="i"
RParen 1143:1144
Newline 1144:1145
RBrace 1149:1150
Newline 1150:1151
Ident 1155:1164 text="gcCollect"
LParen 1164:1165
True 1165:1169
RParen 1169:1170
Newline 1170:1171
Ident 1175:1181 text="expect"
LParen 1181:1182
Ident 1182:1185 text="len"
LParen 1185:1186
Ident 1186:1188 text="xs"
RParen 1188:1189
RParen 1189:1190
Dot 1190:1191
Ident 1191:1195 text="toBe"
LParen 1195:1196
Number 1196:1198 text="11" suf="" isf=0 int=11
RParen 1198:1199
Newline 1199:1200
Ident 1204:1210 text="expect"
LParen 1210:1211
Ident 1211:1213 text="xs"
LBracket 1213:1214
Number 1214:1216 text="10" suf="" isf=0 int=10
RBracket 1216:1217
RParen 1217:1218
Dot 1218:1219
Ident 1219:1223 text="toBe"
LParen 1223:1224
Number 1224:1225 text="9" suf="" isf=0 int=9
RParen 1225:1226
Newline 1226:1227
RBrace 1227:1228
Newline 1228:1229
Eof 1229:1229
