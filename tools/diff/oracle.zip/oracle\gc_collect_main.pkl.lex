Newline 79:80
Newline 154:155
Newline 233:234
Newline 310:311
Newline 374:375
Newline 375:376
Fn 376:378
Ident 379:384 text="build"
LParen 384:385
RParen 385:386
Arrow 387:389
Ident 390:394 text="List"
Lt 394:395
Ident 395:398 text="int"
Gt 398:399
LBrace 400:401
Newline 401:402
Var 406:409
Ident 410:412 text="xs"
Assign 413:414
LBracket 415:416
Number 416:417 text="0" suf="" isf=0 int=0
RBracket 417:418
Newline 418:419
For 423:426
LParen 427:428
Ident 428:429 text="i"
In 430:432
Ident 433:438 text="range"
LParen 438:439
Number 439:440 text="8" suf="" isf=0 int=8
RParen 440:441
RParen 441:442
LBrace 443:444
Newline 444:445
Ident 453:455 text="xs"
Dot 455:456
Ident 456:460 text="push"
LParen 460:461
Ident 461:462 text="i"
Star 463:464
Ident 465:466 text="i"
RParen 466:467
Newline 467:468
RBrace 472:473
Newline 473:474
Ident 478:480 text="xs"
Newline 480:481
RBrace 481:482
Newline 482:483
Newline 483:484
Fn 484:486
Ident 487:491 text="main"
LParen 491:492
RParen 492:493
LBrace 494:495
Newline 495:496
Ident 500:509 text="gcCollect"
LParen 509:510
True 510:514
RParen 514:515
Newline 515:516
Var 520:523
Ident 524:526 text="xs"
Assign 527:528
Ident 529:534 text="build"
LParen 534:535
RParen 535:536
Newline 536:537
Ident 541:550 text="gcCollect"
LParen 550:551
False 551:556
RParen 556:557
Newline 557:558
Ident 562:569 text="println"
LParen 569:570
Str 570:576 T("len=")
Plus 577:578
Ident 579:582 text="str"
LParen 582:583
Ident 583:586 text="len"
LParen 586:587
Ident 587:589 text="xs"
RParen 589:590
RParen 590:591
RParen 591:592
Newline 592:593
Ident 597:604 text="println"
LParen 604:605
Str 605:611 T("sum=")
Plus 612:613
Ident 614:617 text="str"
LParen 617:618
Ident 618:620 text="xs"
LBracket 620:621
Number 621:622 text="1" suf="" isf=0 int=1
RBracket 622:623
Plus 624:625
Ident 626:628 text="xs"
LBracket 628:629
Number 629:630 text="2" suf="" isf=0 int=2
RBracket 630:631
Plus 632:633
Ident 634:636 text="xs"
LBracket 636:637
Number 637:638 text="3" suf="" isf=0 int=3
RBracket 638:639
RParen 639:640
RParen 640:641
Newline 641:642
Ident 646:655 text="gcCollect"
LParen 655:656
True 656:660
RParen 660:661
Newline 661:662
Ident 666:673 text="println"
LParen 673:674
Str 674:682 T("after=")
Plus 683:684
Ident 685:688 text="str"
LParen 688:689
Ident 689:691 text="xs"
LBracket 691:692
Number 692:693 text="8" suf="" isf=0 int=8
RBracket 693:694
RParen 694:695
RParen 695:696
Newline 696:697
RBrace 697:698
Newline 698:699
Eof 699:699
