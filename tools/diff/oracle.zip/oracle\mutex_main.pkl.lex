Newline 77:78
Newline 149:150
Newline 229:230
Newline 304:305
Newline 350:351
Newline 353:354
Newline 432:433
Newline 479:480
Newline 480:481
Fn 481:483
Ident 484:488 text="main"
LParen 488:489
RParen 489:490
LBrace 491:492
Newline 492:493
Newline 553:554
Let 558:561
Ident 562:563 text="m"
Assign 564:565
Ident 566:575 text="mutex_new"
LParen 575:576
RParen 576:577
Newline 577:578
Ident 582:588 text="expect"
LParen 588:589
Ident 589:602 text="mutex_trylock"
LParen 602:603
Ident 603:604 text="m"
RParen 604:605
RParen 605:606
Dot 606:607
Ident 607:611 text="toBe"
LParen 611:612
True 612:616
RParen 616:617
Newline 617:618
Newline 618:619
Newline 690:691
Ident 695:701 text="expect"
LParen 701:702
Ident 702:715 text="mutex_trylock"
LParen 715:716
Ident 716:717 text="m"
RParen 717:718
RParen 718:719
Dot 719:720
Ident 720:724 text="toBe"
LParen 724:725
False 725:730
RParen 730:731
Newline 731:732
Newline 732:733
Newline 789:790
Ident 794:800 text="expect"
LParen 800:801
Ident 801:814 text="mutex_trylock"
LParen 814:815
Ident 815:816 text="m"
RParen 816:817
RParen 817:818
Dot 818:819
Ident 819:823 text="toBe"
LParen 823:824
False 824:829
RParen 829:830
Newline 830:831
Newline 831:832
Newline 876:877
Ident 881:893 text="mutex_unlock"
LParen 893:894
Ident 894:895 text="m"
RParen 895:896
Newline 896:897
Ident 901:907 text="expect"
LParen 907:908
Ident 908:921 text="mutex_trylock"
LParen 921:922
Ident 922:923 text="m"
RParen 923:924
RParen 924:925
Dot 925:926
Ident 926:930 text="toBe"
LParen 930:931
True 931:935
RParen 935:936
Newline 936:937
Ident 941:953 text="mutex_unlock"
LParen 953:954
Ident 954:955 text="m"
RParen 955:956
Newline 956:957
Newline 957:958
Newline 1023:1024
Let 1028:1031
Ident 1032:1033 text="n"
Assign 1034:1035
Ident 1036:1045 text="mutex_new"
LParen 1045:1046
RParen 1046:1047
Newline 1047:1048
Ident 1052:1062 text="mutex_lock"
LParen 1062:1063
Ident 1063:1064 text="m"
RParen 1064:1065
Newline 1065:1066
Ident 1070:1080 text="mutex_lock"
LParen 1080:1081
Ident 1081:1082 text="n"
RParen 1082:1083
Newline 1083:1084
Ident 1088:1100 text="mutex_unlock"
LParen 1100:1101
Ident 1101:1102 text="n"
RParen 1102:1103
Newline 1103:1104
Ident 1108:1120 text="mutex_unlock"
LParen 1120:1121
Ident 1121:1122 text="m"
RParen 1122:1123
Newline 1123:1124
Ident 1128:1134 text="expect"
LParen 1134:1135
Ident 1135:1148 text="mutex_trylock"
LParen 1148:1149
Ident 1149:1150 text="m"
RParen 1150:1151
RParen 1151:1152
Dot 1152:1153
Ident 1153:1157 text="toBe"
LParen 1157:1158
True 1158:1162
RParen 1162:1163
Newline 1163:1164
Ident 1168:1174 text="expect"
LParen 1174:1175
Ident 1175:1188 text="mutex_trylock"
LParen 1188:1189
Ident 1189:1190 text="n"
RParen 1190:1191
RParen 1191:1192
Dot 1192:1193
Ident 1193:1197 text="toBe"
LParen 1197:1198
True 1198:1202
RParen 1202:1203
Newline 1203:1204
Ident 1208:1220 text="mutex_unlock"
LParen 1220:1221
Ident 1221:1222 text="m"
RParen 1222:1223
Newline 1223:1224
Ident 1228:1240 text="mutex_unlock"
LParen 1240:1241
Ident 1241:1242 text="n"
RParen 1242:1243
Newline 1243:1244
Newline 1244:1245
Newline 1310:1311
Let 1315:1318
Ident 1319:1320 text="a"
Assign 1321:1322
Ident 1323:1332 text="mutex_new"
LParen 1332:1333
RParen 1333:1334
Newline 1334:1335
Let 1339:1342
Ident 1343:1344 text="b"
Assign 1345:1346
Ident 1347:1356 text="mutex_new"
LParen 1356:1357
RParen 1357:1358
Newline 1358:1359
Ident 1363:1369 text="expect"
LParen 1369:1370
Ident 1370:1383 text="mutex_trylock"
LParen 1383:1384
Ident 1384:1385 text="a"
RParen 1385:1386
RParen 1386:1387
Dot 1387:1388
Ident 1388:1392 text="toBe"
LParen 1392:1393
True 1393:1397
RParen 1397:1398
Newline 1398:1399
Ident 1403:1409 text="expect"
LParen 1409:1410
Ident 1410:1423 text="mutex_trylock"
LParen 1423:1424
Ident 1424:1425 text="b"
RParen 1425:1426
RParen 1426:1427
Dot 1427:1428
Ident 1428:1432 text="toBe"
LParen 1432:1433
True 1433:1437
RParen 1437:1438
Newline 1438:1439
Ident 1443:1449 text="expect"
LParen 1449:1450
Ident 1450:1463 text="mutex_trylock"
LParen 1463:1464
Ident 1464:1465 text="a"
RParen 1465:1466
RParen 1466:1467
Dot 1467:1468
Ident 1468:1472 text="toBe"
LParen 1472:1473
False 1473:1478
RParen 1478:1479
Newline 1479:1480
Ident 1484:1496 text="mutex_unlock"
LParen 1496:1497
Ident 1497:1498 text="a"
RParen 1498:1499
Newline 1499:1500
Ident 1504:1516 text="mutex_unlock"
LParen 1516:1517
Ident 1517:1518 text="b"
RParen 1518:1519
Newline 1519:1520
Newline 1520:1521
Newline 1598:1599
Newline 1664:1665
Let 1669:1672
Ident 1673:1674 text="c"
Assign 1675:1676
Ident 1677:1686 text="mutex_new"
LParen 1686:1687
RParen 1687:1688
Newline 1688:1689
Ident 1693:1705 text="mutex_unlock"
LParen 1705:1706
Ident 1706:1707 text="c"
RParen 1707:1708
Newline 1708:1709
Ident 1713:1719 text="expect"
LParen 1719:1720
Ident 1720:1733 text="mutex_trylock"
LParen 1733:1734
Ident 1734:1735 text="c"
RParen 1735:1736
RParen 1736:1737
Dot 1737:1738
Ident 1738:1742 text="toBe"
LParen 1742:1743
True 1743:1747
RParen 1747:1748
Newline 1748:1749
Ident 1753:1765 text="mutex_unlock"
LParen 1765:1766
Ident 1766:1767 text="c"
RParen 1767:1768
Newline 1768:1769
Newline 1769:1770
Ident 1774:1781 text="println"
LParen 1781:1782
Str 1782:1792 T("mutex ok")
RParen 1792:1793
Newline 1793:1794
RBrace 1794:1795
Newline 1795:1796
Eof 1796:1796
