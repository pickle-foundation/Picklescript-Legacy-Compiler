Module 0:6
Ident 7:11 text="main"
Newline 12:13
Newline 14:15
Class 15:20
Ident 21:26 text="Point"
LBrace 27:28
Newline 29:30
Var 34:37
Ident 38:39 text="x"
Assign 40:41
Number 42:43 text="0" suf="" isf=0 int=0
Newline 44:45
Var 49:52
Ident 53:54 text="y"
Assign 55:56
Number 57:58 text="0" suf="" isf=0 int=0
Newline 59:60
RBrace 60:61
Newline 62:63
Newline 64:65
Enum 65:69
Ident 70:75 text="Color"
LBrace 76:77
Newline 78:79
Ident 83:86 text="Red"
Newline 87:88
Ident 92:97 text="Green"
Newline 98:99
Ident 103:107 text="Blue"
LParen 107:108
Ident 108:109 text="v"
Colon 109:110
Ident 111:114 text="int"
RParen 114:115
Newline 116:117
RBrace 117:118
Newline 119:120
Newline 121:122
Newline 203:204
Newline 267:268
Fn 268:270 doc="A generic parameter has no static rep, so the argument is boxed. That is the\nonly way to reach the BOX_* arms of print_obj from source."
Ident 271:275 text="show"
Lt 275:276
Ident 276:277 text="T"
Gt 277:278
LParen 278:279
Ident 279:280 text="x"
Colon 280:281
Ident 282:283 text="T"
RParen 283:284
LBrace 285:286
Newline 287:288
Ident 292:297 text="print"
LParen 297:298
Ident 298:299 text="x"
RParen 299:300
Newline 301:302
Ident 306:313 text="println"
LParen 313:314
Str 314:316
RParen 316:317
Newline 318:319
RBrace 319:320
Newline 321:322
Newline 323:324
Fn 324:326
Ident 327:331 text="main"
LParen 331:332
RParen 332:333
LBrace 334:335
Newline 336:337
Ident 341:346 text="print"
LParen 346:347
Str 347:354 T("hello")
RParen 354:355
Newline 356:357
Ident 361:368 text="println"
LParen 368:369
Str 369:371
RParen 371:372
Newline 373:374
Ident 378:383 text="print"
LParen 383:384
Str 384:386
RParen 386:387
Newline 388:389
Var 393:396
Ident 397:399 text="xs"
Colon 399:400
Ident 401:405 text="List"
Lt 405:406
Ident 406:409 text="int"
Gt 409:410
Assign 411:412
LBracket 413:414
Number 414:415 text="1" suf="" isf=0 int=1
Comma 415:416
Number 417:418 text="2" suf="" isf=0 int=2
Comma 418:419
Number 420:421 text="3" suf="" isf=0 int=3
RBracket 421:422
Newline 423:424
Ident 428:433 text="print"
LParen 433:434
Ident 434:436 text="xs"
RParen 436:437
Newline 438:439
Ident 443:450 text="println"
LParen 450:451
Str 451:453
RParen 453:454
Newline 455:456
Var 460:463
Ident 464:466 text="es"
Assign 467:468
Ident 469:474 text="range"
LParen 474:475
Number 475:476 text="0" suf="" isf=0 int=0
RParen 476:477
Newline 478:479
Ident 483:488 text="print"
LParen 488:489
Ident 489:491 text="es"
RParen 491:492
Newline 493:494
Ident 498:505 text="println"
LParen 505:506
Str 506:508
RParen 508:509
Newline 510:511
Var 515:518
Ident 519:520 text="m"
Colon 520:521
Ident 522:525 text="Map"
Lt 525:526
Ident 526:532 text="string"
Comma 532:533
Ident 534:537 text="int"
Gt 537:538
Assign 539:540
LBrace 541:542
Str 542:545 T("a")
Colon 545:546
Number 547:548 text="1" suf="" isf=0 int=1
Comma 548:549
Str 550:553 T("b")
Colon 553:554
Number 555:556 text="2" suf="" isf=0 int=2
RBrace 556:557
Newline 558:559
Ident 563:568 text="print"
LParen 568:569
Ident 569:570 text="m"
RParen 570:571
Newline 572:573
Ident 577:584 text="println"
LParen 584:585
Str 585:587
RParen 587:588
Newline 589:590
Ident 594:599 text="print"
LParen 599:600
Ident 600:605 text="Color"
Dot 605:606
Ident 606:609 text="Red"
RParen 609:610
Newline 611:612
Ident 616:623 text="println"
LParen 623:624
Str 624:626
RParen 626:627
Newline 628:629
Ident 633:638 text="print"
LParen 638:639
Ident 639:644 text="Color"
Dot 644:645
Ident 645:650 text="Green"
RParen 650:651
Newline 652:653
Ident 657:664 text="println"
LParen 664:665
Str 665:667
RParen 667:668
Newline 669:670
Ident 674:679 text="print"
LParen 679:680
Ident 680:685 text="Color"
Dot 685:686
Ident 686:690 text="Blue"
LParen 690:691
Number 691:692 text="7" suf="" isf=0 int=7
RParen 692:693
RParen 693:694
Newline 695:696
Ident 700:707 text="println"
LParen 707:708
Str 708:710
RParen 710:711
Newline 712:713
Var 717:720
Ident 721:723 text="ts"
Colon 723:724
Ident 725:729 text="List"
Lt 729:730
LParen 730:731
Ident 731:734 text="int"
Comma 734:735
Ident 736:742 text="string"
RParen 742:743
Gt 743:744
Assign 745:746
LBracket 747:748
LParen 748:749
Number 749:750 text="1" suf="" isf=0 int=1
Comma 750:751
Str 752:755 T("a")
RParen 755:756
Comma 756:757
LParen 758:759
Number 759:760 text="2" suf="" isf=0 int=2
Comma 760:761
Str 762:765 T("b")
RParen 765:766
RBracket 766:767
Newline 768:769
Ident 773:778 text="print"
LParen 778:779
Ellipsis 779:782
Ident 782:784 text="ts"
RParen 784:785
Newline 786:787
Ident 791:798 text="println"
LParen 798:799
Str 799:801
RParen 801:802
Newline 803:804
Var 808:811
Ident 812:813 text="p"
Assign 814:815
Ident 816:821 text="Point"
LParen 821:822
RParen 822:823
Newline 824:825
Ident 829:830 text="p"
Dot 830:831
Ident 831:832 text="x"
Assign 833:834
Number 835:836 text="3" suf="" isf=0 int=3
Newline 837:838
Ident 842:847 text="print"
LParen 847:848
Ident 848:849 text="p"
RParen 849:850
Newline 851:852
Ident 856:863 text="println"
LParen 863:864
Str 864:866
RParen 866:867
Newline 868:869
Ident 873:877 text="show"
LParen 877:878
Number 878:880 text="42" suf="" isf=0 int=42
RParen 880:881
Newline 882:883
Ident 887:891 text="show"
LParen 891:892
Minus 892:893
Number 893:895 text="42" suf="" isf=0 int=42
RParen 895:896
Newline 897:898
Ident 902:906 text="show"
LParen 906:907
Number 907:911 text="1.25" suf="" isf=1 int=-
RParen 911:912
Newline 913:914
Ident 918:922 text="show"
LParen 922:923
Number 923:926 text="0.1" suf="" isf=1 int=-
RParen 926:927
Newline 928:929
Ident 933:937 text="show"
LParen 937:938
Minus 938:939
Number 939:942 text="0.0" suf="" isf=1 int=-
RParen 942:943
Newline 944:945
Ident 949:953 text="show"
LParen 953:954
Number 954:959 text="1e308" suf="" isf=1 int=-
Star 960:961
Number 962:966 text="10.0" suf="" isf=1 int=-
RParen 966:967
Newline 968:969
Ident 973:977 text="show"
LParen 977:978
True 978:982
RParen 982:983
Newline 984:985
Ident 989:993 text="show"
LParen 993:994
False 994:999
RParen 999:1000
Newline 1001:1002
Ident 1006:1010 text="show"
LParen 1010:1011
Char 1011:1014 ch='q' int=113
RParen 1014:1015
Newline 1016:1017
Ident 1021:1025 text="show"
LParen 1025:1026
Char 1026:1029 ch='Z' int=90
RParen 1029:1030
Newline 1031:1032
Ident 1036:1040 text="show"
LParen 1040:1041
Str 1041:1051 T("é")
RParen 1051:1052
Newline 1053:1054
RBrace 1054:1055
Newline 1056:1057
Eof 1057:1057
