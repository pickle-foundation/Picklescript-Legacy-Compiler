Newline 75:76
Newline 153:154
Newline 219:220
Newline 267:268
Newline 270:271
Newline 349:350
Newline 421:422
Newline 486:487
Newline 563:564
Newline 643:644
Newline 721:722
Newline 800:801
Newline 880:881
Newline 935:936
Newline 938:939
Newline 1018:1019
Newline 1093:1094
Newline 1172:1173
Newline 1250:1251
Newline 1320:1321
Newline 1323:1324
Newline 1402:1403
Newline 1480:1481
Newline 1559:1560
Newline 1634:1635
Newline 1635:1636
Import 1636:1642
LBrace 1643:1644
Ident 1645:1656 text="abiMutexNew"
RBrace 1657:1658
From 1659:1663
Ident 1664:1671 text="runtime"
Dot 1671:1672
Ident 1672:1680 text="abi_sync"
Newline 1680:1681
Newline 1681:1682
Fn 1682:1684
Ident 1685:1689 text="main"
LParen 1689:1690
RParen 1690:1691
LBrace 1692:1693
Newline 1693:1694
Newline 1772:1773
Let 1777:1780
Ident 1781:1782 text="m"
Assign 1783:1784
Ident 1785:1794 text="mutex_new"
LParen 1794:1795
RParen 1795:1796
Newline 1796:1797
Let 1801:1804
Ident 1805:1806 text="c"
Assign 1807:1808
Ident 1809:1817 text="cond_new"
LParen 1817:1818
RParen 1818:1819
Newline 1819:1820
Let 1824:1827
Ident 1828:1829 text="s"
Assign 1830:1831
Ident 1832:1839 text="sem_new"
LParen 1839:1840
Number 1840:1841 text="2" suf="" isf=0 int=2
RParen 1841:1842
Newline 1842:1843
Let 1847:1850
Ident 1851:1852 text="a"
Assign 1853:1854
Ident 1855:1865 text="atomic_new"
LParen 1865:1866
Number 1866:1867 text="5" suf="" isf=0 int=5
RParen 1867:1868
Newline 1868:1869
Let 1873:1876
Ident 1877:1879 text="ch"
Assign 1880:1881
Ident 1882:1893 text="channel_new"
LParen 1893:1894
Number 1894:1895 text="3" suf="" isf=0 int=3
RParen 1895:1896
Newline 1896:1897
Ident 1901:1908 text="println"
LParen 1908:1909
Ident 1909:1910 text="m"
RParen 1910:1911
Newline 1911:1912
Ident 1916:1923 text="println"
LParen 1923:1924
Ident 1924:1925 text="c"
RParen 1925:1926
Newline 1926:1927
Ident 1931:1938 text="println"
LParen 1938:1939
Ident 1939:1940 text="s"
RParen 1940:1941
Newline 1941:1942
Ident 1946:1953 text="println"
LParen 1953:1954
Ident 1954:1955 text="a"
RParen 1955:1956
Newline 1956:1957
Ident 1961:1968 text="println"
LParen 1968:1969
Ident 1969:1971 text="ch"
RParen 1971:1972
Newline 1972:1973
Newline 1973:1974
Newline 2032:2033
Ident 2037:2044 text="println"
LParen 2044:2045
Ident 2045:2058 text="mutex_trylock"
LParen 2058:2059
Ident 2059:2060 text="m"
RParen 2060:2061
RParen 2061:2062
Newline 2062:2063
Ident 2067:2074 text="println"
LParen 2074:2075
Ident 2075:2088 text="mutex_trylock"
LParen 2088:2089
Ident 2089:2090 text="m"
RParen 2090:2091
RParen 2091:2092
Newline 2092:2093
Ident 2097:2109 text="mutex_unlock"
LParen 2109:2110
Ident 2110:2111 text="m"
RParen 2111:2112
Newline 2112:2113
Ident 2117:2124 text="println"
LParen 2124:2125
Ident 2125:2138 text="mutex_trylock"
LParen 2138:2139
Ident 2139:2140 text="m"
RParen 2140:2141
RParen 2141:2142
Newline 2142:2143
Ident 2147:2159 text="mutex_unlock"
LParen 2159:2160
Ident 2160:2161 text="m"
RParen 2161:2162
Newline 2162:2163
Ident 2167:2179 text="mutex_unlock"
LParen 2179:2180
Ident 2180:2181 text="m"
RParen 2181:2182
Newline 2182:2183
Ident 2187:2194 text="println"
LParen 2194:2195
Ident 2195:2208 text="mutex_trylock"
LParen 2208:2209
Ident 2209:2210 text="m"
RParen 2210:2211
RParen 2211:2212
Newline 2212:2213
Ident 2217:2229 text="mutex_unlock"
LParen 2229:2230
Ident 2230:2231 text="m"
RParen 2231:2232
Newline 2232:2233
Ident 2237:2247 text="mutex_lock"
LParen 2247:2248
Ident 2248:2249 text="m"
RParen 2249:2250
Newline 2250:2251
Ident 2255:2262 text="println"
LParen 2262:2263
Ident 2263:2276 text="mutex_trylock"
LParen 2276:2277
Ident 2277:2278 text="m"
RParen 2278:2279
RParen 2279:2280
Newline 2280:2281
Ident 2285:2297 text="mutex_unlock"
LParen 2297:2298
Ident 2298:2299 text="m"
RParen 2299:2300
Newline 2300:2301
Newline 2301:2302
Newline 2371:2372
Ident 2376:2387 text="cond_signal"
LParen 2387:2388
Ident 2388:2389 text="c"
RParen 2389:2390
Newline 2390:2391
Ident 2395:2404 text="cond_wait"
LParen 2404:2405
Ident 2405:2406 text="c"
Comma 2406:2407
Number 2408:2409 text="0" suf="" isf=0 int=0
RParen 2409:2410
Newline 2410:2411
Ident 2415:2426 text="cond_signal"
LParen 2426:2427
Ident 2427:2428 text="c"
RParen 2428:2429
Newline 2429:2430
Ident 2434:2443 text="cond_wait"
LParen 2443:2444
Ident 2444:2445 text="c"
Comma 2445:2446
Ident 2447:2448 text="m"
RParen 2448:2449
Newline 2449:2450
Newline 2506:2507
Ident 2511:2518 text="println"
LParen 2518:2519
Ident 2519:2532 text="mutex_trylock"
LParen 2532:2533
Ident 2533:2534 text="m"
RParen 2534:2535
RParen 2535:2536
Newline 2536:2537
Ident 2541:2553 text="mutex_unlock"
LParen 2553:2554
Ident 2554:2555 text="m"
RParen 2555:2556
Newline 2556:2557
Ident 2561:2575 text="cond_broadcast"
LParen 2575:2576
Ident 2576:2577 text="c"
RParen 2577:2578
Newline 2578:2579
Ident 2583:2594 text="cond_signal"
LParen 2594:2595
Ident 2595:2596 text="c"
RParen 2596:2597
Newline 2597:2598
Ident 2602:2611 text="cond_wait"
LParen 2611:2612
Ident 2612:2613 text="c"
Comma 2613:2614
Number 2615:2616 text="0" suf="" isf=0 int=0
RParen 2616:2617
Newline 2617:2618
Newline 2618:2619
Newline 2687:2688
Ident 2692:2699 text="println"
LParen 2699:2700
Ident 2700:2715 text="sem_try_acquire"
LParen 2715:2716
Ident 2716:2717 text="s"
Comma 2717:2718
Number 2719:2720 text="1" suf="" isf=0 int=1
RParen 2720:2721
RParen 2721:2722
Newline 2722:2723
Ident 2727:2734 text="println"
LParen 2734:2735
Ident 2735:2750 text="sem_try_acquire"
LParen 2750:2751
Ident 2751:2752 text="s"
Comma 2752:2753
Number 2754:2755 text="1" suf="" isf=0 int=1
RParen 2755:2756
RParen 2756:2757
Newline 2757:2758
Ident 2762:2769 text="println"
LParen 2769:2770
Ident 2770:2785 text="sem_try_acquire"
LParen 2785:2786
Ident 2786:2787 text="s"
Comma 2787:2788
Number 2789:2790 text="1" suf="" isf=0 int=1
RParen 2790:2791
RParen 2791:2792
Newline 2792:2793
Ident 2797:2808 text="sem_release"
LParen 2808:2809
Ident 2809:2810 text="s"
Comma 2810:2811
Number 2812:2813 text="1" suf="" isf=0 int=1
RParen 2813:2814
Newline 2814:2815
Ident 2819:2826 text="println"
LParen 2826:2827
Ident 2827:2842 text="sem_try_acquire"
LParen 2842:2843
Ident 2843:2844 text="s"
Comma 2844:2845
Number 2846:2847 text="1" suf="" isf=0 int=1
RParen 2847:2848
RParen 2848:2849
Newline 2849:2850
Ident 2854:2861 text="println"
LParen 2861:2862
Ident 2862:2877 text="sem_try_acquire"
LParen 2877:2878
Ident 2878:2879 text="s"
Comma 2879:2880
Number 2881:2882 text="1" suf="" isf=0 int=1
RParen 2882:2883
RParen 2883:2884
Newline 2884:2885
Let 2889:2892
Ident 2893:2896 text="neg"
Assign 2897:2898
Ident 2899:2906 text="sem_new"
LParen 2906:2907
Minus 2907:2908
Number 2908:2909 text="2" suf="" isf=0 int=2
RParen 2909:2910
Newline 2910:2911
Ident 2915:2922 text="println"
LParen 2922:2923
Ident 2923:2938 text="sem_try_acquire"
LParen 2938:2939
Ident 2939:2942 text="neg"
Comma 2942:2943
Number 2944:2945 text="1" suf="" isf=0 int=1
RParen 2945:2946
RParen 2946:2947
Newline 2947:2948
Ident 2952:2963 text="sem_release"
LParen 2963:2964
Ident 2964:2967 text="neg"
Comma 2967:2968
Number 2969:2970 text="0" suf="" isf=0 int=0
RParen 2970:2971
Newline 2971:2972
Ident 2976:2983 text="println"
LParen 2983:2984
Ident 2984:2999 text="sem_try_acquire"
LParen 2999:3000
Ident 3000:3003 text="neg"
Comma 3003:3004
Number 3005:3006 text="1" suf="" isf=0 int=1
RParen 3006:3007
RParen 3007:3008
Newline 3008:3009
Ident 3013:3024 text="sem_release"
LParen 3024:3025
Ident 3025:3028 text="neg"
Comma 3028:3029
Number 3030:3031 text="1" suf="" isf=0 int=1
RParen 3031:3032
Newline 3032:3033
Ident 3037:3044 text="println"
LParen 3044:3045
Ident 3045:3060 text="sem_try_acquire"
LParen 3060:3061
Ident 3061:3064 text="neg"
Comma 3064:3065
Number 3066:3067 text="1" suf="" isf=0 int=1
RParen 3067:3068
RParen 3068:3069
Newline 3069:3070
Ident 3074:3081 text="println"
LParen 3081:3082
Ident 3082:3097 text="sem_try_acquire"
LParen 3097:3098
Ident 3098:3101 text="neg"
Comma 3101:3102
Number 3103:3104 text="1" suf="" isf=0 int=1
RParen 3104:3105
RParen 3105:3106
Newline 3106:3107
Let 3111:3114
Ident 3115:3117 text="su"
Assign 3118:3119
Ident 3120:3127 text="sem_new"
LParen 3127:3128
Number 3128:3129 text="0" suf="" isf=0 int=0
RParen 3129:3130
Newline 3130:3131
Ident 3135:3146 text="sem_release"
LParen 3146:3147
Ident 3147:3149 text="su"
Comma 3149:3150
Number 3151:3152 text="1" suf="" isf=0 int=1
RParen 3152:3153
Newline 3153:3154
Ident 3158:3169 text="sem_acquire"
LParen 3169:3170
Ident 3170:3172 text="su"
Comma 3172:3173
Number 3174:3175 text="1" suf="" isf=0 int=1
RParen 3175:3176
Newline 3176:3177
Newline 3177:3178
Newline 3255:3256
Ident 3260:3267 text="println"
LParen 3267:3268
Ident 3268:3279 text="atomic_load"
LParen 3279:3280
Ident 3280:3281 text="a"
RParen 3281:3282
RParen 3282:3283
Newline 3283:3284
Ident 3288:3295 text="println"
LParen 3295:3296
Ident 3296:3306 text="atomic_add"
LParen 3306:3307
Ident 3307:3308 text="a"
Comma 3308:3309
Number 3310:3311 text="3" suf="" isf=0 int=3
RParen 3311:3312
RParen 3312:3313
Newline 3313:3314
Ident 3318:3325 text="println"
LParen 3325:3326
Ident 3326:3337 text="atomic_load"
LParen 3337:3338
Ident 3338:3339 text="a"
RParen 3339:3340
RParen 3340:3341
Newline 3341:3342
Ident 3346:3358 text="atomic_store"
LParen 3358:3359
Ident 3359:3360 text="a"
Comma 3360:3361
Number 3362:3363 text="1" suf="" isf=0 int=1
RParen 3363:3364
Newline 3364:3365
Ident 3369:3376 text="println"
LParen 3376:3377
Ident 3377:3387 text="atomic_cas"
LParen 3387:3388
Ident 3388:3389 text="a"
Comma 3389:3390
Number 3391:3392 text="1" suf="" isf=0 int=1
Comma 3392:3393
Number 3394:3395 text="9" suf="" isf=0 int=9
RParen 3395:3396
RParen 3396:3397
Newline 3397:3398
Ident 3402:3409 text="println"
LParen 3409:3410
Ident 3410:3421 text="atomic_load"
LParen 3421:3422
Ident 3422:3423 text="a"
RParen 3423:3424
RParen 3424:3425
Newline 3425:3426
Ident 3430:3437 text="println"
LParen 3437:3438
Ident 3438:3448 text="atomic_cas"
LParen 3448:3449
Ident 3449:3450 text="a"
Comma 3450:3451
Number 3452:3453 text="1" suf="" isf=0 int=1
Comma 3453:3454
Number 3455:3456 text="0" suf="" isf=0 int=0
RParen 3456:3457
RParen 3457:3458
Newline 3458:3459
Ident 3463:3470 text="println"
LParen 3470:3471
Ident 3471:3482 text="atomic_load"
LParen 3482:3483
Ident 3483:3484 text="a"
RParen 3484:3485
RParen 3485:3486
Newline 3486:3487
Newline 3487:3488
Newline 3556:3557
Ident 3561:3568 text="println"
LParen 3568:3569
Ident 3569:3580 text="channel_cap"
LParen 3580:3581
Ident 3581:3583 text="ch"
RParen 3583:3584
RParen 3584:3585
Newline 3585:3586
Ident 3590:3597 text="println"
LParen 3597:3598
Ident 3598:3609 text="channel_len"
LParen 3609:3610
Ident 3610:3612 text="ch"
RParen 3612:3613
RParen 3613:3614
Newline 3614:3615
Let 3619:3622
Ident 3623:3625 text="e0"
Assign 3626:3627
Ident 3628:3644 text="channel_try_recv"
LParen 3644:3645
Ident 3645:3647 text="ch"
RParen 3647:3648
Newline 3648:3649
If 3653:3655
LParen 3656:3657
Let 3657:3660
Ident 3661:3665 text="some"
LParen 3665:3666
Ident 3666:3668 text="v0"
RParen 3668:3669
Assign 3670:3671
Ident 3672:3674 text="e0"
RParen 3674:3675
LBrace 3676:3677
Ident 3678:3685 text="println"
LParen 3685:3686
Ident 3686:3688 text="v0"
RParen 3688:3689
RBrace 3690:3691
Else 3692:3696
LBrace 3697:3698
Ident 3699:3706 text="println"
LParen 3706:3707
Str 3707:3713 T("none")
RParen 3713:3714
RBrace 3715:3716
Newline 3716:3717
Ident 3721:3728 text="println"
LParen 3728:3729
Ident 3729:3745 text="channel_try_send"
LParen 3745:3746
Ident 3746:3748 text="ch"
Comma 3748:3749
Number 3750:3752 text="42" suf="" isf=0 int=42
RParen 3752:3753
RParen 3753:3754
Newline 3754:3755
Ident 3759:3766 text="println"
LParen 3766:3767
Ident 3767:3778 text="channel_len"
LParen 3778:3779
Ident 3779:3781 text="ch"
RParen 3781:3782
RParen 3782:3783
Newline 3783:3784
Let 3788:3791
Ident 3792:3794 text="g1"
Assign 3795:3796
Ident 3797:3813 text="channel_try_recv"
LParen 3813:3814
Ident 3814:3816 text="ch"
RParen 3816:3817
Newline 3817:3818
If 3822:3824
LParen 3825:3826
Let 3826:3829
Ident 3830:3834 text="some"
LParen 3834:3835
Ident 3835:3837 text="v1"
RParen 3837:3838
Assign 3839:3840
Ident 3841:3843 text="g1"
RParen 3843:3844
LBrace 3845:3846
Ident 3847:3854 text="println"
LParen 3854:3855
Ident 3855:3857 text="v1"
RParen 3857:3858
RBrace 3859:3860
Else 3861:3865
LBrace 3866:3867
Ident 3868:3875 text="println"
LParen 3875:3876
Str 3876:3882 T("none")
RParen 3882:3883
RBrace 3884:3885
Newline 3885:3886
Ident 3890:3897 text="println"
LParen 3897:3898
Ident 3898:3909 text="channel_len"
LParen 3909:3910
Ident 3910:3912 text="ch"
RParen 3912:3913
RParen 3913:3914
Newline 3914:3915
Ident 3919:3931 text="channel_send"
LParen 3931:3932
Ident 3932:3934 text="ch"
Comma 3934:3935
Number 3936:3938 text="43" suf="" isf=0 int=43
RParen 3938:3939
Newline 3939:3940
Ident 3944:3956 text="channel_send"
LParen 3956:3957
Ident 3957:3959 text="ch"
Comma 3959:3960
Number 3961:3963 text="44" suf="" isf=0 int=44
RParen 3963:3964
Newline 3964:3965
Ident 3969:3976 text="println"
LParen 3976:3977
Ident 3977:3989 text="channel_recv"
LParen 3989:3990
Ident 3990:3992 text="ch"
RParen 3992:3993
RParen 3993:3994
Newline 3994:3995
Ident 3999:4006 text="println"
LParen 4006:4007
Ident 4007:4019 text="channel_recv"
LParen 4019:4020
Ident 4020:4022 text="ch"
RParen 4022:4023
RParen 4023:4024
Newline 4024:4025
Let 4029:4032
Ident 4033:4034 text="b"
Assign 4035:4036
Ident 4037:4048 text="channel_new"
LParen 4048:4049
Number 4049:4050 text="1" suf="" isf=0 int=1
RParen 4050:4051
Newline 4051:4052
Ident 4056:4063 text="println"
LParen 4063:4064
Ident 4064:4080 text="channel_try_send"
LParen 4080:4081
Ident 4081:4082 text="b"
Comma 4082:4083
Number 4084:4086 text="49" suf="" isf=0 int=49
RParen 4086:4087
RParen 4087:4088
Newline 4088:4089
Ident 4093:4100 text="println"
LParen 4100:4101
Ident 4101:4117 text="channel_try_send"
LParen 4117:4118
Ident 4118:4119 text="b"
Comma 4119:4120
Number 4121:4123 text="50" suf="" isf=0 int=50
RParen 4123:4124
RParen 4124:4125
Newline 4125:4126
Ident 4130:4137 text="println"
LParen 4137:4138
Ident 4138:4150 text="channel_recv"
LParen 4150:4151
Ident 4151:4152 text="b"
RParen 4152:4153
RParen 4153:4154
Newline 4154:4155
Ident 4159:4166 text="println"
LParen 4166:4167
Ident 4167:4183 text="channel_try_send"
LParen 4183:4184
Ident 4184:4185 text="b"
Comma 4185:4186
Number 4187:4189 text="51" suf="" isf=0 int=51
RParen 4189:4190
RParen 4190:4191
Newline 4191:4192
Let 4196:4199
Ident 4200:4201 text="r"
Assign 4202:4203
Ident 4204:4215 text="channel_new"
LParen 4215:4216
Number 4216:4217 text="2" suf="" isf=0 int=2
RParen 4217:4218
Newline 4218:4219
Ident 4223:4235 text="channel_send"
LParen 4235:4236
Ident 4236:4237 text="r"
Comma 4237:4238
Number 4239:4241 text="10" suf="" isf=0 int=10
RParen 4241:4242
Newline 4242:4243
Ident 4247:4259 text="channel_send"
LParen 4259:4260
Ident 4260:4261 text="r"
Comma 4261:4262
Number 4263:4265 text="20" suf="" isf=0 int=20
RParen 4265:4266
Newline 4266:4267
Ident 4271:4278 text="println"
LParen 4278:4279
Ident 4279:4291 text="channel_recv"
LParen 4291:4292
Ident 4292:4293 text="r"
RParen 4293:4294
RParen 4294:4295
Newline 4295:4296
Ident 4300:4312 text="channel_send"
LParen 4312:4313
Ident 4313:4314 text="r"
Comma 4314:4315
Number 4316:4318 text="30" suf="" isf=0 int=30
RParen 4318:4319
Newline 4319:4320
Ident 4324:4331 text="println"
LParen 4331:4332
Ident 4332:4344 text="channel_recv"
LParen 4344:4345
Ident 4345:4346 text="r"
RParen 4346:4347
RParen 4347:4348
Newline 4348:4349
Ident 4353:4360 text="println"
LParen 4360:4361
Ident 4361:4373 text="channel_recv"
LParen 4373:4374
Ident 4374:4375 text="r"
RParen 4375:4376
RParen 4376:4377
Newline 4377:4378
Let 4382:4385
Ident 4386:4388 text="cl"
Assign 4389:4390
Ident 4391:4402 text="channel_new"
LParen 4402:4403
Number 4403:4404 text="1" suf="" isf=0 int=1
RParen 4404:4405
Newline 4405:4406
Ident 4410:4417 text="println"
LParen 4417:4418
Ident 4418:4432 text="channel_closed"
LParen 4432:4433
Ident 4433:4435 text="cl"
RParen 4435:4436
RParen 4436:4437
Newline 4437:4438
Ident 4442:4454 text="channel_send"
LParen 4454:4455
Ident 4455:4457 text="cl"
Comma 4457:4458
Number 4459:4461 text="65" suf="" isf=0 int=65
RParen 4461:4462
Newline 4462:4463
Ident 4467:4480 text="channel_close"
LParen 4480:4481
Ident 4481:4483 text="cl"
RParen 4483:4484
Newline 4484:4485
Ident 4489:4496 text="println"
LParen 4496:4497
Ident 4497:4511 text="channel_closed"
LParen 4511:4512
Ident 4512:4514 text="cl"
RParen 4514:4515
RParen 4515:4516
Newline 4516:4517
Let 4521:4524
Ident 4525:4527 text="g2"
Assign 4528:4529
Ident 4530:4546 text="channel_try_recv"
LParen 4546:4547
Ident 4547:4549 text="cl"
RParen 4549:4550
Newline 4550:4551
If 4555:4557
LParen 4558:4559
Let 4559:4562
Ident 4563:4567 text="some"
LParen 4567:4568
Ident 4568:4570 text="v2"
RParen 4570:4571
Assign 4572:4573
Ident 4574:4576 text="g2"
RParen 4576:4577
LBrace 4578:4579
Ident 4580:4587 text="println"
LParen 4587:4588
Ident 4588:4590 text="v2"
RParen 4590:4591
RBrace 4592:4593
Else 4594:4598
LBrace 4599:4600
Ident 4601:4608 text="println"
LParen 4608:4609
Str 4609:4615 T("none")
RParen 4615:4616
RBrace 4617:4618
Newline 4618:4619
Let 4623:4626
Ident 4627:4629 text="e3"
Assign 4630:4631
Ident 4632:4648 text="channel_try_recv"
LParen 4648:4649
Ident 4649:4651 text="cl"
RParen 4651:4652
Newline 4652:4653
If 4657:4659
LParen 4660:4661
Let 4661:4664
Ident 4665:4669 text="some"
LParen 4669:4670
Ident 4670:4672 text="v3"
RParen 4672:4673
Assign 4674:4675
Ident 4676:4678 text="e3"
RParen 4678:4679
LBrace 4680:4681
Ident 4682:4689 text="println"
LParen 4689:4690
Ident 4690:4692 text="v3"
RParen 4692:4693
RBrace 4694:4695
Else 4696:4700
LBrace 4701:4702
Ident 4703:4710 text="println"
LParen 4710:4711
Str 4711:4717 T("none")
RParen 4717:4718
RBrace 4719:4720
Newline 4720:4721
Newline 4721:4722
Ident 4726:4733 text="println"
LParen 4733:4734
Str 4734:4743 T("sync ok")
RParen 4743:4744
Newline 4744:4745
RBrace 4745:4746
Eof 4746:4746
