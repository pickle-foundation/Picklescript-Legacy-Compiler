Module 0:6
Ident 7:11 text="main"
Newline 11:12
Newline 12:13
Newline 89:90
Newline 167:168
Newline 246:247
Newline 321:322
Newline 378:379
Var 379:382
Ident 383:388 text="gBool"
Colon 388:389
Ident 390:394 text="bool"
Assign 395:396
True 397:401
Newline 401:402
Var 402:405
Ident 406:414 text="gBoolOff"
Colon 414:415
Ident 416:420 text="bool"
Assign 421:422
False 423:428
Newline 428:429
Var 429:432
Ident 433:438 text="gChar"
Colon 438:439
Ident 440:444 text="char"
Assign 445:446
Char 447:450 ch='Z' int=90
Newline 450:451
Var 451:454
Ident 455:461 text="gFloat"
Colon 461:462
Ident 463:468 text="float"
Assign 469:470
Number 471:474 text="2.5" suf="" isf=1 int=-
Newline 474:475
Var 475:478
Ident 479:488 text="gFloatNeg"
Colon 488:489
Ident 490:495 text="float"
Assign 496:497
Minus 498:499
Number 499:502 text="1.5" suf="" isf=1 int=-
Newline 502:503
Var 503:506
Ident 507:511 text="gInt"
Colon 511:512
Ident 513:516 text="int"
Assign 517:518
Number 519:521 text="42" suf="" isf=0 int=42
Newline 521:522
Var 522:525
Ident 526:533 text="gIntNeg"
Colon 533:534
Ident 535:538 text="int"
Assign 539:540
Minus 541:542
Number 542:543 text="7" suf="" isf=0 int=7
Newline 543:544
Newline 544:545
Newline 623:624
Newline 655:656
Var 656:659
Ident 660:666 text="gFirst"
Colon 666:667
Ident 668:672 text="bool"
Assign 673:674
True 675:679
Newline 679:680
Var 680:683
Ident 684:691 text="gSecond"
Colon 691:692
Ident 693:697 text="bool"
Assign 698:699
False 700:705
Newline 705:706
Newline 706:707
Newline 782:783
Newline 862:863
Newline 940:941
Newline 950:951
Fn 951:953
Ident 954:961 text="setBool"
LParen 961:962
Ident 962:963 text="p"
Colon 963:964
Star 965:966
Ident 966:970 text="bool"
Comma 970:971
Ident 972:973 text="v"
Colon 973:974
Ident 975:979 text="bool"
RParen 979:980
LBrace 981:982
Newline 982:983
Unsafe 987:993
LBrace 994:995
Newline 995:996
Star 1004:1005
Ident 1005:1006 text="p"
Assign 1007:1008
Ident 1009:1010 text="v"
Newline 1010:1011
RBrace 1015:1016
Newline 1016:1017
RBrace 1017:1018
Newline 1018:1019
Newline 1019:1020
Fn 1020:1022
Ident 1023:1030 text="setChar"
LParen 1030:1031
Ident 1031:1032 text="p"
Colon 1032:1033
Star 1034:1035
Ident 1035:1039 text="char"
Comma 1039:1040
Ident 1041:1042 text="v"
Colon 1042:1043
Ident 1044:1048 text="char"
RParen 1048:1049
LBrace 1050:1051
Newline 1051:1052
Unsafe 1056:1062
LBrace 1063:1064
Newline 1064:1065
Star 1073:1074
Ident 1074:1075 text="p"
Assign 1076:1077
Ident 1078:1079 text="v"
Newline 1079:1080
RBrace 1084:1085
Newline 1085:1086
RBrace 1086:1087
Newline 1087:1088
Newline 1088:1089
Fn 1089:1091
Ident 1092:1100 text="setFloat"
LParen 1100:1101
Ident 1101:1102 text="p"
Colon 1102:1103
Star 1104:1105
Ident 1105:1110 text="float"
Comma 1110:1111
Ident 1112:1113 text="v"
Colon 1113:1114
Ident 1115:1120 text="float"
RParen 1120:1121
LBrace 1122:1123
Newline 1123:1124
Unsafe 1128:1134
LBrace 1135:1136
Newline 1136:1137
Star 1145:1146
Ident 1146:1147 text="p"
Assign 1148:1149
Ident 1150:1151 text="v"
Newline 1151:1152
RBrace 1156:1157
Newline 1157:1158
RBrace 1158:1159
Newline 1159:1160
Newline 1160:1161
Fn 1161:1163
Ident 1164:1168 text="main"
LParen 1168:1169
RParen 1169:1170
LBrace 1171:1172
Newline 1172:1173
Newline 1227:1228
Ident 1232:1239 text="println"
LParen 1239:1240
Str 1240:1247 T("bool:")
Comma 1247:1248
Ident 1249:1254 text="gBool"
RParen 1254:1255
Newline 1255:1256
Ident 1260:1266 text="assert"
LParen 1266:1267
Ident 1267:1272 text="gBool"
Comma 1272:1273
Str 1274:1312 T("a `true` global initialized to false")
RParen 1312:1313
Newline 1313:1314
Ident 1318:1324 text="assert"
LParen 1324:1325
Bang 1325:1326
Ident 1326:1334 text="gBoolOff"
Comma 1334:1335
Str 1336:1374 T("a `false` global initialized to true")
RParen 1374:1375
Newline 1375:1376
Ident 1380:1386 text="assert"
LParen 1386:1387
Ident 1387:1392 text="gChar"
EqEq 1393:1395
Char 1396:1399 ch='Z' int=90
Comma 1399:1400
Str 1401:1450 T("a char global did not read back its initializer")
RParen 1450:1451
Newline 1451:1452
Ident 1456:1462 text="assert"
LParen 1462:1463
Ident 1463:1469 text="gFloat"
EqEq 1470:1472
Number 1473:1476 text="2.5" suf="" isf=1 int=-
Comma 1476:1477
Str 1478:1528 T("a float global did not read back its initializer")
RParen 1528:1529
Newline 1529:1530
Ident 1534:1540 text="assert"
LParen 1540:1541
Ident 1541:1550 text="gFloatNeg"
EqEq 1551:1553
Minus 1554:1555
Number 1555:1558 text="1.5" suf="" isf=1 int=-
Comma 1558:1559
Str 1560:1598 T("a negated float global lost its sign")
RParen 1598:1599
Newline 1599:1600
Ident 1604:1610 text="assert"
LParen 1610:1611
Ident 1611:1615 text="gInt"
EqEq 1616:1618
Number 1619:1621 text="42" suf="" isf=0 int=42
Comma 1621:1622
Str 1623:1648 T("an int global regressed")
RParen 1648:1649
Newline 1649:1650
Ident 1654:1660 text="assert"
LParen 1660:1661
Ident 1661:1668 text="gIntNeg"
EqEq 1669:1671
Minus 1672:1673
Number 1673:1674 text="7" suf="" isf=0 int=7
Comma 1674:1675
Str 1676:1712 T("a negated int global lost its sign")
RParen 1712:1713
Newline 1713:1714
Newline 1714:1715
Newline 1774:1775
Ident 1779:1785 text="assert"
LParen 1785:1786
Ident 1786:1792 text="gFirst"
Comma 1792:1793
Str 1794:1843 T("the first of two adjacent bool globals is wrong")
RParen 1843:1844
Newline 1844:1845
Ident 1849:1855 text="assert"
LParen 1855:1856
Bang 1856:1857
Ident 1857:1864 text="gSecond"
Comma 1864:1865
Str 1866:1916 T("the second of two adjacent bool globals is wrong")
RParen 1916:1917
Newline 1917:1918
Newline 1918:1919
Newline 1985:1986
Ident 1990:1995 text="gBool"
Assign 1996:1997
False 1998:2003
Newline 2003:2004
Ident 2008:2016 text="gBoolOff"
Assign 2017:2018
True 2019:2023
Newline 2023:2024
Ident 2028:2035 text="println"
LParen 2035:2036
Str 2036:2050 T("after flips:")
Comma 2050:2051
Ident 2052:2057 text="gBool"
Comma 2057:2058
Ident 2059:2067 text="gBoolOff"
RParen 2067:2068
Newline 2068:2069
Ident 2073:2079 text="assert"
LParen 2079:2080
Bang 2080:2081
Ident 2081:2086 text="gBool"
Comma 2086:2087
Str 2088:2135 T("storing false into a bool global did not take")
RParen 2135:2136
Newline 2136:2137
Ident 2141:2147 text="assert"
LParen 2147:2148
Ident 2148:2156 text="gBoolOff"
Comma 2156:2157
Str 2158:2204 T("storing true into a bool global did not take")
RParen 2204:2205
Newline 2205:2206
Ident 2210:2216 text="assert"
LParen 2216:2217
Ident 2217:2223 text="gFirst"
AndAnd 2224:2226
Bang 2227:2228
Ident 2228:2235 text="gSecond"
Comma 2235:2236
Str 2237:2280 T("a bool store clobbered an adjacent global")
RParen 2280:2281
Newline 2281:2282
Newline 2282:2283
Newline 2337:2338
Ident 2342:2347 text="gChar"
Assign 2348:2349
Char 2350:2353 ch='q' int=113
Newline 2353:2354
Ident 2358:2364 text="assert"
LParen 2364:2365
Ident 2365:2370 text="gChar"
EqEq 2371:2373
Char 2374:2377 ch='q' int=113
Comma 2377:2378
Str 2379:2420 T("storing into a char global did not take")
RParen 2420:2421
Newline 2421:2422
Ident 2426:2431 text="gChar"
Assign 2432:2433
Char 2434:2437 ch='Z' int=90
Newline 2437:2438
Newline 2438:2439
Newline 2484:2485
Ident 2489:2495 text="gFloat"
Assign 2496:2497
Number 2498:2501 text="0.1" suf="" isf=1 int=-
Newline 2501:2502
Ident 2506:2512 text="assert"
LParen 2512:2513
Ident 2513:2519 text="gFloat"
EqEq 2520:2522
Number 2523:2526 text="0.1" suf="" isf=1 int=-
Comma 2526:2527
Str 2528:2576 T("storing into a float global did not round-trip")
RParen 2576:2577
Newline 2577:2578
Ident 2582:2588 text="gFloat"
Assign 2589:2590
Number 2591:2594 text="2.5" suf="" isf=1 int=-
Newline 2594:2595
Newline 2595:2596
Newline 2671:2672
Newline 2728:2729
Unsafe 2733:2739
LBrace 2740:2741
Newline 2741:2742
Let 2750:2753
Ident 2754:2756 text="pb"
Colon 2756:2757
Star 2758:2759
Ident 2759:2763 text="bool"
Assign 2764:2765
Amp 2766:2767
Ident 2767:2773 text="gFirst"
Newline 2773:2774
Ident 2782:2789 text="setBool"
LParen 2789:2790
Ident 2790:2792 text="pb"
Comma 2792:2793
False 2794:2799
RParen 2799:2800
Newline 2800:2801
RBrace 2805:2806
Newline 2806:2807
Ident 2811:2818 text="println"
LParen 2818:2819
Str 2819:2848 T("gFirst after pointer store:")
Comma 2848:2849
Ident 2850:2856 text="gFirst"
RParen 2856:2857
Newline 2857:2858
Ident 2862:2868 text="assert"
LParen 2868:2869
Bang 2869:2870
Ident 2870:2876 text="gFirst"
Comma 2876:2877
Str 2878:2926 T("a write through &bool did not reach the global")
RParen 2926:2927
Newline 2927:2928
Newline 2928:2929
Unsafe 2933:2939
LBrace 2940:2941
Newline 2941:2942
Let 2950:2953
Ident 2954:2956 text="pf"
Colon 2956:2957
Star 2958:2959
Ident 2959:2964 text="float"
Assign 2965:2966
Amp 2967:2968
Ident 2968:2974 text="gFloat"
Newline 2974:2975
Ident 2983:2991 text="setFloat"
LParen 2991:2992
Ident 2992:2994 text="pf"
Comma 2994:2995
Minus 2996:2997
Number 2997:3001 text="0.25" suf="" isf=1 int=-
RParen 3001:3002
Newline 3002:3003
RBrace 3007:3008
Newline 3008:3009
Ident 3013:3019 text="assert"
LParen 3019:3020
Ident 3020:3026 text="gFloat"
EqEq 3027:3029
Minus 3030:3031
Number 3031:3035 text="0.25" suf="" isf=1 int=-
Comma 3035:3036
Str 3037:3086 T("a write through &float did not reach the global")
RParen 3086:3087
Newline 3087:3088
Newline 3088:3089
Unsafe 3093:3099
LBrace 3100:3101
Newline 3101:3102
Let 3110:3113
Ident 3114:3116 text="pc"
Colon 3116:3117
Star 3118:3119
Ident 3119:3123 text="char"
Assign 3124:3125
Amp 3126:3127
Ident 3127:3132 text="gChar"
Newline 3132:3133
Ident 3141:3148 text="setChar"
LParen 3148:3149
Ident 3149:3151 text="pc"
Comma 3151:3152
Char 3153:3156 ch='x' int=120
RParen 3156:3157
Newline 3157:3158
RBrace 3162:3163
Newline 3163:3164
Ident 3168:3174 text="assert"
LParen 3174:3175
Ident 3175:3180 text="gChar"
EqEq 3181:3183
Char 3184:3187 ch='x' int=120
Comma 3187:3188
Str 3189:3237 T("a write through &char did not reach the global")
RParen 3237:3238
Newline 3238:3239
Newline 3239:3240
Ident 3244:3251 text="println"
LParen 3251:3252
Str 3252:3264 T("scalars ok")
RParen 3264:3265
Newline 3265:3266
RBrace 3266:3267
Eof 3267:3267
