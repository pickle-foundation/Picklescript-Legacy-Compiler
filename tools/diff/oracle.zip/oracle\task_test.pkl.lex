Newline 70:71
Newline 73:74
Newline 152:153
Newline 229:230
Newline 309:310
Newline 389:390
Newline 461:462
Newline 508:509
Newline 509:510
Ident 510:514 text="test"
Fn 515:517
Ident 518:545 text="task_sugar_spawns_and_joins"
LParen 545:546
RParen 546:547
LBrace 548:549
Newline 549:550
Let 554:557
Ident 558:561 text="ran"
Assign 562:563
LBracket 564:565
Number 565:566 text="0" suf="" isf=0 int=0
RBracket 566:567
Newline 567:568
Ident 572:575 text="ran"
Dot 575:576
Ident 576:579 text="pop"
LParen 579:580
RParen 580:581
Newline 581:582
Let 586:589
Ident 590:591 text="t"
Assign 592:593
Task 594:598
LBrace 599:600
Newline 600:601
Ident 609:612 text="ran"
Dot 612:613
Ident 613:617 text="push"
LParen 617:618
Number 618:619 text="1" suf="" isf=0 int=1
RParen 619:620
Newline 620:621
RBrace 625:626
Newline 626:627
Ident 631:637 text="expect"
LParen 637:638
Ident 638:649 text="thread_join"
LParen 649:650
Ident 650:651 text="t"
RParen 651:652
RParen 652:653
Dot 653:654
Ident 654:658 text="toBe"
LParen 658:659
True 659:663
RParen 663:664
Newline 664:665
Ident 669:675 text="expect"
LParen 675:676
Ident 676:679 text="len"
LParen 679:680
Ident 680:683 text="ran"
RParen 683:684
RParen 684:685
Dot 685:686
Ident 686:690 text="toBe"
LParen 690:691
Number 691:692 text="1" suf="" isf=0 int=1
RParen 692:693
Newline 693:694
RBrace 694:695
Newline 695:696
Newline 696:697
Ident 697:701 text="test"
Fn 702:704
Ident 705:748 text="task_sugar_hands_the_lock_back_like_a_spawn"
LParen 748:749
RParen 749:750
LBrace 751:752
Newline 752:753
Newline 830:831
Newline 910:911
Newline 952:953
Let 957:960
Ident 961:963 text="ch"
Assign 964:965
Ident 966:977 text="channel_new"
LParen 977:978
Number 978:979 text="1" suf="" isf=0 int=1
RParen 979:980
Newline 980:981
Let 985:988
Ident 989:993 text="seen"
Assign 994:995
Ident 996:1006 text="atomic_new"
LParen 1006:1007
Number 1007:1008 text="0" suf="" isf=0 int=0
RParen 1008:1009
Newline 1009:1010
Let 1014:1017
Ident 1018:1019 text="t"
Assign 1020:1021
Task 1022:1026
LBrace 1027:1028
Newline 1028:1029
Let 1037:1040
Ident 1041:1042 text="v"
Assign 1043:1044
Ident 1045:1057 text="channel_recv"
LParen 1057:1058
Ident 1058:1060 text="ch"
RParen 1060:1061
Newline 1061:1062
Ident 1070:1082 text="atomic_store"
LParen 1082:1083
Ident 1083:1087 text="seen"
Comma 1087:1088
Ident 1089:1090 text="v"
RParen 1090:1091
Newline 1091:1092
RBrace 1096:1097
Newline 1097:1098
Ident 1102:1110 text="sleep_ms"
LParen 1110:1111
Number 1111:1112 text="5" suf="" isf=0 int=5
RParen 1112:1113
Newline 1113:1114
Ident 1118:1130 text="channel_send"
LParen 1130:1131
Ident 1131:1133 text="ch"
Comma 1133:1134
Number 1135:1136 text="7" suf="" isf=0 int=7
RParen 1136:1137
Newline 1137:1138
Ident 1142:1148 text="expect"
LParen 1148:1149
Ident 1149:1160 text="thread_join"
LParen 1160:1161
Ident 1161:1162 text="t"
RParen 1162:1163
RParen 1163:1164
Dot 1164:1165
Ident 1165:1169 text="toBe"
LParen 1169:1170
True 1170:1174
RParen 1174:1175
Newline 1175:1176
Ident 1180:1186 text="expect"
LParen 1186:1187
Ident 1187:1198 text="atomic_load"
LParen 1198:1199
Ident 1199:1203 text="seen"
RParen 1203:1204
RParen 1204:1205
Dot 1205:1206
Ident 1206:1210 text="toBe"
LParen 1210:1211
Number 1211:1212 text="7" suf="" isf=0 int=7
RParen 1212:1213
Newline 1213:1214
RBrace 1214:1215
Newline 1215:1216
Newline 1216:1217
Ident 1217:1221 text="test"
Fn 1222:1224
Ident 1225:1264 text="task_sugar_as_a_statement_is_observable"
LParen 1264:1265
RParen 1265:1266
LBrace 1267:1268
Newline 1268:1269
Newline 1346:1347
Newline 1426:1427
Newline 1490:1491
Let 1495:1498
Ident 1499:1502 text="out"
Assign 1503:1504
Ident 1505:1516 text="channel_new"
LParen 1516:1517
Number 1517:1518 text="1" suf="" isf=0 int=1
RParen 1518:1519
Newline 1519:1520
Task 1524:1528
LBrace 1529:1530
Newline 1530:1531
Ident 1539:1551 text="channel_send"
LParen 1551:1552
Ident 1552:1555 text="out"
Comma 1555:1556
Number 1557:1559 text="42" suf="" isf=0 int=42
RParen 1559:1560
Newline 1560:1561
RBrace 1565:1566
Newline 1566:1567
Ident 1571:1577 text="expect"
LParen 1577:1578
Ident 1578:1590 text="channel_recv"
LParen 1590:1591
Ident 1591:1594 text="out"
RParen 1594:1595
RParen 1595:1596
Dot 1596:1597
Ident 1597:1601 text="toBe"
LParen 1601:1602
Number 1602:1604 text="42" suf="" isf=0 int=42
RParen 1604:1605
Newline 1605:1606
Ident 1610:1616 text="expect"
LParen 1616:1617
Ident 1617:1628 text="channel_len"
LParen 1628:1629
Ident 1629:1632 text="out"
RParen 1632:1633
RParen 1633:1634
Dot 1634:1635
Ident 1635:1639 text="toBe"
LParen 1639:1640
Number 1640:1641 text="0" suf="" isf=0 int=0
RParen 1641:1642
Newline 1642:1643
RBrace 1643:1644
Newline 1644:1645
Newline 1645:1646
Ident 1646:1650 text="test"
Fn 1651:1653
Ident 1654:1685 text="task_can_still_be_an_identifier"
LParen 1685:1686
RParen 1686:1687
LBrace 1688:1689
Newline 1689:1690
Let 1694:1697
Task 1698:1702
Assign 1703:1704
Number 1705:1706 text="7" suf="" isf=0 int=7
Newline 1706:1707
Ident 1711:1717 text="expect"
LParen 1717:1718
Task 1718:1722
RParen 1722:1723
Dot 1723:1724
Ident 1724:1728 text="toBe"
LParen 1728:1729
Number 1729:1730 text="7" suf="" isf=0 int=7
RParen 1730:1731
Newline 1731:1732
RBrace 1732:1733
Newline 1733:1734
Newline 1734:1735
Ident 1735:1739 text="test"
Fn 1740:1742
Ident 1743:1774 text="task_sugar_body_runs_statements"
LParen 1774:1775
RParen 1775:1776
LBrace 1777:1778
Newline 1778:1779
Newline 1851:1852
Newline 1928:1929
Newline 1978:1979
Let 1983:1986
Ident 1987:1990 text="ran"
Assign 1991:1992
LBracket 1993:1994
Number 1994:1995 text="0" suf="" isf=0 int=0
RBracket 1995:1996
Newline 1996:1997
Ident 2001:2004 text="ran"
Dot 2004:2005
Ident 2005:2008 text="pop"
LParen 2008:2009
RParen 2009:2010
Newline 2010:2011
Let 2015:2018
Ident 2019:2020 text="t"
Assign 2021:2022
Task 2023:2027
LBrace 2028:2029
Newline 2029:2030
Ident 2038:2041 text="ran"
Dot 2041:2042
Ident 2042:2046 text="push"
LParen 2046:2047
Number 2047:2048 text="2" suf="" isf=0 int=2
RParen 2048:2049
Newline 2049:2050
Ident 2058:2061 text="ran"
Dot 2061:2062
Ident 2062:2066 text="push"
LParen 2066:2067
Number 2067:2068 text="3" suf="" isf=0 int=3
RParen 2068:2069
Newline 2069:2070
RBrace 2074:2075
Newline 2075:2076
Ident 2080:2086 text="expect"
LParen 2086:2087
Ident 2087:2098 text="thread_join"
LParen 2098:2099
Ident 2099:2100 text="t"
RParen 2100:2101
RParen 2101:2102
Dot 2102:2103
Ident 2103:2107 text="toBe"
LParen 2107:2108
True 2108:2112
RParen 2112:2113
Newline 2113:2114
Ident 2118:2124 text="expect"
LParen 2124:2125
Ident 2125:2128 text="len"
LParen 2128:2129
Ident 2129:2132 text="ran"
RParen 2132:2133
RParen 2133:2134
Dot 2134:2135
Ident 2135:2139 text="toBe"
LParen 2139:2140
Number 2140:2141 text="2" suf="" isf=0 int=2
RParen 2141:2142
Newline 2142:2143
Ident 2147:2153 text="expect"
LParen 2153:2154
Ident 2154:2157 text="ran"
LBracket 2157:2158
Number 2158:2159 text="0" suf="" isf=0 int=0
RBracket 2159:2160
RParen 2160:2161
Dot 2161:2162
Ident 2162:2166 text="toBe"
LParen 2166:2167
Number 2167:2168 text="2" suf="" isf=0 int=2
RParen 2168:2169
Newline 2169:2170
Ident 2174:2180 text="expect"
LParen 2180:2181
Ident 2181:2184 text="ran"
LBracket 2184:2185
Number 2185:2186 text="1" suf="" isf=0 int=1
RBracket 2186:2187
RParen 2187:2188
Dot 2188:2189
Ident 2189:2193 text="toBe"
LParen 2193:2194
Number 2194:2195 text="3" suf="" isf=0 int=3
RParen 2195:2196
Newline 2196:2197
RBrace 2197:2198
Eof 2198:2198
