Fn 0:2
Ident 3:18 text="emptyIntBoolMap"
LParen 18:19
RParen 19:20
Arrow 21:23
Ident 24:27 text="Map"
Lt 27:28
Ident 28:31 text="int"
Comma 31:32
Ident 33:37 text="bool"
Gt 37:38
LBrace 39:40
Newline 40:41
Let 45:48
Ident 49:50 text="m"
Assign 51:52
LBrace 53:54
Number 54:55 text="0" suf="" isf=0 int=0
Colon 55:56
False 57:62
RBrace 62:63
Newline 63:64
Ident 68:69 text="m"
Dot 69:70
Ident 70:76 text="remove"
LParen 76:77
Number 77:78 text="0" suf="" isf=0 int=0
RParen 78:79
Newline 79:80
Ident 84:85 text="m"
Newline 85:86
RBrace 86:87
Newline 87:88
Newline 88:89
Fn 89:91
Ident 92:110 text="emptyIntIntListMap"
LParen 110:111
RParen 111:112
Arrow 113:115
Ident 116:119 text="Map"
Lt 119:120
Ident 120:123 text="int"
Comma 123:124
Ident 125:129 text="List"
Lt 129:130
Ident 130:133 text="int"
Shr 133:135
LBrace 136:137
Newline 137:138
Let 142:145
Ident 146:147 text="m"
Assign 148:149
LBrace 150:151
Number 151:152 text="0" suf="" isf=0 int=0
Colon 152:153
Ident 154:163 text="emptyInts"
LParen 163:164
RParen 164:165
RBrace 165:166
Newline 166:167
Ident 171:172 text="m"
Dot 172:173
Ident 173:179 text="remove"
LParen 179:180
Number 180:181 text="0" suf="" isf=0 int=0
RParen 181:182
Newline 182:183
Ident 187:188 text="m"
Newline 188:189
RBrace 189:190
Newline 190:191
Newline 191:192
Fn 192:194
Ident 195:204 text="emptyInts"
LParen 204:205
RParen 205:206
Arrow 207:209
Ident 210:214 text="List"
Lt 214:215
Ident 215:218 text="int"
Gt 218:219
LBrace 220:221
Newline 221:222
Let 226:229
Ident 230:231 text="l"
Assign 232:233
LBracket 234:235
Number 235:236 text="0" suf="" isf=0 int=0
RBracket 236:237
Newline 237:238
Ident 242:243 text="l"
Dot 243:244
Ident 244:250 text="remove"
LParen 250:251
Number 251:252 text="0" suf="" isf=0 int=0
RParen 252:253
Newline 253:254
Ident 258:259 text="l"
Newline 259:260
RBrace 260:261
Newline 261:262
Newline 262:263
Fn 263:265
Ident 266:275 text="emptyStrs"
LParen 275:276
RParen 276:277
Arrow 278:280
Ident 281:285 text="List"
Lt 285:286
Ident 286:292 text="string"
Gt 292:293
LBrace 294:295
Newline 295:296
Let 300:303
Ident 304:305 text="l"
Assign 306:307
LBracket 308:309
Str 309:311
RBracket 311:312
Newline 312:313
Ident 317:318 text="l"
Dot 318:319
Ident 319:325 text="remove"
LParen 325:326
Number 326:327 text="0" suf="" isf=0 int=0
RParen 327:328
Newline 328:329
Ident 333:334 text="l"
Newline 334:335
RBrace 335:336
Newline 336:337
Newline 337:338
Fn 338:340
Ident 341:349 text="bigChurn"
LParen 349:350
RParen 350:351
LBrace 352:353
Newline 353:354
Var 358:361
Ident 362:367 text="blobs"
Assign 368:369
Ident 370:379 text="emptyStrs"
LParen 379:380
RParen 380:381
Newline 381:382
Var 386:389
Ident 390:392 text="gz"
Assign 393:394
Number 395:396 text="0" suf="" isf=0 int=0
Newline 396:397
While 401:406
LParen 407:408
Ident 408:410 text="gz"
Lt 411:412
Number 413:416 text="300" suf="" isf=0 int=300
RParen 416:417
LBrace 418:419
Newline 419:420
Ident 428:433 text="blobs"
Dot 433:434
Ident 434:438 text="push"
LParen 438:439
Str 439:446 T("blob-")
Plus 447:448
Ident 449:452 text="str"
LParen 452:453
Ident 453:455 text="gz"
RParen 455:456
Plus 457:458
Str 459:498 T("-abcdefghijklmnopqrstuvwxyz0123456789")
RParen 498:499
Newline 499:500
Ident 508:510 text="gz"
Assign 511:512
Ident 513:515 text="gz"
Plus 516:517
Number 518:519 text="1" suf="" isf=0 int=1
Newline 519:520
RBrace 524:525
Newline 525:526
Var 530:533
Ident 534:536 text="l2"
Assign 537:538
Ident 539:548 text="emptyInts"
LParen 548:549
RParen 549:550
Newline 550:551
Var 555:558
Ident 559:561 text="g2"
Assign 562:563
Number 564:565 text="0" suf="" isf=0 int=0
Newline 565:566
While 570:575
LParen 576:577
Ident 577:579 text="g2"
Lt 580:581
Number 582:586 text="5000" suf="" isf=0 int=5000
RParen 586:587
LBrace 588:589
Newline 589:590
Ident 598:600 text="l2"
Dot 600:601
Ident 601:605 text="push"
LParen 605:606
Ident 606:608 text="g2"
RParen 608:609
Newline 609:610
Ident 618:620 text="g2"
Assign 621:622
Ident 623:625 text="g2"
Plus 626:627
Number 628:629 text="1" suf="" isf=0 int=1
Newline 629:630
RBrace 634:635
Newline 635:636
Var 640:643
Ident 644:646 text="m2"
Assign 647:648
Ident 649:664 text="emptyIntBoolMap"
LParen 664:665
RParen 665:666
Newline 666:667
Var 671:674
Ident 675:677 text="g3"
Assign 678:679
Number 680:681 text="0" suf="" isf=0 int=0
Newline 681:682
While 686:691
LParen 692:693
Ident 693:695 text="g3"
Lt 696:697
Number 698:701 text="300" suf="" isf=0 int=300
RParen 701:702
LBrace 703:704
Newline 704:705
Ident 713:715 text="m2"
LBracket 715:716
Ident 716:718 text="g3"
RBracket 718:719
Assign 720:721
Ident 722:724 text="g3"
Percent 725:726
Number 727:728 text="2" suf="" isf=0 int=2
EqEq 729:731
Number 732:733 text="0" suf="" isf=0 int=0
Newline 733:734
Ident 742:744 text="g3"
Assign 745:746
Ident 747:749 text="g3"
Plus 750:751
Number 752:753 text="1" suf="" isf=0 int=1
Newline 753:754
RBrace 758:759
Newline 759:760
RBrace 760:761
Newline 761:762
Newline 762:763
Fn 763:765
Ident 766:775 text="verifyMap"
LParen 775:776
Ident 776:777 text="m"
Colon 777:778
Ident 779:782 text="Map"
Lt 782:783
Ident 783:786 text="int"
Comma 786:787
Ident 788:792 text="bool"
Gt 792:793
Comma 793:794
Ident 795:796 text="n"
Colon 796:797
Ident 798:801 text="int"
Comma 801:802
Ident 803:807 text="pred"
Colon 807:808
LParen 809:810
Ident 810:813 text="int"
RParen 813:814
Arrow 815:817
Ident 818:822 text="bool"
RParen 822:823
Arrow 824:826
Ident 827:831 text="bool"
LBrace 832:833
Newline 833:834
Var 838:841
Ident 842:844 text="ok"
Assign 845:846
Ident 847:850 text="len"
LParen 850:851
Ident 851:852 text="m"
RParen 852:853
EqEq 854:856
Ident 857:858 text="n"
Newline 858:859
Var 863:866
Ident 867:868 text="i"
Assign 869:870
Number 871:872 text="0" suf="" isf=0 int=0
Newline 872:873
While 877:882
LParen 883:884
Ident 884:885 text="i"
Lt 886:887
Ident 888:889 text="n"
RParen 889:890
LBrace 891:892
Newline 892:893
If 901:903
LParen 904:905
Ident 905:906 text="m"
LBracket 906:907
Ident 907:908 text="i"
RBracket 908:909
NotEq 910:912
Ident 913:917 text="pred"
LParen 917:918
Ident 918:919 text="i"
RParen 919:920
RParen 920:921
LBrace 922:923
Newline 923:924
Ident 936:938 text="ok"
Assign 939:940
False 941:946
Newline 946:947
RBrace 955:956
Newline 956:957
Ident 965:966 text="i"
Assign 967:968
Ident 969:970 text="i"
Plus 971:972
Number 973:974 text="1" suf="" isf=0 int=1
Newline 974:975
RBrace 979:980
Newline 980:981
Var 985:988
Ident 989:993 text="ksum"
Assign 994:995
Number 996:997 text="0" suf="" isf=0 int=0
Newline 997:998
Var 1002:1005
Ident 1006:1012 text="kcount"
Assign 1013:1014
Number 1015:1016 text="0" suf="" isf=0 int=0
Newline 1016:1017
For 1021:1024
LParen 1025:1026
Ident 1026:1027 text="k"
In 1028:1030
Ident 1031:1032 text="m"
Dot 1032:1033
Ident 1033:1037 text="keys"
LParen 1037:1038
RParen 1038:1039
RParen 1039:1040
LBrace 1041:1042
Newline 1042:1043
Ident 1051:1057 text="kcount"
Assign 1058:1059
Ident 1060:1066 text="kcount"
Plus 1067:1068
Number 1069:1070 text="1" suf="" isf=0 int=1
Newline 1070:1071
Ident 1079:1083 text="ksum"
Assign 1084:1085
Ident 1086:1090 text="ksum"
Plus 1091:1092
Ident 1093:1094 text="k"
Newline 1094:1095
RBrace 1099:1100
Newline 1100:1101
If 1105:1107
LParen 1108:1109
Ident 1109:1115 text="kcount"
NotEq 1116:1118
Ident 1119:1120 text="n"
RParen 1120:1121
LBrace 1122:1123
Newline 1123:1124
Ident 1132:1134 text="ok"
Assign 1135:1136
False 1137:1142
Newline 1142:1143
RBrace 1147:1148
Newline 1148:1149
If 1153:1155
LParen 1156:1157
Ident 1157:1161 text="ksum"
NotEq 1162:1164
Ident 1165:1166 text="n"
Star 1167:1168
LParen 1169:1170
Ident 1170:1171 text="n"
Minus 1172:1173
Number 1174:1175 text="1" suf="" isf=0 int=1
RParen 1175:1176
Slash 1177:1178
Number 1179:1180 text="2" suf="" isf=0 int=2
RParen 1180:1181
LBrace 1182:1183
Newline 1183:1184
Ident 1192:1194 text="ok"
Assign 1195:1196
False 1197:1202
Newline 1202:1203
RBrace 1207:1208
Newline 1208:1209
Ident 1213:1215 text="ok"
Newline 1215:1216
RBrace 1216:1217
Newline 1217:1218
Newline 1218:1219
Fn 1219:1221
Ident 1222:1232 text="runCompile"
LParen 1232:1233
RParen 1233:1234
Arrow 1235:1237
Ident 1238:1244 text="string"
LBrace 1245:1246
Newline 1246:1247
Var 1251:1254
Ident 1255:1266 text="directThrow"
Assign 1267:1268
Ident 1269:1284 text="emptyIntBoolMap"
LParen 1284:1285
RParen 1285:1286
Newline 1286:1287
Var 1291:1294
Ident 1295:1296 text="i"
Assign 1297:1298
Number 1299:1300 text="0" suf="" isf=0 int=0
Newline 1300:1301
While 1305:1310
LParen 1311:1312
Ident 1312:1313 text="i"
Lt 1314:1315
Number 1316:1319 text="200" suf="" isf=0 int=200
RParen 1319:1320
LBrace 1321:1322
Newline 1322:1323
Ident 1331:1342 text="directThrow"
LBracket 1342:1343
Ident 1343:1344 text="i"
RBracket 1344:1345
Assign 1346:1347
Ident 1348:1349 text="i"
Percent 1350:1351
Number 1352:1353 text="3" suf="" isf=0 int=3
EqEq 1354:1356
Number 1357:1358 text="0" suf="" isf=0 int=0
Newline 1358:1359
Ident 1367:1368 text="i"
Assign 1369:1370
Ident 1371:1372 text="i"
Plus 1373:1374
Number 1375:1376 text="1" suf="" isf=0 int=1
Newline 1376:1377
RBrace 1381:1382
Newline 1382:1383
Ident 1387:1395 text="bigChurn"
LParen 1395:1396
RParen 1396:1397
Newline 1397:1398
Var 1402:1405
Ident 1406:1407 text="a"
Assign 1408:1409
Ident 1410:1419 text="verifyMap"
LParen 1419:1420
Ident 1420:1431 text="directThrow"
Comma 1431:1432
Number 1433:1436 text="200" suf="" isf=0 int=200
Comma 1436:1437
Fn 1438:1440
LParen 1441:1442
Ident 1442:1443 text="x"
Colon 1443:1444
Ident 1445:1448 text="int"
RParen 1448:1449
Arrow 1450:1452
Ident 1453:1457 text="bool"
LBrace 1458:1459
Ident 1460:1461 text="x"
Percent 1462:1463
Number 1464:1465 text="3" suf="" isf=0 int=3
EqEq 1466:1468
Number 1469:1470 text="0" suf="" isf=0 int=0
RBrace 1471:1472
RParen 1472:1473
Newline 1473:1474
Ident 1478:1486 text="bigChurn"
LParen 1486:1487
RParen 1487:1488
Newline 1488:1489
Var 1493:1496
Ident 1497:1498 text="b"
Assign 1499:1500
Ident 1501:1510 text="verifyMap"
LParen 1510:1511
Ident 1511:1522 text="directThrow"
Comma 1522:1523
Number 1524:1527 text="200" suf="" isf=0 int=200
Comma 1527:1528
Fn 1529:1531
LParen 1532:1533
Ident 1533:1534 text="x"
Colon 1534:1535
Ident 1536:1539 text="int"
RParen 1539:1540
Arrow 1541:1543
Ident 1544:1548 text="bool"
LBrace 1549:1550
Ident 1551:1552 text="x"
Percent 1553:1554
Number 1555:1556 text="3" suf="" isf=0 int=3
EqEq 1557:1559
Number 1560:1561 text="0" suf="" isf=0 int=0
RBrace 1562:1563
RParen 1563:1564
Newline 1564:1565
If 1569:1571
LParen 1572:1573
Ident 1573:1574 text="a"
AndAnd 1575:1577
Ident 1578:1579 text="b"
RParen 1579:1580
LBrace 1581:1582
Newline 1582:1583
Return 1591:1597
Str 1598:1602 T("ST")
Newline 1602:1603
RBrace 1607:1608
Newline 1608:1609
Var 1613:1616
Ident 1617:1623 text="detail"
Assign 1624:1625
Str 1626:1630 T("a=")
Plus 1631:1632
Ident 1633:1636 text="str"
LParen 1636:1637
Ident 1637:1638 text="a"
RParen 1638:1639
Plus 1640:1641
Str 1642:1647 T(" b=")
Plus 1648:1649
Ident 1650:1653 text="str"
LParen 1653:1654
Ident 1654:1655 text="b"
RParen 1655:1656
Plus 1657:1658
Str 1659:1666 T(" len=")
Plus 1667:1668
Ident 1669:1672 text="str"
LParen 1672:1673
Ident 1673:1676 text="len"
LParen 1676:1677
Ident 1677:1688 text="directThrow"
RParen 1688:1689
RParen 1689:1690
Newline 1690:1691
For 1695:1698
LParen 1699:1700
Ident 1700:1701 text="k"
In 1702:1704
Ident 1705:1716 text="directThrow"
Dot 1716:1717
Ident 1717:1721 text="keys"
LParen 1721:1722
RParen 1722:1723
RParen 1723:1724
LBrace 1725:1726
Newline 1726:1727
Ident 1735:1741 text="detail"
Assign 1742:1743
Ident 1744:1750 text="detail"
Plus 1751:1752
Str 1753:1756 T(",")
Plus 1757:1758
Ident 1759:1762 text="str"
LParen 1762:1763
Ident 1763:1764 text="k"
RParen 1764:1765
Newline 1765:1766
If 1774:1776
LParen 1777:1778
Ident 1778:1781 text="len"
LParen 1781:1782
Ident 1782:1788 text="detail"
RParen 1788:1789
Gt 1790:1791
Number 1792:1795 text="300" suf="" isf=0 int=300
RParen 1795:1796
LBrace 1797:1798
Newline 1798:1799
Break 1811:1816
Newline 1816:1817
RBrace 1825:1826
Newline 1826:1827
RBrace 1831:1832
Newline 1832:1833
Str 1837:1843 T("VAR ")
Plus 1844:1845
Ident 1846:1852 text="detail"
Newline 1852:1853
RBrace 1853:1854
Newline 1854:1855
Newline 1855:1856
Fn 1856:1858
Ident 1859:1863 text="main"
LParen 1863:1864
RParen 1864:1865
LBrace 1866:1867
Newline 1867:1868
Var 1872:1875
Ident 1876:1879 text="out"
Assign 1880:1881
Str 1882:1884
Newline 1884:1885
Var 1889:1892
Ident 1893:1894 text="r"
Assign 1895:1896
Number 1897:1898 text="0" suf="" isf=0 int=0
Newline 1898:1899
While 1903:1908
LParen 1909:1910
Ident 1910:1911 text="r"
Lt 1912:1913
Number 1914:1915 text="3" suf="" isf=0 int=3
RParen 1915:1916
LBrace 1917:1918
Newline 1918:1919
Ident 1927:1930 text="out"
Assign 1931:1932
Ident 1933:1936 text="out"
Plus 1937:1938
Ident 1939:1949 text="runCompile"
LParen 1949:1950
RParen 1950:1951
Plus 1952:1953
Str 1954:1957 T(";")
Newline 1957:1958
Ident 1966:1967 text="r"
Assign 1968:1969
Ident 1970:1971 text="r"
Plus 1972:1973
Number 1974:1975 text="1" suf="" isf=0 int=1
Newline 1975:1976
RBrace 1980:1981
Newline 1981:1982
Ident 1986:1991 text="print"
LParen 1991:1992
Ident 1992:1995 text="out"
RParen 1995:1996
Newline 1996:1997
RBrace 1997:1998
Eof 1998:1998
