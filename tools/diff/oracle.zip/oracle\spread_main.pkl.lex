Fn 0:2
Ident 3:4 text="g"
LParen 4:5
Ident 5:6 text="a"
Colon 6:7
Ident 8:11 text="int"
Comma 11:12
Ident 13:14 text="b"
Colon 14:15
Ident 16:19 text="int"
Comma 19:20
Ident 21:22 text="c"
Colon 22:23
Ident 24:27 text="int"
RParen 27:28
Arrow 29:31
Ident 32:35 text="int"
LBrace 36:37
Newline 37:38
Ident 42:43 text="a"
Plus 44:45
Ident 46:47 text="b"
Star 48:49
Ident 50:51 text="c"
Newline 51:52
RBrace 52:53
Newline 53:54
Newline 54:55
Fn 55:57
Ident 58:59 text="h"
LParen 59:60
Ident 60:62 text="xs"
Colon 62:63
Ident 64:68 text="List"
Lt 68:69
Ident 69:72 text="int"
Gt 72:73
RParen 73:74
Arrow 75:77
Ident 78:81 text="int"
LBrace 82:83
Newline 83:84
Ident 88:89 text="g"
LParen 89:90
Number 90:91 text="1" suf="" isf=0 int=1
Comma 91:92
Number 93:94 text="2" suf="" isf=0 int=2
Comma 94:95
Ellipsis 96:99
Ident 99:101 text="xs"
RParen 101:102
Newline 102:103
RBrace 103:104
Newline 104:105
Newline 105:106
Fn 106:108
Ident 109:111 text="h2"
LParen 111:112
Ident 112:113 text="p"
Colon 113:114
Ident 115:118 text="int"
Comma 118:119
Ident 120:122 text="xs"
Colon 122:123
Ident 124:128 text="List"
Lt 128:129
Ident 129:132 text="int"
Gt 132:133
RParen 133:134
Arrow 135:137
Ident 138:141 text="int"
LBrace 142:143
Newline 143:144
Ident 148:149 text="g"
LParen 149:150
Ident 150:151 text="p"
Comma 151:152
Ellipsis 153:156
Ident 156:158 text="xs"
RParen 158:159
Newline 159:160
RBrace 160:161
Newline 161:162
Newline 162:163
Fn 163:165
Ident 166:167 text="r"
LParen 167:168
Ident 168:169 text="n"
Colon 169:170
Ident 171:174 text="int"
RParen 174:175
Arrow 176:178
Ident 179:183 text="List"
Lt 183:184
Ident 184:187 text="int"
Gt 187:188
LBrace 189:190
Newline 190:191
Var 195:198
Ident 199:202 text="out"
Assign 203:204
LBracket 205:206
Number 206:207 text="0" suf="" isf=0 int=0
RBracket 207:208
Newline 208:209
Ident 213:216 text="out"
Dot 216:217
Ident 217:220 text="pop"
LParen 220:221
RParen 221:222
Newline 222:223
Var 227:230
Ident 231:232 text="i"
Assign 233:234
Number 235:236 text="0" suf="" isf=0 int=0
Newline 236:237
While 241:246
LParen 247:248
Ident 248:249 text="i"
Lt 250:251
Ident 252:253 text="n"
RParen 253:254
LBrace 255:256
Newline 256:257
Ident 265:268 text="out"
Dot 268:269
Ident 269:273 text="push"
LParen 273:274
Ident 274:275 text="i"
RParen 275:276
Newline 276:277
Ident 285:286 text="i"
Assign 287:288
Ident 289:290 text="i"
Plus 291:292
Number 293:294 text="1" suf="" isf=0 int=1
Newline 294:295
RBrace 299:300
Newline 300:301
Ident 305:308 text="out"
Newline 308:309
RBrace 309:310
Newline 310:311
Newline 311:312
Fn 312:314
Ident 315:319 text="main"
LParen 319:320
RParen 320:321
LBrace 322:323
Newline 323:324
Ident 328:335 text="println"
LParen 335:336
Ident 336:339 text="str"
LParen 339:340
Ident 340:341 text="h"
LParen 341:342
LBracket 342:343
Number 343:344 text="0" suf="" isf=0 int=0
RBracket 344:345
RParen 345:346
RParen 346:347
RParen 347:348
Newline 348:349
Ident 353:360 text="println"
LParen 360:361
Ident 361:364 text="str"
LParen 364:365
Ident 365:367 text="h2"
LParen 367:368
Number 368:369 text="5" suf="" isf=0 int=5
Comma 369:370
LBracket 371:372
Number 372:373 text="6" suf="" isf=0 int=6
Comma 373:374
Number 375:376 text="7" suf="" isf=0 int=7
RBracket 376:377
RParen 377:378
RParen 378:379
RParen 379:380
Newline 380:381
Ident 385:392 text="println"
LParen 392:393
Ident 393:396 text="str"
LParen 396:397
Ident 397:399 text="h2"
LParen 399:400
Number 400:401 text="1" suf="" isf=0 int=1
Comma 401:402
Ident 403:404 text="r"
LParen 404:405
Number 405:406 text="2" suf="" isf=0 int=2
RParen 406:407
RParen 407:408
RParen 408:409
RParen 409:410
Newline 410:411
Var 415:418
Ident 419:420 text="q"
Assign 421:422
Number 423:424 text="0" suf="" isf=0 int=0
RangeIncl 425:428
Number 429:430 text="3" suf="" isf=0 int=3
Newline 430:431
Var 435:438
Ident 439:442 text="tot"
Assign 443:444
Number 445:446 text="0" suf="" isf=0 int=0
Newline 446:447
For 451:454
LParen 455:456
Ident 456:457 text="x"
In 458:460
Ident 461:462 text="q"
RParen 462:463
LBrace 464:465
Newline 465:466
Ident 474:477 text="tot"
Assign 478:479
Ident 480:483 text="tot"
Plus 484:485
Ident 486:487 text="x"
Newline 487:488
RBrace 492:493
Newline 493:494
Ident 498:505 text="println"
LParen 505:506
Str 506:514 T("range ")
Plus 515:516
Ident 517:520 text="str"
LParen 520:521
Ident 521:524 text="tot"
RParen 524:525
RParen 525:526
Newline 526:527
Var 531:534
Ident 535:539 text="half"
Assign 540:541
Number 542:543 text="0" suf="" isf=0 int=0
Range 544:546
Number 547:548 text="4" suf="" isf=0 int=4
Newline 548:549
Var 553:556
Ident 557:561 text="tot2"
Assign 562:563
Number 564:565 text="0" suf="" isf=0 int=0
Newline 565:566
For 570:573
LParen 574:575
Ident 575:576 text="y"
In 577:579
Ident 580:584 text="half"
RParen 584:585
LBrace 586:587
Newline 587:588
Ident 596:600 text="tot2"
Assign 601:602
Ident 603:607 text="tot2"
Plus 608:609
Ident 610:611 text="y"
Newline 611:612
RBrace 616:617
Newline 617:618
Ident 622:629 text="println"
LParen 629:630
Str 630:637 T("half ")
Plus 638:639
Ident 640:643 text="str"
LParen 643:644
Ident 644:648 text="tot2"
RParen 648:649
RParen 649:650
Newline 650:651
RBrace 651:652
Eof 652:652
