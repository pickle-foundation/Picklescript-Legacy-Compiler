Newline 66:67
Newline 69:70
Newline 146:147
Newline 226:227
Newline 307:308
Newline 385:386
Newline 465:466
Newline 482:483
Newline 485:486
Newline 560:561
Newline 639:640
Newline 718:719
Newline 797:798
Newline 832:833
Newline 833:834
Newline 907:908
Newline 981:982
Newline 1012:1013
Fn 1013:1015
Ident 1016:1021 text="tally"
LParen 1021:1022
RParen 1022:1023
Arrow 1024:1026
Ident 1027:1031 text="List"
Lt 1031:1032
Ident 1032:1035 text="int"
Gt 1035:1036
LBrace 1037:1038
Newline 1038:1039
Var 1043:1046
Ident 1047:1049 text="xs"
Assign 1050:1051
LBracket 1052:1053
Number 1053:1054 text="0" suf="" isf=0 int=0
RBracket 1054:1055
Newline 1055:1056
Ident 1060:1062 text="xs"
Dot 1062:1063
Ident 1063:1066 text="pop"
LParen 1066:1067
RParen 1067:1068
Newline 1068:1069
Ident 1073:1075 text="xs"
Newline 1075:1076
RBrace 1076:1077
Newline 1077:1078
Ident 1078:1082 text="test"
Fn 1083:1085
Ident 1086:1122 text="spawn_runs_the_body_and_join_returns"
LParen 1122:1123
RParen 1123:1124
LBrace 1125:1126
Newline 1126:1127
Let 1131:1134
Ident 1135:1138 text="ran"
Assign 1139:1140
Ident 1141:1146 text="tally"
LParen 1146:1147
RParen 1147:1148
Newline 1148:1149
Let 1153:1156
Ident 1157:1158 text="t"
Assign 1159:1160
Ident 1161:1173 text="thread_spawn"
LParen 1173:1174
Fn 1174:1176
LParen 1176:1177
RParen 1177:1178
LBrace 1179:1180
Ident 1181:1184 text="ran"
Dot 1184:1185
Ident 1185:1189 text="push"
LParen 1189:1190
Number 1190:1191 text="1" suf="" isf=0 int=1
RParen 1191:1192
RBrace 1193:1194
RParen 1194:1195
Newline 1195:1196
Ident 1200:1206 text="expect"
LParen 1206:1207
Ident 1207:1218 text="thread_join"
LParen 1218:1219
Ident 1219:1220 text="t"
RParen 1220:1221
RParen 1221:1222
Dot 1222:1223
Ident 1223:1227 text="toBe"
LParen 1227:1228
True 1228:1232
RParen 1232:1233
Newline 1233:1234
Ident 1238:1244 text="expect"
LParen 1244:1245
Ident 1245:1260 text="thread_finished"
LParen 1260:1261
Ident 1261:1262 text="t"
RParen 1262:1263
RParen 1263:1264
Dot 1264:1265
Ident 1265:1269 text="toBe"
LParen 1269:1270
True 1270:1274
RParen 1274:1275
Newline 1275:1276
Ident 1280:1286 text="expect"
LParen 1286:1287
Ident 1287:1290 text="len"
LParen 1290:1291
Ident 1291:1294 text="ran"
RParen 1294:1295
RParen 1295:1296
Dot 1296:1297
Ident 1297:1301 text="toBe"
LParen 1301:1302
Number 1302:1303 text="1" suf="" isf=0 int=1
RParen 1303:1304
Newline 1304:1305
RBrace 1305:1306
Newline 1306:1307
Newline 1307:1308
Ident 1308:1312 text="test"
Fn 1313:1315
Ident 1316:1332 text="a_task_can_print"
LParen 1332:1333
RParen 1333:1334
LBrace 1335:1336
Newline 1336:1337
Let 1341:1344
Ident 1345:1346 text="t"
Assign 1347:1348
Ident 1349:1361 text="thread_spawn"
LParen 1361:1362
Fn 1362:1364
LParen 1364:1365
RParen 1365:1366
LBrace 1367:1368
Ident 1369:1376 text="println"
LParen 1376:1377
Str 1377:1401 T("a task wrote this line")
RParen 1401:1402
RBrace 1403:1404
RParen 1404:1405
Newline 1405:1406
Ident 1410:1416 text="expect"
LParen 1416:1417
Ident 1417:1428 text="thread_join"
LParen 1428:1429
Ident 1429:1430 text="t"
RParen 1430:1431
RParen 1431:1432
Dot 1432:1433
Ident 1433:1437 text="toBe"
LParen 1437:1438
True 1438:1442
RParen 1442:1443
Newline 1443:1444
RBrace 1444:1445
Newline 1445:1446
Newline 1446:1447
Ident 1447:1451 text="test"
Fn 1452:1454
Ident 1455:1496 text="several_tasks_all_run_before_join_returns"
LParen 1496:1497
RParen 1497:1498
LBrace 1499:1500
Newline 1500:1501
Let 1505:1508
Ident 1509:1512 text="ran"
Assign 1513:1514
Ident 1515:1520 text="tally"
LParen 1520:1521
RParen 1521:1522
Newline 1522:1523
Let 1527:1530
Ident 1531:1532 text="a"
Assign 1533:1534
Ident 1535:1547 text="thread_spawn"
LParen 1547:1548
Fn 1548:1550
LParen 1550:1551
RParen 1551:1552
LBrace 1553:1554
Ident 1555:1558 text="ran"
Dot 1558:1559
Ident 1559:1563 text="push"
LParen 1563:1564
Number 1564:1565 text="1" suf="" isf=0 int=1
RParen 1565:1566
RBrace 1567:1568
RParen 1568:1569
Newline 1569:1570
Let 1574:1577
Ident 1578:1579 text="b"
Assign 1580:1581
Ident 1582:1594 text="thread_spawn"
LParen 1594:1595
Fn 1595:1597
LParen 1597:1598
RParen 1598:1599
LBrace 1600:1601
Ident 1602:1605 text="ran"
Dot 1605:1606
Ident 1606:1610 text="push"
LParen 1610:1611
Number 1611:1612 text="2" suf="" isf=0 int=2
RParen 1612:1613
RBrace 1614:1615
RParen 1615:1616
Newline 1616:1617
Let 1621:1624
Ident 1625:1626 text="c"
Assign 1627:1628
Ident 1629:1641 text="thread_spawn"
LParen 1641:1642
Fn 1642:1644
LParen 1644:1645
RParen 1645:1646
LBrace 1647:1648
Ident 1649:1652 text="ran"
Dot 1652:1653
Ident 1653:1657 text="push"
LParen 1657:1658
Number 1658:1659 text="3" suf="" isf=0 int=3
RParen 1659:1660
RBrace 1661:1662
RParen 1662:1663
Newline 1663:1664
Ident 1668:1674 text="expect"
LParen 1674:1675
Ident 1675:1686 text="thread_join"
LParen 1686:1687
Ident 1687:1688 text="a"
RParen 1688:1689
RParen 1689:1690
Dot 1690:1691
Ident 1691:1695 text="toBe"
LParen 1695:1696
True 1696:1700
RParen 1700:1701
Newline 1701:1702
Ident 1706:1712 text="expect"
LParen 1712:1713
Ident 1713:1724 text="thread_join"
LParen 1724:1725
Ident 1725:1726 text="b"
RParen 1726:1727
RParen 1727:1728
Dot 1728:1729
Ident 1729:1733 text="toBe"
LParen 1733:1734
True 1734:1738
RParen 1738:1739
Newline 1739:1740
Ident 1744:1750 text="expect"
LParen 1750:1751
Ident 1751:1762 text="thread_join"
LParen 1762:1763
Ident 1763:1764 text="c"
RParen 1764:1765
RParen 1765:1766
Dot 1766:1767
Ident 1767:1771 text="toBe"
LParen 1771:1772
True 1772:1776
RParen 1776:1777
Newline 1777:1778
Ident 1782:1788 text="expect"
LParen 1788:1789
Ident 1789:1792 text="len"
LParen 1792:1793
Ident 1793:1796 text="ran"
RParen 1796:1797
RParen 1797:1798
Dot 1798:1799
Ident 1799:1803 text="toBe"
LParen 1803:1804
Number 1804:1805 text="3" suf="" isf=0 int=3
RParen 1805:1806
Newline 1806:1807
Ident 1811:1817 text="expect"
LParen 1817:1818
Ident 1818:1830 text="thread_count"
LParen 1830:1831
RParen 1831:1832
Ge 1833:1835
Number 1836:1837 text="3" suf="" isf=0 int=3
RParen 1837:1838
Dot 1838:1839
Ident 1839:1843 text="toBe"
LParen 1843:1844
True 1844:1848
RParen 1848:1849
Newline 1849:1850
RBrace 1850:1851
Newline 1851:1852
Newline 1852:1853
Ident 1853:1857 text="test"
Fn 1858:1860
Ident 1861:1894 text="join_waits_for_a_task_that_sleeps"
LParen 1894:1895
RParen 1895:1896
LBrace 1897:1898
Newline 1898:1899
Let 1903:1906
Ident 1907:1910 text="ran"
Assign 1911:1912
Ident 1913:1918 text="tally"
LParen 1918:1919
RParen 1919:1920
Newline 1920:1921
Let 1925:1928
Ident 1929:1930 text="t"
Assign 1931:1932
Ident 1933:1945 text="thread_spawn"
LParen 1945:1946
Fn 1946:1948
LParen 1948:1949
RParen 1949:1950
LBrace 1951:1952
Newline 1952:1953
Ident 1961:1969 text="sleep_ms"
LParen 1969:1970
Number 1970:1972 text="20" suf="" isf=0 int=20
RParen 1972:1973
Newline 1973:1974
Ident 1982:1985 text="ran"
Dot 1985:1986
Ident 1986:1990 text="push"
LParen 1990:1991
Number 1991:1992 text="1" suf="" isf=0 int=1
RParen 1992:1993
Newline 1993:1994
RBrace 1998:1999
RParen 1999:2000
Newline 2000:2001
Newline 2078:2079
Newline 2148:2149
Ident 2153:2161 text="sleep_ms"
LParen 2161:2162
Number 2162:2163 text="1" suf="" isf=0 int=1
RParen 2163:2164
Newline 2164:2165
Ident 2169:2175 text="expect"
LParen 2175:2176
Ident 2176:2191 text="thread_finished"
LParen 2191:2192
Ident 2192:2193 text="t"
RParen 2193:2194
RParen 2194:2195
Dot 2195:2196
Ident 2196:2200 text="toBe"
LParen 2200:2201
False 2201:2206
RParen 2206:2207
Newline 2207:2208
Ident 2212:2218 text="expect"
LParen 2218:2219
Ident 2219:2230 text="thread_join"
LParen 2230:2231
Ident 2231:2232 text="t"
RParen 2232:2233
RParen 2233:2234
Dot 2234:2235
Ident 2235:2239 text="toBe"
LParen 2239:2240
True 2240:2244
RParen 2244:2245
Newline 2245:2246
Ident 2250:2256 text="expect"
LParen 2256:2257
Ident 2257:2272 text="thread_finished"
LParen 2272:2273
Ident 2273:2274 text="t"
RParen 2274:2275
RParen 2275:2276
Dot 2276:2277
Ident 2277:2281 text="toBe"
LParen 2281:2282
True 2282:2286
RParen 2286:2287
Newline 2287:2288
Ident 2292:2298 text="expect"
LParen 2298:2299
Ident 2299:2302 text="len"
LParen 2302:2303
Ident 2303:2306 text="ran"
RParen 2306:2307
RParen 2307:2308
Dot 2308:2309
Ident 2309:2313 text="toBe"
LParen 2313:2314
Number 2314:2315 text="1" suf="" isf=0 int=1
RParen 2315:2316
Newline 2316:2317
RBrace 2317:2318
Newline 2318:2319
Newline 2319:2320
Ident 2320:2324 text="test"
Fn 2325:2327
Ident 2328:2371 text="a_task_can_allocate_while_this_thread_waits"
LParen 2371:2372
RParen 2372:2373
LBrace 2374:2375
Newline 2375:2376
Newline 2450:2451
Newline 2512:2513
Let 2517:2520
Ident 2521:2525 text="made"
Assign 2526:2527
Ident 2528:2533 text="tally"
LParen 2533:2534
RParen 2534:2535
Newline 2535:2536
Let 2540:2543
Ident 2544:2545 text="t"
Assign 2546:2547
Ident 2548:2560 text="thread_spawn"
LParen 2560:2561
Fn 2561:2563
LParen 2563:2564
RParen 2564:2565
LBrace 2566:2567
Newline 2567:2568
Var 2576:2579
Ident 2580:2582 text="xs"
Assign 2583:2584
LBracket 2585:2586
Number 2586:2587 text="1" suf="" isf=0 int=1
Comma 2587:2588
Number 2589:2590 text="2" suf="" isf=0 int=2
Comma 2590:2591
Number 2592:2593 text="3" suf="" isf=0 int=3
RBracket 2593:2594
Newline 2594:2595
For 2603:2606
LParen 2607:2608
Ident 2608:2609 text="i"
In 2610:2612
Number 2613:2614 text="0" suf="" isf=0 int=0
Range 2614:2616
Number 2616:2618 text="10" suf="" isf=0 int=10
RParen 2618:2619
LBrace 2620:2621
Newline 2621:2622
Ident 2634:2636 text="xs"
Dot 2636:2637
Ident 2637:2641 text="push"
LParen 2641:2642
Ident 2642:2643 text="i"
RParen 2643:2644
Newline 2644:2645
RBrace 2653:2654
Newline 2654:2655
Ident 2663:2667 text="made"
Dot 2667:2668
Ident 2668:2672 text="push"
LParen 2672:2673
Ident 2673:2676 text="len"
LParen 2676:2677
Ident 2677:2679 text="xs"
RParen 2679:2680
RParen 2680:2681
Newline 2681:2682
RBrace 2686:2687
RParen 2687:2688
Newline 2688:2689
Ident 2693:2699 text="expect"
LParen 2699:2700
Ident 2700:2711 text="thread_join"
LParen 2711:2712
Ident 2712:2713 text="t"
RParen 2713:2714
RParen 2714:2715
Dot 2715:2716
Ident 2716:2720 text="toBe"
LParen 2720:2721
True 2721:2725
RParen 2725:2726
Newline 2726:2727
Ident 2731:2737 text="expect"
LParen 2737:2738
Ident 2738:2741 text="len"
LParen 2741:2742
Ident 2742:2746 text="made"
RParen 2746:2747
RParen 2747:2748
Dot 2748:2749
Ident 2749:2753 text="toBe"
LParen 2753:2754
Number 2754:2755 text="1" suf="" isf=0 int=1
RParen 2755:2756
Newline 2756:2757
Ident 2761:2767 text="expect"
LParen 2767:2768
Ident 2768:2772 text="made"
LBracket 2772:2773
Number 2773:2774 text="0" suf="" isf=0 int=0
RBracket 2774:2775
RParen 2775:2776
Dot 2776:2777
Ident 2777:2781 text="toBe"
LParen 2781:2782
Number 2782:2784 text="13" suf="" isf=0 int=13
RParen 2784:2785
Newline 2785:2786
RBrace 2786:2787
Newline 2787:2788
Newline 2788:2789
Ident 2789:2793 text="test"
Fn 2794:2796
Ident 2797:2823 text="mutex_serialises_two_tasks"
LParen 2823:2824
RParen 2824:2825
LBrace 2826:2827
Newline 2827:2828
Newline 2903:2904
Newline 2981:2982
Newline 3002:3003
Let 3007:3010
Ident 3011:3012 text="m"
Assign 3013:3014
Ident 3015:3024 text="mutex_new"
LParen 3024:3025
RParen 3025:3026
Newline 3026:3027
Let 3031:3034
Ident 3035:3042 text="counter"
Assign 3043:3044
Ident 3045:3055 text="atomic_new"
LParen 3055:3056
Number 3056:3057 text="0" suf="" isf=0 int=0
RParen 3057:3058
Newline 3058:3059
Let 3063:3066
Ident 3067:3068 text="t"
Assign 3069:3070
Ident 3071:3083 text="thread_spawn"
LParen 3083:3084
Fn 3084:3086
LParen 3086:3087
RParen 3087:3088
LBrace 3089:3090
Newline 3090:3091
Ident 3099:3109 text="mutex_lock"
LParen 3109:3110
Ident 3110:3111 text="m"
RParen 3111:3112
Newline 3112:3113
Let 3121:3124
Ident 3125:3128 text="was"
Assign 3129:3130
Ident 3131:3142 text="atomic_load"
LParen 3142:3143
Ident 3143:3150 text="counter"
RParen 3150:3151
Newline 3151:3152
Ident 3160:3168 text="sleep_ms"
LParen 3168:3169
Number 3169:3170 text="1" suf="" isf=0 int=1
RParen 3170:3171
Newline 3171:3172
Ident 3180:3192 text="atomic_store"
LParen 3192:3193
Ident 3193:3200 text="counter"
Comma 3200:3201
Ident 3202:3205 text="was"
Plus 3206:3207
Number 3208:3209 text="1" suf="" isf=0 int=1
RParen 3209:3210
Newline 3210:3211
Ident 3219:3231 text="mutex_unlock"
LParen 3231:3232
Ident 3232:3233 text="m"
RParen 3233:3234
Newline 3234:3235
RBrace 3239:3240
RParen 3240:3241
Newline 3241:3242
Ident 3246:3256 text="mutex_lock"
LParen 3256:3257
Ident 3257:3258 text="m"
RParen 3258:3259
Newline 3259:3260
Let 3264:3267
Ident 3268:3271 text="was"
Assign 3272:3273
Ident 3274:3285 text="atomic_load"
LParen 3285:3286
Ident 3286:3293 text="counter"
RParen 3293:3294
Newline 3294:3295
Ident 3299:3307 text="sleep_ms"
LParen 3307:3308
Number 3308:3309 text="1" suf="" isf=0 int=1
RParen 3309:3310
Newline 3310:3311
Ident 3315:3327 text="atomic_store"
LParen 3327:3328
Ident 3328:3335 text="counter"
Comma 3335:3336
Ident 3337:3340 text="was"
Plus 3341:3342
Number 3343:3344 text="1" suf="" isf=0 int=1
RParen 3344:3345
Newline 3345:3346
Ident 3350:3362 text="mutex_unlock"
LParen 3362:3363
Ident 3363:3364 text="m"
RParen 3364:3365
Newline 3365:3366
Ident 3370:3376 text="expect"
LParen 3376:3377
Ident 3377:3388 text="thread_join"
LParen 3388:3389
Ident 3389:3390 text="t"
RParen 3390:3391
RParen 3391:3392
Dot 3392:3393
Ident 3393:3397 text="toBe"
LParen 3397:3398
True 3398:3402
RParen 3402:3403
Newline 3403:3404
Ident 3408:3414 text="expect"
LParen 3414:3415
Ident 3415:3426 text="atomic_load"
LParen 3426:3427
Ident 3427:3434 text="counter"
RParen 3434:3435
RParen 3435:3436
Dot 3436:3437
Ident 3437:3441 text="toBe"
LParen 3441:3442
Number 3442:3443 text="2" suf="" isf=0 int=2
RParen 3443:3444
Newline 3444:3445
RBrace 3445:3446
Newline 3446:3447
Newline 3447:3448
Ident 3448:3452 text="test"
Fn 3453:3455
Ident 3456:3488 text="cond_signal_wakes_a_waiting_task"
LParen 3488:3489
RParen 3489:3490
LBrace 3491:3492
Newline 3492:3493
Let 3497:3500
Ident 3501:3502 text="m"
Assign 3503:3504
Ident 3505:3514 text="mutex_new"
LParen 3514:3515
RParen 3515:3516
Newline 3516:3517
Let 3521:3524
Ident 3525:3526 text="c"
Assign 3527:3528
Ident 3529:3537 text="cond_new"
LParen 3537:3538
RParen 3538:3539
Newline 3539:3540
Let 3544:3547
Ident 3548:3552 text="woke"
Assign 3553:3554
Ident 3555:3565 text="atomic_new"
LParen 3565:3566
Number 3566:3567 text="0" suf="" isf=0 int=0
RParen 3567:3568
Newline 3568:3569
Let 3573:3576
Ident 3577:3578 text="t"
Assign 3579:3580
Ident 3581:3593 text="thread_spawn"
LParen 3593:3594
Fn 3594:3596
LParen 3596:3597
RParen 3597:3598
LBrace 3599:3600
Newline 3600:3601
Ident 3609:3619 text="mutex_lock"
LParen 3619:3620
Ident 3620:3621 text="m"
RParen 3621:3622
Newline 3622:3623
Ident 3631:3640 text="cond_wait"
LParen 3640:3641
Ident 3641:3642 text="c"
Comma 3642:3643
Ident 3644:3645 text="m"
RParen 3645:3646
Newline 3646:3647
Ident 3655:3667 text="atomic_store"
LParen 3667:3668
Ident 3668:3672 text="woke"
Comma 3672:3673
Number 3674:3675 text="1" suf="" isf=0 int=1
RParen 3675:3676
Newline 3676:3677
Ident 3685:3697 text="mutex_unlock"
LParen 3697:3698
Ident 3698:3699 text="m"
RParen 3699:3700
Newline 3700:3701
RBrace 3705:3706
RParen 3706:3707
Newline 3707:3708
Ident 3712:3720 text="sleep_ms"
LParen 3720:3721
Number 3721:3722 text="5" suf="" isf=0 int=5
RParen 3722:3723
Newline 3723:3724
Ident 3728:3739 text="cond_signal"
LParen 3739:3740
Ident 3740:3741 text="c"
RParen 3741:3742
Newline 3742:3743
Ident 3747:3753 text="expect"
LParen 3753:3754
Ident 3754:3765 text="thread_join"
LParen 3765:3766
Ident 3766:3767 text="t"
RParen 3767:3768
RParen 3768:3769
Dot 3769:3770
Ident 3770:3774 text="toBe"
LParen 3774:3775
True 3775:3779
RParen 3779:3780
Newline 3780:3781
Ident 3785:3791 text="expect"
LParen 3791:3792
Ident 3792:3803 text="atomic_load"
LParen 3803:3804
Ident 3804:3808 text="woke"
RParen 3808:3809
RParen 3809:3810
Dot 3810:3811
Ident 3811:3815 text="toBe"
LParen 3815:3816
Number 3816:3817 text="1" suf="" isf=0 int=1
RParen 3817:3818
Newline 3818:3819
RBrace 3819:3820
Newline 3820:3821
Newline 3821:3822
Ident 3822:3826 text="test"
Fn 3827:3829
Ident 3830:3864 text="semaphore_counts_down_across_tasks"
LParen 3864:3865
RParen 3865:3866
LBrace 3867:3868
Newline 3868:3869
Let 3873:3876
Ident 3877:3878 text="s"
Assign 3879:3880
Ident 3881:3888 text="sem_new"
LParen 3888:3889
Number 3889:3890 text="1" suf="" isf=0 int=1
RParen 3890:3891
Newline 3891:3892
Let 3896:3899
Ident 3900:3904 text="took"
Assign 3905:3906
Ident 3907:3917 text="atomic_new"
LParen 3917:3918
Number 3918:3919 text="0" suf="" isf=0 int=0
RParen 3919:3920
Newline 3920:3921
Let 3925:3928
Ident 3929:3930 text="t"
Assign 3931:3932
Ident 3933:3945 text="thread_spawn"
LParen 3945:3946
Fn 3946:3948
LParen 3948:3949
RParen 3949:3950
LBrace 3951:3952
Newline 3952:3953
Ident 3961:3972 text="sem_acquire"
LParen 3972:3973
Ident 3973:3974 text="s"
Comma 3974:3975
Number 3976:3977 text="1" suf="" isf=0 int=1
RParen 3977:3978
Newline 3978:3979
Ident 3987:3999 text="atomic_store"
LParen 3999:4000
Ident 4000:4004 text="took"
Comma 4004:4005
Number 4006:4007 text="1" suf="" isf=0 int=1
RParen 4007:4008
Newline 4008:4009
Ident 4017:4028 text="sem_release"
LParen 4028:4029
Ident 4029:4030 text="s"
Comma 4030:4031
Number 4032:4033 text="1" suf="" isf=0 int=1
RParen 4033:4034
Newline 4034:4035
RBrace 4039:4040
RParen 4040:4041
Newline 4041:4042
Ident 4046:4052 text="expect"
LParen 4052:4053
Ident 4053:4064 text="thread_join"
LParen 4064:4065
Ident 4065:4066 text="t"
RParen 4066:4067
RParen 4067:4068
Dot 4068:4069
Ident 4069:4073 text="toBe"
LParen 4073:4074
True 4074:4078
RParen 4078:4079
Newline 4079:4080
Ident 4084:4090 text="expect"
LParen 4090:4091
Ident 4091:4102 text="atomic_load"
LParen 4102:4103
Ident 4103:4107 text="took"
RParen 4107:4108
RParen 4108:4109
Dot 4109:4110
Ident 4110:4114 text="toBe"
LParen 4114:4115
Number 4115:4116 text="1" suf="" isf=0 int=1
RParen 4116:4117
Newline 4117:4118
Ident 4122:4128 text="expect"
LParen 4128:4129
Ident 4129:4144 text="sem_try_acquire"
LParen 4144:4145
Ident 4145:4146 text="s"
Comma 4146:4147
Number 4148:4149 text="1" suf="" isf=0 int=1
RParen 4149:4150
RParen 4150:4151
Dot 4151:4152
Ident 4152:4156 text="toBe"
LParen 4156:4157
True 4157:4161
RParen 4161:4162
Newline 4162:4163
RBrace 4163:4164
Newline 4164:4165
Newline 4165:4166
Ident 4166:4170 text="test"
Fn 4171:4173
Ident 4174:4192 text="atomics_are_shared"
LParen 4192:4193
RParen 4193:4194
LBrace 4195:4196
Newline 4196:4197
Let 4201:4204
Ident 4205:4206 text="a"
Assign 4207:4208
Ident 4209:4219 text="atomic_new"
LParen 4219:4220
Number 4220:4221 text="0" suf="" isf=0 int=0
RParen 4221:4222
Newline 4222:4223
Let 4227:4230
Ident 4231:4235 text="seen"
Assign 4236:4237
Ident 4238:4248 text="atomic_new"
LParen 4248:4249
Number 4249:4250 text="0" suf="" isf=0 int=0
RParen 4250:4251
Newline 4251:4252
Let 4256:4259
Ident 4260:4261 text="t"
Assign 4262:4263
Ident 4264:4276 text="thread_spawn"
LParen 4276:4277
Fn 4277:4279
LParen 4279:4280
RParen 4280:4281
LBrace 4282:4283
Newline 4283:4284
Let 4292:4295
Ident 4296:4299 text="was"
Assign 4300:4301
Ident 4302:4312 text="atomic_add"
LParen 4312:4313
Ident 4313:4314 text="a"
Comma 4314:4315
Number 4316:4317 text="5" suf="" isf=0 int=5
RParen 4317:4318
Newline 4318:4319
Ident 4327:4339 text="atomic_store"
LParen 4339:4340
Ident 4340:4344 text="seen"
Comma 4344:4345
Ident 4346:4349 text="was"
RParen 4349:4350
Newline 4350:4351
RBrace 4355:4356
RParen 4356:4357
Newline 4357:4358
Ident 4362:4368 text="expect"
LParen 4368:4369
Ident 4369:4380 text="thread_join"
LParen 4380:4381
Ident 4381:4382 text="t"
RParen 4382:4383
RParen 4383:4384
Dot 4384:4385
Ident 4385:4389 text="toBe"
LParen 4389:4390
True 4390:4394
RParen 4394:4395
Newline 4395:4396
Ident 4400:4406 text="expect"
LParen 4406:4407
Ident 4407:4418 text="atomic_load"
LParen 4418:4419
Ident 4419:4423 text="seen"
RParen 4423:4424
RParen 4424:4425
Dot 4425:4426
Ident 4426:4430 text="toBe"
LParen 4430:4431
Number 4431:4432 text="0" suf="" isf=0 int=0
RParen 4432:4433
Newline 4433:4434
Ident 4438:4444 text="expect"
LParen 4444:4445
Ident 4445:4456 text="atomic_load"
LParen 4456:4457
Ident 4457:4458 text="a"
RParen 4458:4459
RParen 4459:4460
Dot 4460:4461
Ident 4461:4465 text="toBe"
LParen 4465:4466
Number 4466:4467 text="5" suf="" isf=0 int=5
RParen 4467:4468
Newline 4468:4469
Ident 4473:4479 text="expect"
LParen 4479:4480
Ident 4480:4490 text="atomic_cas"
LParen 4490:4491
Ident 4491:4492 text="a"
Comma 4492:4493
Number 4494:4495 text="5" suf="" isf=0 int=5
Comma 4495:4496
Number 4497:4498 text="9" suf="" isf=0 int=9
RParen 4498:4499
RParen 4499:4500
Dot 4500:4501
Ident 4501:4505 text="toBe"
LParen 4505:4506
True 4506:4510
RParen 4510:4511
Newline 4511:4512
Ident 4516:4522 text="expect"
LParen 4522:4523
Ident 4523:4534 text="atomic_load"
LParen 4534:4535
Ident 4535:4536 text="a"
RParen 4536:4537
RParen 4537:4538
Dot 4538:4539
Ident 4539:4543 text="toBe"
LParen 4543:4544
Number 4544:4545 text="9" suf="" isf=0 int=9
RParen 4545:4546
Newline 4546:4547
Ident 4551:4557 text="expect"
LParen 4557:4558
Ident 4558:4568 text="atomic_cas"
LParen 4568:4569
Ident 4569:4570 text="a"
Comma 4570:4571
Number 4572:4573 text="5" suf="" isf=0 int=5
Comma 4573:4574
Number 4575:4577 text="11" suf="" isf=0 int=11
RParen 4577:4578
RParen 4578:4579
Dot 4579:4580
Ident 4580:4584 text="toBe"
LParen 4584:4585
False 4585:4590
RParen 4590:4591
Newline 4591:4592
Ident 4596:4602 text="expect"
LParen 4602:4603
Ident 4603:4614 text="atomic_load"
LParen 4614:4615
Ident 4615:4616 text="a"
RParen 4616:4617
RParen 4617:4618
Dot 4618:4619
Ident 4619:4623 text="toBe"
LParen 4623:4624
Number 4624:4625 text="9" suf="" isf=0 int=9
RParen 4625:4626
Newline 4626:4627
RBrace 4627:4628
Newline 4628:4629
Newline 4629:4630
Ident 4630:4634 text="test"
Fn 4635:4637
Ident 4638:4670 text="once_runs_the_body_a_single_time"
LParen 4670:4671
RParen 4671:4672
LBrace 4673:4674
Newline 4674:4675
Newline 4755:4756
Newline 4836:4837
Newline 4916:4917
Newline 4938:4939
Let 4943:4946
Ident 4947:4948 text="o"
Assign 4949:4950
Ident 4951:4959 text="once_new"
LParen 4959:4960
RParen 4960:4961
Newline 4961:4962
Let 4966:4969
Ident 4970:4974 text="runs"
Assign 4975:4976
Ident 4977:4987 text="atomic_new"
LParen 4987:4988
Number 4988:4989 text="0" suf="" isf=0 int=0
RParen 4989:4990
Newline 4990:4991
Let 4995:4998
Ident 4999:5003 text="last"
Assign 5004:5005
Ident 5006:5016 text="atomic_new"
LParen 5016:5017
Number 5017:5018 text="0" suf="" isf=0 int=0
RParen 5018:5019
Newline 5019:5020
Let 5024:5027
Ident 5028:5032 text="wins"
Assign 5033:5034
Ident 5035:5045 text="atomic_new"
LParen 5045:5046
Number 5046:5047 text="0" suf="" isf=0 int=0
RParen 5047:5048
Newline 5048:5049
Let 5053:5056
Ident 5057:5061 text="body"
Assign 5062:5063
Fn 5064:5066
LParen 5066:5067
RParen 5067:5068
LBrace 5069:5070
Newline 5070:5071
Let 5079:5082
Ident 5083:5086 text="was"
Assign 5087:5088
Ident 5089:5099 text="atomic_add"
LParen 5099:5100
Ident 5100:5104 text="runs"
Comma 5104:5105
Number 5106:5107 text="1" suf="" isf=0 int=1
RParen 5107:5108
Newline 5108:5109
Ident 5117:5129 text="atomic_store"
LParen 5129:5130
Ident 5130:5134 text="last"
Comma 5134:5135
Ident 5136:5139 text="was"
RParen 5139:5140
Newline 5140:5141
RBrace 5145:5146
Newline 5146:5147
Let 5151:5154
Ident 5155:5156 text="a"
Assign 5157:5158
Ident 5159:5171 text="thread_spawn"
LParen 5171:5172
Fn 5172:5174
LParen 5174:5175
RParen 5175:5176
LBrace 5177:5178
Newline 5178:5179
Let 5187:5190
Ident 5191:5194 text="won"
Assign 5195:5196
Ident 5197:5205 text="once_run"
LParen 5205:5206
Ident 5206:5207 text="o"
Comma 5207:5208
Ident 5209:5213 text="body"
RParen 5213:5214
Newline 5214:5215
If 5223:5225
LParen 5226:5227
Ident 5227:5230 text="won"
RParen 5230:5231
LBrace 5232:5233
Newline 5233:5234
Ident 5246:5256 text="atomic_add"
LParen 5256:5257
Ident 5257:5261 text="wins"
Comma 5261:5262
Number 5263:5264 text="1" suf="" isf=0 int=1
RParen 5264:5265
Newline 5265:5266
RBrace 5274:5275
Newline 5275:5276
RBrace 5280:5281
RParen 5281:5282
Newline 5282:5283
Let 5287:5290
Ident 5291:5292 text="b"
Assign 5293:5294
Ident 5295:5307 text="thread_spawn"
LParen 5307:5308
Fn 5308:5310
LParen 5310:5311
RParen 5311:5312
LBrace 5313:5314
Newline 5314:5315
Let 5323:5326
Ident 5327:5330 text="won"
Assign 5331:5332
Ident 5333:5341 text="once_run"
LParen 5341:5342
Ident 5342:5343 text="o"
Comma 5343:5344
Ident 5345:5349 text="body"
RParen 5349:5350
Newline 5350:5351
If 5359:5361
LParen 5362:5363
Ident 5363:5366 text="won"
RParen 5366:5367
LBrace 5368:5369
Newline 5369:5370
Ident 5382:5392 text="atomic_add"
LParen 5392:5393
Ident 5393:5397 text="wins"
Comma 5397:5398
Number 5399:5400 text="1" suf="" isf=0 int=1
RParen 5400:5401
Newline 5401:5402
RBrace 5410:5411
Newline 5411:5412
RBrace 5416:5417
RParen 5417:5418
Newline 5418:5419
Ident 5423:5429 text="expect"
LParen 5429:5430
Ident 5430:5441 text="thread_join"
LParen 5441:5442
Ident 5442:5443 text="a"
RParen 5443:5444
RParen 5444:5445
Dot 5445:5446
Ident 5446:5450 text="toBe"
LParen 5450:5451
True 5451:5455
RParen 5455:5456
Newline 5456:5457
Ident 5461:5467 text="expect"
LParen 5467:5468
Ident 5468:5479 text="thread_join"
LParen 5479:5480
Ident 5480:5481 text="b"
RParen 5481:5482
RParen 5482:5483
Dot 5483:5484
Ident 5484:5488 text="toBe"
LParen 5488:5489
True 5489:5493
RParen 5493:5494
Newline 5494:5495
Ident 5499:5505 text="expect"
LParen 5505:5506
Ident 5506:5517 text="atomic_load"
LParen 5517:5518
Ident 5518:5522 text="runs"
RParen 5522:5523
RParen 5523:5524
Dot 5524:5525
Ident 5525:5529 text="toBe"
LParen 5529:5530
Number 5530:5531 text="1" suf="" isf=0 int=1
RParen 5531:5532
Newline 5532:5533
Ident 5537:5543 text="expect"
LParen 5543:5544
Ident 5544:5555 text="atomic_load"
LParen 5555:5556
Ident 5556:5560 text="last"
RParen 5560:5561
RParen 5561:5562
Dot 5562:5563
Ident 5563:5567 text="toBe"
LParen 5567:5568
Number 5568:5569 text="0" suf="" isf=0 int=0
RParen 5569:5570
Newline 5570:5571
Ident 5575:5581 text="expect"
LParen 5581:5582
Ident 5582:5593 text="atomic_load"
LParen 5593:5594
Ident 5594:5598 text="wins"
RParen 5598:5599
RParen 5599:5600
Dot 5600:5601
Ident 5601:5605 text="toBe"
LParen 5605:5606
Number 5606:5607 text="1" suf="" isf=0 int=1
RParen 5607:5608
Newline 5608:5609
Ident 5613:5619 text="expect"
LParen 5619:5620
Ident 5620:5629 text="once_done"
LParen 5629:5630
Ident 5630:5631 text="o"
RParen 5631:5632
RParen 5632:5633
Dot 5633:5634
Ident 5634:5638 text="toBe"
LParen 5638:5639
True 5639:5643
RParen 5643:5644
Newline 5644:5645
Ident 5649:5655 text="expect"
LParen 5655:5656
Ident 5656:5664 text="once_run"
LParen 5664:5665
Ident 5665:5666 text="o"
Comma 5666:5667
Ident 5668:5672 text="body"
RParen 5672:5673
RParen 5673:5674
Dot 5674:5675
Ident 5675:5679 text="toBe"
LParen 5679:5680
False 5680:5685
RParen 5685:5686
Newline 5686:5687
Ident 5691:5697 text="expect"
LParen 5697:5698
Ident 5698:5709 text="atomic_load"
LParen 5709:5710
Ident 5710:5714 text="runs"
RParen 5714:5715
RParen 5715:5716
Dot 5716:5717
Ident 5717:5721 text="toBe"
LParen 5721:5722
Number 5722:5723 text="1" suf="" isf=0 int=1
RParen 5723:5724
Newline 5724:5725
RBrace 5725:5726
Newline 5726:5727
Newline 5727:5728
Ident 5728:5732 text="test"
Fn 5733:5735
Ident 5736:5784 text="a_failing_assert_fails_the_task_and_join_says_so"
LParen 5784:5785
RParen 5785:5786
LBrace 5787:5788
Newline 5788:5789
Newline 5864:5865
Newline 5943:5944
Newline 6002:6003
Let 6007:6010
Ident 6011:6018 text="carried"
Assign 6019:6020
Ident 6021:6026 text="tally"
LParen 6026:6027
RParen 6027:6028
Newline 6028:6029
Let 6033:6036
Ident 6037:6038 text="t"
Assign 6039:6040
Ident 6041:6053 text="thread_spawn"
LParen 6053:6054
Fn 6054:6056
LParen 6056:6057
RParen 6057:6058
LBrace 6059:6060
Newline 6060:6061
Ident 6069:6075 text="assert"
LParen 6075:6076
False 6076:6081
Comma 6081:6082
Str 6083:6099 T("task assertion")
RParen 6099:6100
Newline 6100:6101
Ident 6109:6116 text="carried"
Dot 6116:6117
Ident 6117:6121 text="push"
LParen 6121:6122
Number 6122:6123 text="1" suf="" isf=0 int=1
RParen 6123:6124
Newline 6124:6125
RBrace 6129:6130
RParen 6130:6131
Newline 6131:6132
Ident 6136:6142 text="expect"
LParen 6142:6143
Ident 6143:6154 text="thread_join"
LParen 6154:6155
Ident 6155:6156 text="t"
RParen 6156:6157
RParen 6157:6158
Dot 6158:6159
Ident 6159:6163 text="toBe"
LParen 6163:6164
False 6164:6169
RParen 6169:6170
Newline 6170:6171
Ident 6175:6181 text="expect"
LParen 6181:6182
Ident 6182:6185 text="len"
LParen 6185:6186
Ident 6186:6193 text="carried"
RParen 6193:6194
RParen 6194:6195
Dot 6195:6196
Ident 6196:6200 text="toBe"
LParen 6200:6201
Number 6201:6202 text="1" suf="" isf=0 int=1
RParen 6202:6203
Newline 6203:6204
If 6208:6210
LParen 6211:6212
Let 6212:6215
Ident 6216:6220 text="some"
LParen 6220:6221
Ident 6221:6224 text="msg"
RParen 6224:6225
Assign 6226:6227
Ident 6228:6242 text="thread_message"
LParen 6242:6243
Ident 6243:6244 text="t"
RParen 6244:6245
RParen 6245:6246
LBrace 6247:6248
Newline 6248:6249
Ident 6257:6263 text="expect"
LParen 6263:6264
Ident 6264:6267 text="msg"
RParen 6267:6268
Dot 6268:6269
Ident 6269:6273 text="toBe"
LParen 6273:6274
Str 6274:6290 T("task assertion")
RParen 6290:6291
Newline 6291:6292
RBrace 6296:6297
Else 6298:6302
LBrace 6303:6304
Newline 6304:6305
Ident 6313:6319 text="assert"
LParen 6319:6320
False 6320:6325
Comma 6325:6326
Str 6327:6360 T("expected a task failure message")
RParen 6360:6361
Newline 6361:6362
RBrace 6366:6367
Newline 6367:6368
RBrace 6368:6369
Newline 6369:6370
Newline 6370:6371
Ident 6371:6375 text="test"
Fn 6376:6378
Ident 6379:6423 text="this_test_did_not_inherit_its_tasks_failures"
LParen 6423:6424
RParen 6424:6425
LBrace 6426:6427
Newline 6427:6428
Newline 6506:6507
Newline 6580:6581
Let 6585:6588
Ident 6589:6590 text="t"
Assign 6591:6592
Ident 6593:6605 text="thread_spawn"
LParen 6605:6606
Fn 6606:6608
LParen 6608:6609
RParen 6609:6610
LBrace 6611:6612
Ident 6613:6621 text="sleep_ms"
LParen 6621:6622
Number 6622:6623 text="1" suf="" isf=0 int=1
RParen 6623:6624
RBrace 6625:6626
RParen 6626:6627
Newline 6627:6628
Ident 6632:6638 text="expect"
LParen 6638:6639
Ident 6639:6650 text="thread_join"
LParen 6650:6651
Ident 6651:6652 text="t"
RParen 6652:6653
RParen 6653:6654
Dot 6654:6655
Ident 6655:6659 text="toBe"
LParen 6659:6660
True 6660:6664
RParen 6664:6665
Newline 6665:6666
RBrace 6666:6667
Newline 6667:6668
Newline 6668:6669
Ident 6669:6673 text="test"
Fn 6674:6676
Ident 6677:6711 text="thread_ids_are_distinct_and_stable"
LParen 6711:6712
RParen 6712:6713
LBrace 6714:6715
Newline 6715:6716
Let 6720:6723
Ident 6724:6728 text="mine"
Assign 6729:6730
Ident 6731:6745 text="thread_current"
LParen 6745:6746
RParen 6746:6747
Newline 6747:6748
Ident 6752:6758 text="expect"
LParen 6758:6759
Ident 6759:6763 text="mine"
Gt 6764:6765
Number 6766:6767 text="0" suf="" isf=0 int=0
RParen 6767:6768
Dot 6768:6769
Ident 6769:6773 text="toBe"
LParen 6773:6774
True 6774:6778
RParen 6778:6779
Newline 6779:6780
Ident 6784:6790 text="expect"
LParen 6790:6791
Ident 6791:6805 text="thread_current"
LParen 6805:6806
RParen 6806:6807
RParen 6807:6808
Dot 6808:6809
Ident 6809:6813 text="toBe"
LParen 6813:6814
Ident 6814:6818 text="mine"
RParen 6818:6819
Newline 6819:6820
Let 6824:6827
Ident 6828:6832 text="seen"
Assign 6833:6834
Ident 6835:6845 text="atomic_new"
LParen 6845:6846
Number 6846:6847 text="0" suf="" isf=0 int=0
RParen 6847:6848
Newline 6848:6849
Let 6853:6856
Ident 6857:6858 text="t"
Assign 6859:6860
Ident 6861:6873 text="thread_spawn"
LParen 6873:6874
Fn 6874:6876
LParen 6876:6877
RParen 6877:6878
LBrace 6879:6880
Newline 6880:6881
If 6889:6891
LParen 6892:6893
Ident 6893:6907 text="thread_current"
LParen 6907:6908
RParen 6908:6909
NotEq 6910:6912
Ident 6913:6917 text="mine"
RParen 6917:6918
LBrace 6919:6920
Newline 6920:6921
Ident 6933:6945 text="atomic_store"
LParen 6945:6946
Ident 6946:6950 text="seen"
Comma 6950:6951
Number 6952:6953 text="1" suf="" isf=0 int=1
RParen 6953:6954
Newline 6954:6955
RBrace 6963:6964
Newline 6964:6965
Ident 6973:6985 text="thread_yield"
LParen 6985:6986
RParen 6986:6987
Newline 6987:6988
RBrace 6992:6993
RParen 6993:6994
Newline 6994:6995
Ident 6999:7005 text="expect"
LParen 7005:7006
Ident 7006:7017 text="thread_join"
LParen 7017:7018
Ident 7018:7019 text="t"
RParen 7019:7020
RParen 7020:7021
Dot 7021:7022
Ident 7022:7026 text="toBe"
LParen 7026:7027
True 7027:7031
RParen 7031:7032
Newline 7032:7033
Ident 7037:7043 text="expect"
LParen 7043:7044
Ident 7044:7055 text="atomic_load"
LParen 7055:7056
Ident 7056:7060 text="seen"
RParen 7060:7061
RParen 7061:7062
Dot 7062:7063
Ident 7063:7067 text="toBe"
LParen 7067:7068
Number 7068:7069 text="1" suf="" isf=0 int=1
RParen 7069:7070
Newline 7070:7071
RBrace 7071:7072
Newline 7072:7073
Eof 7073:7073
