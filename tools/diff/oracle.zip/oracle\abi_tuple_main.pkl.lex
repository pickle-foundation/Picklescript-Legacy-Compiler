Module 0:6
Ident 7:21 text="abi_tuple_main"
Newline 22:23
Newline 24:25
Newline 93:94
Newline 97:98
Newline 189:190
Newline 276:277
Newline 362:363
Newline 447:448
Newline 451:452
Newline 541:542
Newline 626:627
Newline 717:718
Newline 810:811
Newline 868:869
Newline 870:871
Import 871:877
LBrace 878:879
Ident 880:888 text="tupleNew"
Comma 888:889
Ident 890:901 text="abiTupleLen"
Comma 901:902
Ident 903:919 text="abiTupleSetField"
Comma 919:920
Ident 921:934 text="abiTupleField"
RBrace 935:936
From 937:941
Ident 942:949 text="runtime"
Dot 949:950
Ident 950:959 text="abi_tuple"
Newline 960:961
Import 961:967
LBrace 968:969
Ident 970:979 text="abiBoxI64"
Comma 979:980
Ident 981:992 text="abiUnboxI64"
RBrace 993:994
From 995:999
Ident 1000:1007 text="runtime"
Dot 1007:1008
Ident 1008:1015 text="abi_box"
Newline 1016:1017
Newline 1018:1019
Newline 1102:1103
Fn 1103:1105 doc="Read field `i` back through the exported `pickle_tuple_field` ABI entry point."
Ident 1106:1108 text="at"
LParen 1108:1109
Ident 1109:1110 text="t"
Colon 1110:1111
Star 1112:1113
Ident 1113:1116 text="int"
Comma 1116:1117
Ident 1118:1119 text="i"
Colon 1119:1120
Ident 1121:1124 text="int"
RParen 1124:1125
Arrow 1126:1128
Ident 1129:1132 text="int"
LBrace 1133:1134
Newline 1135:1136
Return 1140:1146
Ident 1147:1158 text="abiUnboxI64"
LParen 1158:1159
Ident 1159:1172 text="abiTupleField"
LParen 1172:1173
Ident 1173:1174 text="t"
Comma 1174:1175
Ident 1176:1177 text="i"
RParen 1177:1178
RParen 1178:1179
Newline 1180:1181
RBrace 1181:1182
Newline 1183:1184
Newline 1185:1186
Fn 1186:1188
Ident 1189:1193 text="main"
LParen 1193:1194
RParen 1194:1195
LBrace 1196:1197
Newline 1198:1199
Newline 1234:1235
Var 1239:1242
Ident 1243:1244 text="t"
Assign 1245:1246
Ident 1247:1255 text="tupleNew"
LParen 1255:1256
Number 1256:1257 text="3" suf="" isf=0 int=3
RParen 1257:1258
Newline 1259:1260
Unsafe 1264:1270
LBrace 1271:1272
Newline 1273:1274
Ident 1282:1289 text="println"
LParen 1289:1290
Str 1290:1305 T("class: ") E[Ident 1299:1300 text="t"; LBracket 1300:1301; Number 1301:1302 text="1" suf="" isf=0 int=1; RBracket 1302:1303; Eof 1304:1304]
RParen 1305:1306
Newline 1307:1308
Ident 1316:1323 text="println"
LParen 1323:1324
Str 1324:1338 T("size: ") E[Ident 1332:1333 text="t"; LBracket 1333:1334; Number 1334:1335 text="2" suf="" isf=0 int=2; RBracket 1335:1336; Eof 1337:1337]
RParen 1338:1339
Newline 1340:1341
Ident 1349:1356 text="println"
LParen 1356:1357
Str 1357:1377 T("count word: ") E[Ident 1371:1372 text="t"; LBracket 1372:1373; Number 1373:1374 text="3" suf="" isf=0 int=3; RBracket 1374:1375; Eof 1376:1376]
RParen 1377:1378
Newline 1379:1380
Ident 1388:1395 text="println"
LParen 1395:1396
Str 1396:1417 T("field0 word: ") E[Ident 1411:1412 text="t"; LBracket 1412:1413; Number 1413:1414 text="4" suf="" isf=0 int=4; RBracket 1414:1415; Eof 1416:1416]
RParen 1417:1418
Newline 1419:1420
RBrace 1424:1425
Newline 1426:1427
Ident 1431:1438 text="println"
LParen 1438:1439
Str 1439:1462 T("len: ") E[Ident 1446:1457 text="abiTupleLen"; LParen 1457:1458; Ident 1458:1459 text="t"; RParen 1459:1460; Eof 1461:1461]
RParen 1462:1463
Newline 1464:1465
Newline 1466:1467
Newline 1525:1526
Ident 1530:1546 text="abiTupleSetField"
LParen 1546:1547
Ident 1547:1548 text="t"
Comma 1548:1549
Number 1550:1551 text="0" suf="" isf=0 int=0
Comma 1551:1552
Ident 1553:1562 text="abiBoxI64"
LParen 1562:1563
Number 1563:1565 text="11" suf="" isf=0 int=11
RParen 1565:1566
RParen 1566:1567
Newline 1568:1569
Ident 1573:1589 text="abiTupleSetField"
LParen 1589:1590
Ident 1590:1591 text="t"
Comma 1591:1592
Number 1593:1594 text="1" suf="" isf=0 int=1
Comma 1594:1595
Ident 1596:1605 text="abiBoxI64"
LParen 1605:1606
Number 1606:1608 text="22" suf="" isf=0 int=22
RParen 1608:1609
RParen 1609:1610
Newline 1611:1612
Ident 1616:1632 text="abiTupleSetField"
LParen 1632:1633
Ident 1633:1634 text="t"
Comma 1634:1635
Number 1636:1637 text="2" suf="" isf=0 int=2
Comma 1637:1638
Ident 1639:1648 text="abiBoxI64"
LParen 1648:1649
Number 1649:1651 text="33" suf="" isf=0 int=33
RParen 1651:1652
RParen 1652:1653
Newline 1654:1655
Ident 1659:1666 text="println"
LParen 1666:1667
Str 1667:1683 T("f0: ") E[Ident 1673:1675 text="at"; LParen 1675:1676; Ident 1676:1677 text="t"; Comma 1677:1678; Number 1679:1680 text="0" suf="" isf=0 int=0; RParen 1680:1681; Eof 1682:1682]
RParen 1683:1684
Newline 1685:1686
Ident 1690:1697 text="println"
LParen 1697:1698
Str 1698:1714 T("f1: ") E[Ident 1704:1706 text="at"; LParen 1706:1707; Ident 1707:1708 text="t"; Comma 1708:1709; Number 1710:1711 text="1" suf="" isf=0 int=1; RParen 1711:1712; Eof 1713:1713]
RParen 1714:1715
Newline 1716:1717
Ident 1721:1728 text="println"
LParen 1728:1729
Str 1729:1745 T("f2: ") E[Ident 1735:1737 text="at"; LParen 1737:1738; Ident 1738:1739 text="t"; Comma 1739:1740; Number 1741:1742 text="2" suf="" isf=0 int=2; RParen 1742:1743; Eof 1744:1744]
RParen 1745:1746
Newline 1747:1748
Newline 1749:1750
Newline 1806:1807
Ident 1811:1818 text="println"
LParen 1818:1819
Str 1819:1854 T("oob: ") E[Ident 1826:1839 text="abiTupleField"; LParen 1839:1840; Ident 1840:1841 text="t"; Comma 1841:1842; Number 1843:1844 text="3" suf="" isf=0 int=3; RParen 1844:1845; As 1846:1848; Ident 1849:1852 text="int"; Eof 1853:1853]
RParen 1854:1855
Newline 1856:1857
Ident 1861:1868 text="println"
LParen 1868:1869
Str 1869:1909 T("far oob: ") E[Ident 1880:1893 text="abiTupleField"; LParen 1893:1894; Ident 1894:1895 text="t"; Comma 1895:1896; Number 1897:1899 text="99" suf="" isf=0 int=99; RParen 1899:1900; As 1901:1903; Ident 1904:1907 text="int"; Eof 1908:1908]
RParen 1909:1910
Newline 1911:1912
Newline 1913:1914
Newline 2004:2005
Var 2009:2012
Ident 2013:2014 text="e"
Assign 2015:2016
Ident 2017:2025 text="tupleNew"
LParen 2025:2026
Number 2026:2027 text="0" suf="" isf=0 int=0
RParen 2027:2028
Newline 2029:2030
Ident 2034:2041 text="println"
LParen 2041:2042
Str 2042:2071 T("empty len: ") E[Ident 2055:2066 text="abiTupleLen"; LParen 2066:2067; Ident 2067:2068 text="e"; RParen 2068:2069; Eof 2070:2070]
RParen 2071:2072
Newline 2073:2074
Ident 2078:2085 text="println"
LParen 2085:2086
Str 2086:2127 T("empty oob: ") E[Ident 2099:2112 text="abiTupleField"; LParen 2112:2113; Ident 2113:2114 text="e"; Comma 2114:2115; Number 2116:2117 text="0" suf="" isf=0 int=0; RParen 2117:2118; As 2119:2121; Ident 2122:2125 text="int"; Eof 2126:2126]
RParen 2127:2128
Newline 2129:2130
Newline 2131:2132
Newline 2216:2217
Newline 2269:2270
Let 2274:2277
LParen 2278:2279
Ident 2279:2280 text="a"
Comma 2280:2281
Ident 2282:2283 text="b"
RParen 2283:2284
Assign 2285:2286
LParen 2287:2288
Number 2288:2289 text="7" suf="" isf=0 int=7
Comma 2289:2290
Number 2291:2292 text="9" suf="" isf=0 int=9
RParen 2292:2293
Newline 2294:2295
Ident 2299:2306 text="println"
LParen 2306:2307
Str 2307:2329 T("destructure: ") E[Ident 2322:2323 text="a"; Eof 2324:2324] T(" ") E[Ident 2326:2327 text="b"; Eof 2328:2328]
RParen 2329:2330
Newline 2331:2332
Let 2336:2339
LParen 2340:2341
Ident 2341:2342 text="p"
Comma 2342:2343
Ident 2344:2345 text="q"
Comma 2345:2346
Ident 2347:2348 text="r"
RParen 2348:2349
Assign 2350:2351
LParen 2352:2353
Number 2353:2354 text="1" suf="" isf=0 int=1
Comma 2354:2355
Number 2356:2357 text="2" suf="" isf=0 int=2
Comma 2357:2358
Number 2359:2360 text="3" suf="" isf=0 int=3
RParen 2360:2361
Newline 2362:2363
Ident 2367:2374 text="println"
LParen 2374:2375
Str 2375:2396 T("triple: ") E[Ident 2385:2386 text="p"; Eof 2387:2387] T(" ") E[Ident 2389:2390 text="q"; Eof 2391:2391] T(" ") E[Ident 2393:2394 text="r"; Eof 2395:2395]
RParen 2396:2397
Newline 2398:2399
RBrace 2399:2400
Newline 2401:2402
Eof 2402:2402
