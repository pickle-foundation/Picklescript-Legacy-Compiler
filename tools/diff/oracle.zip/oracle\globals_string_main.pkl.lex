Newline 77:78
Newline 155:156
Newline 233:234
Newline 312:313
Newline 339:340
Newline 342:343
Newline 421:422
Newline 499:500
Newline 571:572
Newline 572:573
Var 573:576
Ident 577:585 text="greeting"
Colon 585:586
Ident 587:593 text="string"
Assign 594:595
Str 596:603 T("hello")
Newline 603:604
Var 604:607
Ident 608:611 text="tag"
Colon 611:612
Ident 613:619 text="string"
Assign 620:621
Str 622:629 T("world")
Newline 629:630
Newline 630:631
Fn 631:633
Ident 634:639 text="churn"
LParen 639:640
RParen 640:641
LBrace 642:643
Newline 643:644
Var 648:651
Ident 652:656 text="keep"
Assign 657:658
Str 659:661
Newline 661:662
Var 666:669
Ident 670:671 text="i"
Assign 672:673
Number 674:675 text="0" suf="" isf=0 int=0
Newline 675:676
While 680:685
LParen 686:687
Ident 687:688 text="i"
Lt 689:690
Number 691:695 text="4000" suf="" isf=0 int=4000
RParen 695:696
LBrace 697:698
Newline 698:699
Ident 707:711 text="keep"
Assign 712:713
Ident 714:718 text="keep"
Plus 719:720
Ident 721:724 text="str"
LParen 724:725
Ident 725:726 text="i"
RParen 726:727
Newline 727:728
Ident 736:737 text="i"
Assign 738:739
Ident 740:741 text="i"
Plus 742:743
Number 744:745 text="1" suf="" isf=0 int=1
Newline 745:746
RBrace 750:751
Newline 751:752
Ident 756:765 text="gcCollect"
LParen 765:766
True 766:770
RParen 770:771
Newline 771:772
Ident 776:785 text="gcCollect"
LParen 785:786
True 786:790
RParen 790:791
Newline 791:792
RBrace 792:793
Newline 793:794
Newline 794:795
Fn 795:797
Ident 798:802 text="main"
LParen 802:803
RParen 803:804
LBrace 805:806
Newline 806:807
Newline 883:884
Newline 943:944
Ident 948:953 text="churn"
LParen 953:954
RParen 954:955
Newline 955:956
If 960:962
LParen 963:964
Ident 964:972 text="greeting"
NotEq 973:975
Str 976:983 T("hello")
RParen 983:984
LBrace 985:986
Newline 986:987
Ident 995:1000 text="print"
LParen 1000:1001
Str 1001:1015 T("BAD greeting")
RParen 1015:1016
Newline 1016:1017
Ident 1025:1029 text="exit"
LParen 1029:1030
Number 1030:1031 text="1" suf="" isf=0 int=1
RParen 1031:1032
Newline 1032:1033
RBrace 1037:1038
Newline 1038:1039
If 1043:1045
LParen 1046:1047
Ident 1047:1050 text="tag"
NotEq 1051:1053
Str 1054:1061 T("world")
RParen 1061:1062
LBrace 1063:1064
Newline 1064:1065
Ident 1073:1078 text="print"
LParen 1078:1079
Str 1079:1088 T("BAD tag")
RParen 1088:1089
Newline 1089:1090
Ident 1098:1102 text="exit"
LParen 1102:1103
Number 1103:1104 text="1" suf="" isf=0 int=1
RParen 1104:1105
Newline 1105:1106
RBrace 1110:1111
Newline 1111:1112
Ident 1116:1124 text="greeting"
Assign 1125:1126
Str 1127:1136 T("mutated")
Newline 1136:1137
Ident 1141:1146 text="churn"
LParen 1146:1147
RParen 1147:1148
Newline 1148:1149
If 1153:1155
LParen 1156:1157
Ident 1157:1165 text="greeting"
NotEq 1166:1168
Str 1169:1178 T("mutated")
RParen 1178:1179
LBrace 1180:1181
Newline 1181:1182
Ident 1190:1195 text="print"
LParen 1195:1196
Str 1196:1213 T("BAD after churn")
RParen 1213:1214
Newline 1214:1215
Ident 1223:1227 text="exit"
LParen 1227:1228
Number 1228:1229 text="1" suf="" isf=0 int=1
RParen 1229:1230
Newline 1230:1231
RBrace 1235:1236
Newline 1236:1237
Ident 1241:1246 text="print"
LParen 1246:1247
Ident 1247:1255 text="greeting"
RParen 1255:1256
Newline 1256:1257
Ident 1261:1266 text="print"
LParen 1266:1267
Ident 1267:1270 text="tag"
RParen 1270:1271
Newline 1271:1272
Ident 1276:1281 text="print"
LParen 1281:1282
Str 1282:1301 T("globals-string ok")
RParen 1301:1302
Newline 1302:1303
RBrace 1303:1304
Eof 1304:1304
