Module 0:6
Ident 7:11 text="main"
Newline 11:12
Newline 12:13
Newline 92:93
Newline 170:171
Var 171:174
Ident 175:182 text="counter"
Colon 182:183
Ident 184:187 text="int"
Assign 188:189
Number 190:191 text="7" suf="" isf=0 int=7
Newline 191:192
Var 192:195
Ident 196:200 text="zero"
Colon 200:201
Ident 202:205 text="int"
Assign 206:207
Number 208:209 text="0" suf="" isf=0 int=0
Newline 209:210
Var 210:213
Ident 214:222 text="negative"
Colon 222:223
Ident 224:227 text="int"
Assign 228:229
Minus 230:231
Number 231:232 text="5" suf="" isf=0 int=5
Newline 232:233
Var 233:236
Ident 237:245 text="inferred"
Assign 246:247
Number 248:250 text="42" suf="" isf=0 int=42
Newline 250:251
Var 251:254
Ident 255:258 text="MAX"
Colon 258:259
Ident 260:263 text="int"
Assign 264:265
Number 266:269 text="100" suf="" isf=0 int=100
Newline 269:270
Newline 270:271
Fn 271:273
Ident 274:278 text="bump"
LParen 278:279
RParen 279:280
Colon 280:281
Ident 282:285 text="int"
LBrace 286:287
Newline 287:288
Ident 292:299 text="counter"
Assign 300:301
Ident 302:309 text="counter"
Plus 310:311
Number 312:313 text="1" suf="" isf=0 int=1
Newline 313:314
Return 318:324
Ident 325:332 text="counter"
Newline 332:333
RBrace 333:334
Newline 334:335
Newline 335:336
Fn 336:338
Ident 339:344 text="reset"
LParen 344:345
RParen 345:346
Colon 346:347
Ident 348:351 text="int"
LBrace 352:353
Newline 353:354
Ident 358:365 text="counter"
Assign 366:367
Number 368:369 text="7" suf="" isf=0 int=7
Newline 369:370
Return 374:380
Ident 381:388 text="counter"
Newline 388:389
RBrace 389:390
Newline 390:391
Newline 391:392
Fn 392:394
Ident 395:399 text="main"
LParen 399:400
RParen 400:401
LBrace 402:403
Newline 403:404
Ident 408:415 text="println"
LParen 415:416
Str 416:436 T("counter starts at:")
Comma 436:437
Ident 438:445 text="counter"
RParen 445:446
Newline 446:447
Ident 451:458 text="println"
LParen 458:459
Str 459:466 T("zero:")
Comma 466:467
Ident 468:472 text="zero"
RParen 472:473
Newline 473:474
Ident 478:485 text="println"
LParen 485:486
Str 486:497 T("negative:")
Comma 497:498
Ident 499:507 text="negative"
RParen 507:508
Newline 508:509
Ident 513:520 text="println"
LParen 520:521
Str 521:532 T("inferred:")
Comma 532:533
Ident 534:542 text="inferred"
RParen 542:543
Newline 543:544
Newline 544:545
Newline 607:608
Ident 612:619 text="println"
LParen 619:620
Str 620:629 T("bump 1:")
Comma 629:630
Ident 631:635 text="bump"
LParen 635:636
RParen 636:637
RParen 637:638
Newline 638:639
Ident 643:650 text="println"
LParen 650:651
Str 651:660 T("bump 2:")
Comma 660:661
Ident 662:666 text="bump"
LParen 666:667
RParen 667:668
RParen 668:669
Newline 669:670
Ident 674:681 text="println"
LParen 681:682
Str 682:691 T("bump 3:")
Comma 691:692
Ident 693:697 text="bump"
LParen 697:698
RParen 698:699
RParen 699:700
Newline 700:701
Ident 705:711 text="assert"
LParen 711:712
Ident 712:719 text="counter"
EqEq 720:722
Number 723:725 text="10" suf="" isf=0 int=10
Comma 725:726
Str 727:768 T("compound-style increment lost its value")
RParen 768:769
Newline 769:770
Newline 770:771
Newline 791:792
Ident 796:803 text="counter"
Assign 804:805
Number 806:807 text="7" suf="" isf=0 int=7
Newline 807:808
Ident 812:819 text="println"
LParen 819:820
Str 820:834 T("after reset:")
Comma 834:835
Ident 836:843 text="counter"
RParen 843:844
Newline 844:845
Ident 849:855 text="assert"
LParen 855:856
Ident 856:863 text="counter"
EqEq 864:866
Number 867:868 text="7" suf="" isf=0 int=7
Comma 868:869
Str 870:914 T("direct assignment did not reach the global")
RParen 914:915
Newline 915:916
Newline 916:917
Newline 992:993
Newline 1060:1061
Ident 1065:1072 text="counter"
PlusEq 1073:1075
Number 1076:1077 text="3" suf="" isf=0 int=3
Newline 1077:1078
Ident 1082:1089 text="println"
LParen 1089:1090
Str 1090:1105 T("counter += 3:")
Comma 1105:1106
Ident 1107:1114 text="counter"
RParen 1114:1115
Newline 1115:1116
Ident 1120:1127 text="counter"
MinusEq 1128:1130
Number 1131:1132 text="1" suf="" isf=0 int=1
Newline 1132:1133
Ident 1137:1144 text="println"
LParen 1144:1145
Str 1145:1160 T("counter -= 1:")
Comma 1160:1161
Ident 1162:1169 text="counter"
RParen 1169:1170
Newline 1170:1171
Ident 1175:1182 text="counter"
StarEq 1183:1185
Number 1186:1187 text="2" suf="" isf=0 int=2
Newline 1187:1188
Ident 1192:1199 text="println"
LParen 1199:1200
Str 1200:1215 T("counter *= 2:")
Comma 1215:1216
Ident 1217:1224 text="counter"
RParen 1224:1225
Newline 1225:1226
Ident 1230:1237 text="counter"
SlashEq 1238:1240
Number 1241:1242 text="3" suf="" isf=0 int=3
Newline 1242:1243
Ident 1247:1254 text="println"
LParen 1254:1255
Str 1255:1270 T("counter /= 3:")
Comma 1270:1271
Ident 1272:1279 text="counter"
RParen 1279:1280
Newline 1280:1281
Newline 1281:1282
Newline 1347:1348
Ident 1352:1359 text="println"
LParen 1359:1360
Str 1360:1377 T("counter + zero:")
Comma 1377:1378
Ident 1379:1386 text="counter"
Plus 1387:1388
Ident 1389:1393 text="zero"
RParen 1393:1394
Newline 1394:1395
Ident 1399:1406 text="println"
LParen 1406:1407
Str 1407:1423 T("counter + MAX:")
Comma 1423:1424
Ident 1425:1432 text="counter"
Plus 1433:1434
Ident 1435:1438 text="MAX"
RParen 1438:1439
Newline 1439:1440
Ident 1444:1451 text="println"
LParen 1451:1452
Str 1452:1473 T("counter + inferred:")
Comma 1473:1474
Ident 1475:1482 text="counter"
Plus 1483:1484
Ident 1485:1493 text="inferred"
RParen 1493:1494
Newline 1494:1495
Newline 1495:1496
Newline 1570:1571
Var 1575:1578
Ident 1579:1590 text="localShadow"
Assign 1591:1592
Number 1593:1594 text="1" suf="" isf=0 int=1
Newline 1594:1595
Ident 1599:1610 text="localShadow"
Assign 1611:1612
Ident 1613:1624 text="localShadow"
Plus 1625:1626
Number 1627:1630 text="100" suf="" isf=0 int=100
Newline 1630:1631
Ident 1635:1642 text="println"
LParen 1642:1643
Str 1643:1651 T("local:")
Comma 1651:1652
Ident 1653:1664 text="localShadow"
RParen 1664:1665
Newline 1665:1666
Ident 1670:1677 text="println"
LParen 1677:1678
Str 1678:1697 T("global unchanged:")
Comma 1697:1698
Ident 1699:1706 text="counter"
RParen 1706:1707
Newline 1707:1708
Newline 1708:1709
Newline 1776:1777
Ident 1781:1787 text="assert"
LParen 1787:1788
Ident 1788:1795 text="counter"
Lt 1796:1797
Ident 1798:1801 text="MAX"
Comma 1801:1802
Str 1803:1838 T("counter should still be below MAX")
RParen 1838:1839
Newline 1839:1840
Ident 1844:1850 text="assert"
LParen 1850:1851
Ident 1851:1858 text="counter"
Gt 1859:1860
Ident 1861:1865 text="zero"
Comma 1865:1866
Str 1867:1899 T("counter should stay above zero")
RParen 1899:1900
Newline 1900:1901
Newline 1901:1902
Ident 1906:1911 text="reset"
LParen 1911:1912
RParen 1912:1913
Newline 1913:1914
Ident 1918:1925 text="println"
LParen 1925:1926
Str 1926:1940 T("reset again:")
Comma 1940:1941
Ident 1942:1949 text="counter"
RParen 1949:1950
Newline 1950:1951
RBrace 1951:1952
Eof 1952:1952
