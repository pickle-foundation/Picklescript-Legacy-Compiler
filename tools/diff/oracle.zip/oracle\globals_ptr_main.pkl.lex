Newline 77:78
Newline 80:81
Newline 157:158
Newline 226:227
Newline 309:310
Newline 391:392
Newline 471:472
Newline 553:554
Newline 585:586
Newline 588:589
Newline 666:667
Newline 747:748
Newline 829:830
Newline 875:876
Newline 876:877
Class 877:882
Ident 883:886 text="Box"
LBrace 887:888
Newline 888:889
Var 893:896
Ident 897:898 text="n"
Colon 898:899
Ident 900:903 text="int"
Newline 903:904
Newline 904:905
Constructor 909:920
LParen 920:921
Ident 921:922 text="n"
Colon 922:923
Ident 924:927 text="int"
RParen 927:928
LBrace 929:930
Newline 930:931
This 939:943
Dot 943:944
Ident 944:945 text="n"
Assign 946:947
Ident 948:949 text="n"
Newline 949:950
RBrace 954:955
Newline 955:956
Newline 956:957
Fn 961:963
Ident 964:971 text="doubled"
LParen 971:972
RParen 972:973
Arrow 974:976
Ident 977:980 text="int"
LBrace 981:982
Newline 982:983
Return 991:997
This 998:1002
Dot 1002:1003
Ident 1003:1004 text="n"
Star 1005:1006
Number 1007:1008 text="2" suf="" isf=0 int=2
Newline 1008:1009
RBrace 1013:1014
Newline 1014:1015
RBrace 1015:1016
Newline 1016:1017
Newline 1017:1018
Struct 1018:1024
Ident 1025:1029 text="Pair"
LBrace 1030:1031
Newline 1031:1032
Ident 1036:1037 text="a"
Colon 1037:1038
Ident 1039:1042 text="int"
Newline 1042:1043
Ident 1047:1048 text="b"
Colon 1048:1049
Ident 1050:1053 text="int"
Newline 1053:1054
RBrace 1054:1055
Newline 1055:1056
Newline 1056:1057
Enum 1057:1061
Ident 1062:1067 text="Shade"
LBrace 1068:1069
Newline 1069:1070
Ident 1074:1079 text="Light"
Newline 1079:1080
Ident 1084:1088 text="Dark"
Newline 1088:1089
RBrace 1089:1090
Newline 1090:1091
Newline 1091:1092
Var 1092:1095
Ident 1096:1103 text="numbers"
Colon 1103:1104
Ident 1105:1109 text="List"
Lt 1109:1110
Ident 1110:1113 text="int"
Gt 1113:1114
Assign 1115:1116
LBracket 1117:1118
Number 1118:1119 text="1" suf="" isf=0 int=1
Comma 1119:1120
Number 1121:1122 text="2" suf="" isf=0 int=2
Comma 1122:1123
Number 1124:1125 text="3" suf="" isf=0 int=3
RBracket 1125:1126
Newline 1126:1127
Var 1127:1130
Ident 1131:1136 text="table"
Colon 1136:1137
Ident 1138:1141 text="Map"
Lt 1141:1142
Ident 1142:1148 text="string"
Comma 1148:1149
Ident 1150:1153 text="int"
Gt 1153:1154
Assign 1155:1156
LBrace 1157:1158
Str 1159:1162 T("a")
Colon 1162:1163
Number 1164:1165 text="1" suf="" isf=0 int=1
Comma 1165:1166
Str 1167:1170 T("b")
Colon 1170:1171
Number 1172:1173 text="2" suf="" isf=0 int=2
RBrace 1174:1175
Newline 1175:1176
Var 1176:1179
Ident 1180:1187 text="pairish"
Colon 1187:1188
LParen 1189:1190
Ident 1190:1193 text="int"
Comma 1193:1194
Ident 1195:1198 text="int"
RParen 1198:1199
Assign 1200:1201
LParen 1202:1203
Number 1203:1204 text="7" suf="" isf=0 int=7
Comma 1204:1205
Number 1206:1207 text="8" suf="" isf=0 int=8
RParen 1207:1208
Newline 1208:1209
Var 1209:1212
Ident 1213:1218 text="boxed"
Colon 1218:1219
Ident 1220:1223 text="Box"
Assign 1224:1225
Ident 1226:1229 text="Box"
LParen 1229:1230
Number 1230:1232 text="21" suf="" isf=0 int=21
RParen 1232:1233
Newline 1233:1234
Var 1234:1237
Ident 1238:1242 text="made"
Colon 1242:1243
Ident 1244:1248 text="Pair"
Assign 1249:1250
Ident 1251:1255 text="Pair"
LParen 1255:1256
Number 1256:1257 text="3" suf="" isf=0 int=3
Comma 1257:1258
Number 1259:1260 text="4" suf="" isf=0 int=4
RParen 1260:1261
Newline 1261:1262
Var 1262:1265
Ident 1266:1271 text="shade"
Colon 1271:1272
Ident 1273:1278 text="Shade"
Assign 1279:1280
Ident 1281:1286 text="Shade"
Dot 1286:1287
Ident 1287:1292 text="Light"
Newline 1292:1293
Newline 1293:1294
Fn 1294:1296
Ident 1297:1302 text="churn"
LParen 1302:1303
RParen 1303:1304
LBrace 1305:1306
Newline 1306:1307
Var 1311:1314
Ident 1315:1319 text="keep"
Assign 1320:1321
Str 1322:1324
Newline 1324:1325
Var 1329:1332
Ident 1333:1334 text="i"
Assign 1335:1336
Number 1337:1338 text="0" suf="" isf=0 int=0
Newline 1338:1339
While 1343:1348
LParen 1349:1350
Ident 1350:1351 text="i"
Lt 1352:1353
Number 1354:1358 text="4000" suf="" isf=0 int=4000
RParen 1358:1359
LBrace 1360:1361
Newline 1361:1362
Ident 1370:1374 text="keep"
Assign 1375:1376
Ident 1377:1381 text="keep"
Plus 1382:1383
Ident 1384:1387 text="str"
LParen 1387:1388
Ident 1388:1389 text="i"
RParen 1389:1390
Newline 1390:1391
Ident 1399:1400 text="i"
Assign 1401:1402
Ident 1403:1404 text="i"
Plus 1405:1406
Number 1407:1408 text="1" suf="" isf=0 int=1
Newline 1408:1409
RBrace 1413:1414
Newline 1414:1415
Ident 1419:1428 text="gcCollect"
LParen 1428:1429
True 1429:1433
RParen 1433:1434
Newline 1434:1435
Ident 1439:1448 text="gcCollect"
LParen 1448:1449
True 1449:1453
RParen 1453:1454
Newline 1454:1455
RBrace 1455:1456
Newline 1456:1457
Newline 1457:1458
Fn 1458:1460
Ident 1461:1466 text="check"
LParen 1466:1467
Ident 1467:1471 text="what"
Colon 1471:1472
Ident 1473:1479 text="string"
Comma 1479:1480
Ident 1481:1483 text="ok"
Colon 1483:1484
Ident 1485:1489 text="bool"
RParen 1489:1490
LBrace 1491:1492
Newline 1492:1493
If 1497:1499
LParen 1500:1501
Bang 1501:1502
Ident 1502:1504 text="ok"
RParen 1504:1505
LBrace 1506:1507
Newline 1507:1508
Ident 1516:1521 text="print"
LParen 1521:1522
Str 1522:1528 T("BAD ")
Plus 1529:1530
Ident 1531:1535 text="what"
RParen 1535:1536
Newline 1536:1537
Ident 1545:1549 text="exit"
LParen 1549:1550
Number 1550:1551 text="1" suf="" isf=0 int=1
RParen 1551:1552
Newline 1552:1553
RBrace 1557:1558
Newline 1558:1559
RBrace 1559:1560
Newline 1560:1561
Newline 1561:1562
Fn 1562:1564
Ident 1565:1573 text="tupleSum"
LParen 1573:1574
Ident 1574:1575 text="p"
Colon 1575:1576
LParen 1577:1578
Ident 1578:1581 text="int"
Comma 1581:1582
Ident 1583:1586 text="int"
RParen 1586:1587
RParen 1587:1588
Arrow 1589:1591
Ident 1592:1595 text="int"
LBrace 1596:1597
Newline 1597:1598
Match 1602:1607
LParen 1608:1609
Ident 1609:1610 text="p"
RParen 1610:1611
LBrace 1612:1613
Newline 1613:1614
Case 1622:1626
LParen 1627:1628
Ident 1628:1629 text="a"
Comma 1629:1630
Ident 1631:1632 text="b"
RParen 1632:1633
Arrow 1634:1636
Ident 1637:1638 text="a"
Plus 1639:1640
Ident 1641:1642 text="b"
Newline 1642:1643
RBrace 1647:1648
Newline 1648:1649
RBrace 1649:1650
Newline 1650:1651
Newline 1651:1652
Fn 1652:1654
Ident 1655:1659 text="main"
LParen 1659:1660
RParen 1660:1661
LBrace 1662:1663
Newline 1663:1664
Newline 1737:1738
Newline 1797:1798
Ident 1802:1807 text="churn"
LParen 1807:1808
RParen 1808:1809
Newline 1809:1810
Newline 1810:1811
Ident 1815:1820 text="check"
LParen 1820:1821
Str 1821:1827 T("list")
Comma 1827:1828
Ident 1829:1832 text="len"
LParen 1832:1833
Ident 1833:1840 text="numbers"
RParen 1840:1841
EqEq 1842:1844
Number 1845:1846 text="3" suf="" isf=0 int=3
RParen 1846:1847
Newline 1847:1848
Ident 1852:1857 text="check"
LParen 1857:1858
Str 1858:1869 T("list head")
Comma 1869:1870
Ident 1871:1878 text="numbers"
LBracket 1878:1879
Number 1879:1880 text="0" suf="" isf=0 int=0
RBracket 1880:1881
EqEq 1882:1884
Number 1885:1886 text="1" suf="" isf=0 int=1
RParen 1886:1887
Newline 1887:1888
Ident 1892:1897 text="check"
LParen 1897:1898
Str 1898:1909 T("list tail")
Comma 1909:1910
Ident 1911:1918 text="numbers"
LBracket 1918:1919
Number 1919:1920 text="2" suf="" isf=0 int=2
RBracket 1920:1921
EqEq 1922:1924
Number 1925:1926 text="3" suf="" isf=0 int=3
RParen 1926:1927
Newline 1927:1928
Newline 1928:1929
Ident 1933:1938 text="check"
LParen 1938:1939
Str 1939:1949 T("map size")
Comma 1949:1950
Ident 1951:1954 text="len"
LParen 1954:1955
Ident 1955:1960 text="table"
RParen 1960:1961
EqEq 1962:1964
Number 1965:1966 text="2" suf="" isf=0 int=2
RParen 1966:1967
Newline 1967:1968
Ident 1972:1977 text="check"
LParen 1977:1978
Str 1978:1985 T("map a")
Comma 1985:1986
Ident 1987:1992 text="table"
LBracket 1992:1993
Str 1993:1996 T("a")
RBracket 1996:1997
EqEq 1998:2000
Number 2001:2002 text="1" suf="" isf=0 int=1
RParen 2002:2003
Newline 2003:2004
Ident 2008:2013 text="check"
LParen 2013:2014
Str 2014:2021 T("map b")
Comma 2021:2022
Ident 2023:2028 text="table"
LBracket 2028:2029
Str 2029:2032 T("b")
RBracket 2032:2033
EqEq 2034:2036
Number 2037:2038 text="2" suf="" isf=0 int=2
RParen 2038:2039
Newline 2039:2040
Newline 2040:2041
Ident 2045:2050 text="check"
LParen 2050:2051
Str 2051:2058 T("tuple")
Comma 2058:2059
Ident 2060:2068 text="tupleSum"
LParen 2068:2069
Ident 2069:2076 text="pairish"
RParen 2076:2077
EqEq 2078:2080
Number 2081:2083 text="15" suf="" isf=0 int=15
RParen 2083:2084
Newline 2084:2085
Newline 2085:2086
Ident 2090:2095 text="check"
LParen 2095:2096
Str 2096:2109 T("class field")
Comma 2109:2110
Ident 2111:2116 text="boxed"
Dot 2116:2117
Ident 2117:2118 text="n"
EqEq 2119:2121
Number 2122:2124 text="21" suf="" isf=0 int=21
RParen 2124:2125
Newline 2125:2126
Ident 2130:2135 text="check"
LParen 2135:2136
Str 2136:2150 T("class method")
Comma 2150:2151
Ident 2152:2157 text="boxed"
Dot 2157:2158
Ident 2158:2165 text="doubled"
LParen 2165:2166
RParen 2166:2167
EqEq 2168:2170
Number 2171:2173 text="42" suf="" isf=0 int=42
RParen 2173:2174
Newline 2174:2175
Newline 2175:2176
Ident 2180:2185 text="check"
LParen 2185:2186
Str 2186:2196 T("struct a")
Comma 2196:2197
Ident 2198:2202 text="made"
Dot 2202:2203
Ident 2203:2204 text="a"
EqEq 2205:2207
Number 2208:2209 text="3" suf="" isf=0 int=3
RParen 2209:2210
Newline 2210:2211
Ident 2215:2220 text="check"
LParen 2220:2221
Str 2221:2231 T("struct b")
Comma 2231:2232
Ident 2233:2237 text="made"
Dot 2237:2238
Ident 2238:2239 text="b"
EqEq 2240:2242
Number 2243:2244 text="4" suf="" isf=0 int=4
RParen 2244:2245
Newline 2245:2246
Newline 2246:2247
Ident 2251:2256 text="check"
LParen 2256:2257
Str 2257:2263 T("enum")
Comma 2263:2264
Ident 2265:2270 text="shade"
EqEq 2271:2273
Ident 2274:2279 text="Shade"
Dot 2279:2280
Ident 2280:2285 text="Light"
RParen 2285:2286
Newline 2286:2287
Newline 2287:2288
Newline 2365:2366
Newline 2414:2415
Ident 2419:2426 text="numbers"
Dot 2426:2427
Ident 2427:2431 text="push"
LParen 2431:2432
Number 2432:2433 text="4" suf="" isf=0 int=4
RParen 2433:2434
Newline 2434:2435
Ident 2439:2444 text="boxed"
Assign 2445:2446
Ident 2447:2450 text="Box"
LParen 2450:2451
Number 2451:2452 text="5" suf="" isf=0 int=5
RParen 2452:2453
Newline 2453:2454
Ident 2458:2463 text="churn"
LParen 2463:2464
RParen 2464:2465
Newline 2465:2466
Ident 2470:2475 text="check"
LParen 2475:2476
Str 2476:2493 T("list after push")
Comma 2493:2494
Ident 2495:2498 text="len"
LParen 2498:2499
Ident 2499:2506 text="numbers"
RParen 2506:2507
EqEq 2508:2510
Number 2511:2512 text="4" suf="" isf=0 int=4
RParen 2512:2513
Newline 2513:2514
Ident 2518:2523 text="check"
LParen 2523:2524
Str 2524:2546 T("list after push head")
Comma 2546:2547
Ident 2548:2555 text="numbers"
LBracket 2555:2556
Number 2556:2557 text="3" suf="" isf=0 int=3
RBracket 2557:2558
EqEq 2559:2561
Number 2562:2563 text="4" suf="" isf=0 int=4
RParen 2563:2564
Newline 2564:2565
Ident 2569:2574 text="check"
LParen 2574:2575
Str 2575:2596 T("class after replace")
Comma 2596:2597
Ident 2598:2603 text="boxed"
Dot 2603:2604
Ident 2604:2611 text="doubled"
LParen 2611:2612
RParen 2612:2613
EqEq 2614:2616
Number 2617:2619 text="10" suf="" isf=0 int=10
RParen 2619:2620
Newline 2620:2621
Ident 2625:2630 text="check"
LParen 2630:2631
Str 2631:2648 T("map after churn")
Comma 2648:2649
Ident 2650:2655 text="table"
LBracket 2655:2656
Str 2656:2659 T("a")
RBracket 2659:2660
EqEq 2661:2663
Number 2664:2665 text="1" suf="" isf=0 int=1
RParen 2665:2666
Newline 2666:2667
Newline 2667:2668
Ident 2672:2677 text="print"
LParen 2677:2678
Str 2678:2694 T("globals-ptr ok")
RParen 2694:2695
Newline 2695:2696
RBrace 2696:2697
Eof 2697:2697
